# 复现说明 — beer-2026-a（交付目录 delivery/round2-final-DRAFT）

> 本文件由 `modeling_deliver {action:"package"}` 从项目台账生成：
> 台账 revision 483，contest.yaml sha256 45f3b9b2291b2de1c176327ba5a95820ae11be3d4a1be1ab0bcf7ef45eb91aa5，生成时间 2026-10-24T04:48:55.228Z，
> 交付模板 generic-zh。下面是**命令**，不是“应该能跑”的断言。

## 一、环境（唯一的外部前提）

- 解释器（绝对路径）：`/Users/baozhashizitou/Documents/Codex/2026-10-23/qing/work/reference-quality-env/bin/python`
- Python 版本：3.12.14
- 平台：macOS-27.0-arm64-arm-64bit
- contest.yaml 声明的附加依赖：（contest.yaml 未声明 runtime.pythonPackages）

依赖版本（来自项目初始化时的真实能力探测）：

| 依赖 | 版本 |
|---|---|
| numpy | 2.3.5 |
| pandas | 2.2.3 |
| scipy | 1.18.1 |
| openpyxl | 3.1.5 |
| matplotlib | 3.11.2 |
| sympy | 1.14.0 |
| sklearn | 1.9.1 |

> 换解释器或依赖版本后，指标可能有微小差异。复现容差以 `contest.yaml` 的
> `evaluation.reproductionTolerance` 为准，比较时用它，而不是“看起来差不多”。

## 二、包内目录

```text
delivery/round2-final-DRAFT/
  report/              report/paper.md（源）、report/rendered.md（交付渲染产物）、report/rendered.refs.json（来源记录）
  figures/             已登记图形 + figures.json（图 id、原路径、sha256、图注、来源实验）
  src/                 建模代码
  data/processed/      已登记的数据集（清洗后）
  data/splits/         训练/测试/assignment 文件
  experiments/         每个成功实验的 metrics.json / predictions.csv / result.json（代码不在 src/ 时也放这里）
  contest.yaml         交付时生效的配置（协议与容差的唯一来源）
  ledger-summary.json  台账摘要：结论、验证、图形、复跑关系、解释器与依赖版本
  README_REPRODUCE.md  本文件
  SHA256SUMS           包内每个文件的 sha256
```

## 三、解压与完整性核对

```bash
tar -xzf delivery/round2-final-DRAFT.tar.gz
cd delivery/round2-final-DRAFT
shasum -a 256 -c SHA256SUMS
```

数据集与它们的 hash：

| 数据集 | 文件 | sha256(前16) | 目标列 |
|---|---|---|---|
| DATA-0001 | data/clean/q2_raw.csv | 42ec0bbe99938ebf | A_malt_all |
| DATA-0002 | data/clean/q1_mapped.csv | 28a7108210a5abf6 | A_malt_all |
| DATA-0003 | data/clean/q3.csv | 49ed4d054a15f514 | tasting_category_fine |

划分方式与划分文件的 hash：

| 划分 | 数据集 | 方法 | train sha256 | test sha256 | assignment 文件 |
|---|---|---|---|---|---|
| SPLIT-0001 | DATA-0001 | random-holdout | a58becb2c623 | 54c01a6ad731 | data/splits/SPLIT-0001/assignment.csv |
| SPLIT-0002 | DATA-0002 | random-holdout | 69e50db79ef4 | dc8a58a04baf | data/splits/SPLIT-0002/assignment.csv |

> 原始附件不在包内；按下面的 sha256 从原始来源重新获取，再走同一清洗脚本：

| 原始文件 | 来源名 | 项目内路径 | sha256(前16) | 角色 |
|---|---|---|---|---|
| RAW-41984922 | 419849227a02e0c7-1.csv | data/raw/imported/419849227a02e0c7-1.csv | 419849227a02e0c7 | chemical_features |
| RAW-415709ac | 415709ac10f2f730-2.csv | data/raw/imported/415709ac10f2f730-2.csv | 415709ac10f2f730 | compound_correlation |
| RAW-fe4dcabd | fe4dcabd48431e6d-3.xlsx | data/raw/imported/fe4dcabd48431e6d-3.xlsx | fe4dcabd48431e6d | sensory_scorecards |
| RAW-43a7b386 | 43a7b38682ed81ce-4.csv | data/raw/imported/43a7b38682ed81ce-4.csv | 43a7b38682ed81ce | sensory_targets |
| RAW-c512eed1 | c512eed108de6f98-5.csv | data/raw/imported/c512eed108de6f98-5.csv | c512eed108de6f98 | sensory_correlation |
| RAW-a55004fb | a55004fb0390299a-6.csv | data/raw/imported/a55004fb0390299a-6.csv | a55004fb0390299a | chemical_sensory_correlation |
| RAW-2083138d | 2083138df46640e2-7.csv | data/raw/imported/2083138df46640e2-7.csv | 2083138df46640e2 | sensory_descriptors |
| RAW-f2316766 | f2316766792111d9-8.xlsx | data/raw/imported/f2316766792111d9-8.xlsx | f2316766792111d9 | reference_thresholds |
| RAW-40813e27 | 40813e273e081ae0-数据说明.txt | data/raw/imported/40813e273e081ae0-数据说明.txt | 40813e273e081ae0 | data_notes |

## 四、复跑实验

在包根目录执行下表命令。若脚本依赖“实验目录内的相对路径”，先 `cd` 到该实验目录再执行同一行命令。

> **依赖 `modeling_contract` 的脚本**：该模块随整合包发布（`<已安装 preset>/packs/modeling-contest/python/`），
> 不在项目目录里。手动复跑时先把它加入 `PYTHONPATH`，例如：
> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/path/to/preset/packs/modeling-contest/python python src/model.py`
> （`PYTHONDONTWRITEBYTECODE=1` 避免把 `__pycache__` 写进 preset 安装目录——那会让包名册/审计把构建产物当成未登记文件）。
> 通过 `modeling_experiment {action:"run"}` 复跑时 runner 会自动设置，无需手工处理。
> 若脚本只读取环境变量（`MODELING_TRAIN_FILE` 等），请按 `contest.yaml` 的划分文件自行导出。

| 实验 | 小题 | 模型 | 状态 | rmse | 复跑命令（在包根执行） |
|---|---|---|---|---|---|
| EXP-0001 | Q1 | MODEL-0001 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0002 | Q1 | MODEL-0002 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0003 | Q1 | MODEL-0003 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0004 | Q2 | MODEL-0004 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0005 | Q3 | MODEL-0005 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0007 | Q2 | MODEL-0007 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0008 | Q3 | MODEL-0008 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0010 | Q2 | MODEL-0010 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0011 | Q3 | MODEL-0011 | succeeded | （无 rmse） | `不可精确复现：缺完整冻结依赖；以新实验重建，不能补写历史通过` |
| EXP-0013 | Q1 | MODEL-0013 | succeeded | （无 rmse） | `/Users/baozhashizitou/Documents/Codex/2026-10-23/qing/work/reference-quality-env/bin/python experiments/EXP-0013/inputs/src/q1_trainonly.py` |
| EXP-0016 | Q1 | MODEL-0015 | succeeded | （无 rmse） | `/Users/baozhashizitou/Documents/Codex/2026-10-23/qing/work/reference-quality-env/bin/python experiments/EXP-0016/inputs/src/q1_trainonly.py` |
| EXP-0017 | Q1 | MODEL-0015 | succeeded | （无 rmse） | `/Users/baozhashizitou/Documents/Codex/2026-10-23/qing/work/reference-quality-env/bin/python experiments/EXP-0016/inputs/src/q1_trainonly.py` |

> 复跑关系（哪个实验是谁的 `rerunOf`）见 `ledger-summary.json` 的 `experiments[]`。
> 新跑出来的数是**新实验**的数，不是旧实验的数；不要在包内覆盖旧结果。

## 五、复核结论与验证

| 校验 | 实验 | 类型 | 结果 | 新鲜度 |
|---|---|---|---|---|
| VAL-0001 | EXP-0002 | leakage | passed | fresh |
| VAL-0002 | EXP-0002 | split-integrity | passed | fresh |
| VAL-0003 | EXP-0002 | holdout-metrics | passed | fresh |
| VAL-0004 | EXP-0002 | leakage | passed | fresh |
| VAL-0005 | EXP-0002 | split-integrity | passed | fresh |
| VAL-0006 | EXP-0002 | holdout-metrics | passed | fresh |
| VAL-0007 | EXP-0002 | baseline-compare | passed | fresh |
| VAL-0008 | EXP-0004 | leakage | FAILED | STALE |
| VAL-0009 | EXP-0004 | split-integrity | passed | STALE |
| VAL-0010 | EXP-0004 | leakage | FAILED | STALE |
| VAL-0011 | EXP-0004 | split-integrity | passed | STALE |
| VAL-0012 | EXP-0007 | leakage | passed | STALE |
| VAL-0013 | EXP-0007 | split-integrity | passed | STALE |
| VAL-0014 | EXP-0008 | leakage | passed | STALE |
| VAL-0015 | EXP-0008 | leakage | passed | STALE |
| VAL-0016 | EXP-0007 | leakage | passed | fresh |
| VAL-0017 | EXP-0007 | split-integrity | passed | fresh |
| VAL-0018 | EXP-0008 | leakage | passed | fresh |
| VAL-0019 | EXP-0016 | independent-rerun | passed | fresh |

| 论断 | 小题 | 状态 | 陈述(截断) |
|---|---|---|---|
| CLAIM-0001 | Q1 | STALE | 在 50 维 mapped grade 上，多输出 Ridge（α=1000，由训练集 5 折 OOF 选出）的留出 M |
| CLAIM-0002 | Q2 | STALE | 每个感官维度的 Top-3 关键化合物具有明显方法依赖性：Spearman 排序与 Ridge 系数排序的 Top-3  |
| CLAIM-0003 | Q3 | STALE | 风格迁移若不加约束，会把缺陷超阈值比例由 0.091 抬到 0.318（逐样本不恶化比例仅 0.333）；加入"缺陷列不 |

| 图 | 标题 | 文件 | sha256(前16) |
|---|---|---|---|
| FIG-0001 | Q1 三模型（B0 常数基线 / C1 多输出 Ridge / C2 多输出 HistGBM）的训练集 OOF MAE 与留出 MAE 对比。 | figures/q1_model_comparison.png | 64684518a0270328 |
| FIG-0002 | Q1 选定模型（C1 多输出 Ridge）在 50 个感官维度上的留出 MAE（按降序排列）。 | figures/q1_per_target_mae.png | ea06b8a0d222de17 |
| FIG-0003 | Q1 多输出 Ridge 的 Top-20 化合物平均标准化系数幅值（50 个目标上的 mean |β|）。 | figures/q1_feature_importance.png | 4875364ace53d3b4 |
| FIG-0004 | Q2 每个感官维度 Top-3 化合物在 B=500 bootstrap 下的入选频率（三种深浅表示排名 1–3）。 | figures/q2_topk_stability.png | 8b8cadb24af2a650 |
| FIG-0005 | Q2 逐维度 Top-3 Jaccard（Spearman 排序 vs Ridge 系数排序）的分布，虚线为 50 维均值。 | figures/q2_method_jaccard.png | 171bb30e5b7c6c37 |
| FIG-0006 | Q3 留出风格（Tripel/Kriek/Lambic）的能量距离：源风格基线、不受约束迁移、缺陷约束迁移、few-shot 生成。 | figures/q3_energy_distance.png | c0649f5a14c3affd |
| FIG-0007 | Q3 缺陷化合物 OAV 迁移前后（log 轴，虚线为 OAV=1 阈值）：不受约束迁移抬高 OAV，缺陷约束后保持不变。 | figures/q3_defect_oav.png | 748874329ab0b5f4 |

> 论文里的每个数字都由占位符从台账渲染而来，逐条解析记录在 `report/rendered.refs.json`；
> 每条结论的证据引用在 `ledger-summary.json` 的 `claims[]` 里。

## 六、交付检查读数

passed 31 / failed 34 / skipped 5

已知限制与警告：

- contest.yaml changed since the project ledger was created: the protocol in force may differ from the one the recorded results were produced under
- experiment EXP-0001: 2 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0001/outputs.json, experiments/EXP-0001/predictions_long.csv
- experiment EXP-0002: 2 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0002/outputs.json, experiments/EXP-0002/predictions_long.csv
- experiment EXP-0003: 2 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0003/outputs.json, experiments/EXP-0003/predictions_long.csv
- experiment EXP-0004: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0004/outputs.json
- experiment EXP-0005: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0005/outputs.json
- experiment EXP-0006 is queued and is not in the package
- experiment EXP-0007: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0007/outputs.json
- experiment EXP-0008: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0008/outputs.json
- experiment EXP-0009 is queued and is not in the package
- experiment EXP-0010: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0010/outputs.json
- experiment EXP-0011: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0011/outputs.json
- experiment EXP-0012 is failed: its numbers are not in the package (a failed run is not a result)
- experiment EXP-0013: 2 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0013/inputs/src/emit.py, experiments/EXP-0013/inputs/src/q1_trainonly.py
- experiment EXP-0014 is failed: its numbers are not in the package (a failed run is not a result)
- experiment EXP-0015 is failed: its numbers are not in the package (a failed run is not a result)
- experiment EXP-0016: 1 output file(s) are not packaged (only metrics/predictions/result + registered figure files are): experiments/EXP-0016/inputs/src/q1_trainonly.py

## 七、诚实边界（本包不能保证的部分）

1. **不生成 PDF/TeX**：本包保证 md 交付。`contest.yaml` 声明了 tex/pdf 而实际没有产出时，交付检查会**判失败**，
   不会把“应该能生成”写成“已就绪”。
2. **随机性**：随机过程按登记的 seed 复跑；未固定的差异以 `evaluation.reproductionTolerance` 比较，超出即视为不可复现。
3. **原始数据不随包分发**：原始附件只以 sha256 记录，需要从原始来源重新获取。
4. **环境随本地而定**：解释器、依赖版本、时间戳不随包分发；换环境后请重新探测解释器并重跑实验。
5. **比赛要求只核对声明的部分**：页数/匿名/命名/AI 说明只在 `contest.yaml` 的 `delivery.contest` 声明后才核对，
   且只有能机械核对的部分被核对（例如页数需要 PDF）；其余需人工确认。

## 八、包内文件清单

- report/build_report.json
- report/paper-header.tex
- report/paper.aux
- report/paper.log
- report/paper.md
- report/paper.pdf
- report/paper.tex
- report/rendered.md
- report/rendered.refs.json
- report/rendered_build.md
- figures/FIG-0001-q1_model_comparison.png
- figures/q1_model_comparison.png
- figures/FIG-0002-q1_per_target_mae.png
- figures/q1_per_target_mae.png
- figures/FIG-0003-q1_feature_importance.png
- figures/q1_feature_importance.png
- figures/FIG-0004-q2_topk_stability.png
- figures/q2_topk_stability.png
- figures/FIG-0005-q2_method_jaccard.png
- figures/q2_method_jaccard.png
- figures/FIG-0006-q3_energy_distance.png
- figures/q3_energy_distance.png
- figures/FIG-0007-q3_defect_oav.png
- figures/q3_defect_oav.png
- figures/figures.json
- src/__pycache__/emit.cpython-312.pyc
- src/__pycache__/lib.cpython-312.pyc
- src/__pycache__/prepare.cpython-312.pyc
- src/__pycache__/q1_common.cpython-312.pyc
- src/build_paper.py
- src/build_q1mapped.py
- src/build_q2raw.py
- src/build_q3.py
- src/emit.py
- src/evidence_docs.py
- src/lib.py
- src/make_figures.py
- src/prepare.py
- src/q1_analysis.py
- src/q1_baseline.py
- src/q1_candidate.py
- src/q1_common.py
- src/q1_rerun_oof.py
- src/q1_trainonly.py
- src/q2_baseline.py
- src/q2_topk.py
- src/q3_baseline.py
- src/q3_generate.py
- data/clean/q2_raw.csv
- data/raw/imported/43a7b38682ed81ce-4.csv
- data/clean/q1_mapped.csv
- data/clean/q3.csv
- data/raw/imported/419849227a02e0c7-1.csv
- data/splits/SPLIT-0001/assignment.csv
- data/splits/SPLIT-0001/train.csv
- data/splits/SPLIT-0001/test.csv
- data/splits/SPLIT-0002/assignment.csv
- data/splits/SPLIT-0002/train.csv
- data/splits/SPLIT-0002/test.csv
- experiments/EXP-0001/metrics.json
- experiments/EXP-0001/predictions.csv
- experiments/EXP-0001/result.json
- experiments/EXP-0002/metrics.json
- experiments/EXP-0002/predictions.csv
- experiments/EXP-0002/result.json
- experiments/EXP-0003/metrics.json
- experiments/EXP-0003/predictions.csv
- experiments/EXP-0003/result.json
- experiments/EXP-0004/metrics.json
- experiments/EXP-0004/result.json
- experiments/EXP-0005/metrics.json
- experiments/EXP-0005/result.json
- experiments/EXP-0007/metrics.json
- experiments/EXP-0007/result.json
- experiments/EXP-0008/metrics.json
- experiments/EXP-0008/result.json
- experiments/EXP-0010/metrics.json
- experiments/EXP-0010/result.json
- experiments/EXP-0011/metrics.json
- experiments/EXP-0011/result.json
- experiments/EXP-0013/metrics.json
- experiments/EXP-0013/result.json
- experiments/EXP-0016/metrics.json
- experiments/EXP-0016/result.json
- experiments/EXP-0017/metrics.json
- experiments/EXP-0017/result.json
- experiments/EXP-0017/q1_trainonly.py
- contest.yaml
- quality-blockers.json
- ledger-summary.json
