#!/usr/bin/env python3
"""Compare complete local run artifacts against frozen v6.2 source outputs.

AI assistance: OpenAI Codex, 2026-10-29; exact serving model unverified.
This is a deterministic reproduction check, not independent implementation or
an assertion that a team member independently designed or reviewed the model.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
SOURCE = BASE / 'engine'
RUN = BASE / 'run-core'


def compare(reference, actual, keys, tolerance=1e-9):
    a, b = pd.read_csv(reference), pd.read_csv(actual)
    missing = [c for c in a if c not in b and c != 'alternative_first_valid']
    if a.duplicated(keys).any() or b.duplicated(keys).any():
        return {'passed': False, 'reason': 'duplicate comparison key'}
    a, b = a.set_index(keys).sort_index(), b.set_index(keys).sort_index()
    if not a.index.equals(b.index):
        return {'passed': False, 'reason': 'row keys differ', 'reference_rows': len(a), 'actual_rows': len(b)}
    mismatches, max_delta, numeric_cells = {}, 0.0, 0
    for col in a.columns.intersection(b.columns):
        av, bv = a[col], b[col]
        if pd.api.types.is_numeric_dtype(av) and pd.api.types.is_numeric_dtype(bv):
            x, y = av.to_numpy(float), bv.to_numpy(float)
            if not np.array_equal(np.isnan(x), np.isnan(y)):
                mismatches[col] = 'NA masks differ'
                continue
            mask = np.isfinite(x) & np.isfinite(y)
            delta = float(np.max(np.abs(x[mask] - y[mask]))) if mask.any() else 0.0
            max_delta = max(max_delta, delta)
            numeric_cells += int(mask.sum())
            if delta > tolerance:
                mismatches[col] = delta
        else:
            x, y = av.fillna('<NA>').astype(str), bv.fillna('<NA>').astype(str)
            neq = int((x != y).sum())
            if neq:
                mismatches[col] = neq
    if 'alternative_first_valid' in a and 'alternative_first_valid' not in b:
        if not a['alternative_first_valid'].equals(a['alternative_rank4']):
            mismatches['alternative_first_valid'] = 'frozen canonical alias is inconsistent'
    return {'passed': not missing and not mismatches, 'rows': len(a),
            'common_columns': len(a.columns.intersection(b.columns)),
            'missing_columns': missing, 'numeric_cells': numeric_cells,
            'max_absolute_delta': max_delta, 'absolute_tolerance': tolerance,
            'mismatches': mismatches,
            'reference': str(reference), 'actual': str(actual)}


def main():
    global SOURCE, RUN
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,default=SOURCE)
    parser.add_argument('--run-root',type=Path,default=RUN)
    parser.add_argument('--result-dir',type=Path,default=None)
    args=parser.parse_args()
    SOURCE=args.source_root.resolve();RUN=args.run_root.resolve()
    result_dir=(args.result_dir or RUN/'verification').resolve()
    result_dir.mkdir(parents=True,exist_ok=True)
    entries = []
    entries.append(compare(SOURCE/'outputs/q1/oof_long.csv', RUN/'experiments/EXP-0073/oof_long.csv',
                           ['beer','repeat','fold','target','model']))
    entries.append(compare(SOURCE/'outputs/q1/oof_predictions_750.csv', RUN/'experiments/EXP-0073/predictions.csv',
                           ['beer','repeat','outer_fold','model']))
    for repeat in range(3):
        for file in ['strict_top3.csv','strict_top3_by_method.csv','extended_top3.csv','extended_top3_by_method.csv']:
            keys = ['dimension','rank'] + (['method'] if 'by_method' in file else [])
            entries.append(compare(SOURCE/f'outputs/q2/v62_clean/repeat{repeat}'/file,
                                   RUN/f'experiments/EXP-0107/repeat{repeat}'/file,keys))
    for file, keys in [
        ('samples.csv',['sample_id']),
        ('q3_metrics.csv',['repeat','fold','stage','model','style']),
        ('constraints.csv',['sample_id','field','bound_type']),
        ('sensory_profiles.csv',['sample_id','stage']),
    ]:
        entries.append(compare(SOURCE/'outputs/q3'/file,RUN/'experiments/EXP-0109'/file,keys))
    entries.append(compare(SOURCE/'outputs/q3/transfers.csv',RUN/'experiments/EXP-0110/transfers.csv',
                           ['repeat','fold','source_beer','strategy'], tolerance=1e-8))
    entries.append(compare(SOURCE/'outputs/q3/transfer_constraints.csv',RUN/'experiments/EXP-0110/transfer_constraints.csv',
                           ['repeat','fold','source_beer','strategy','field','bound_type'], tolerance=1e-8))
    # Only synthetic known-answer tests are called here. The full r00 main also
    # requires contest.yaml, absent from the published v6.2 support archive.
    sys.path.insert(0,str(RUN/'src'))
    import r00_contract_tests as tests
    synthetic = [getattr(tests,name)() for name in [
        'test_graph_reduced_rank','test_qp_active_set','test_energy_toy',
        'test_gradient_finite_difference','test_ridge_equivalence']]
    import v6_common as protocol
    split_checks = []
    splits=protocol.load_splits(); all_beers=set(pd.read_csv(RUN/'data/clean/q1_mapped.csv').beer)
    coverage={}
    for rep,fold,train,test in protocol.iter_outer(splits):
        train,test=set(map(int,train)),set(map(int,test))
        inner=[]
        for f,it,iv in protocol.iter_inner(rep,fold,sorted(train),splits):
            it,iv=set(map(int,it)),set(map(int,iv))
            inner.append(not(it&iv) and it|iv==train and not((it|iv)&test))
        split_checks.append({'repeat':rep,'fold':fold,'passed':not(train&test) and train|test==all_beers and all(inner)})
        coverage.setdefault(rep,[]).extend(test)
    exact_coverage=all(len(v)==250 and len(set(v))==250 for v in coverage.values())
    original_py=list((SOURCE/'src').glob('*.py'))
    byte_identical=all(hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256((RUN/'src'/p.name).read_bytes()).hexdigest() for p in original_py)
    local_names={p.stem:p for p in original_py}
    closure=set();todo=['q1_fix','q2_fix','q3_fix','q3_transfer_fix']
    while todo:
        name=todo.pop()
        if name in closure:continue
        closure.add(name)
        tree=ast.parse(local_names[name].read_text())
        for node in ast.walk(tree):
            imported=[n.name.split('.')[0] for n in node.names] if isinstance(node,ast.Import) else ([node.module.split('.')[0]] if isinstance(node,ast.ImportFrom) and node.module else [])
            todo.extend(n for n in imported if n in local_names and n not in closure)
    inventory={'all_shipped_model_python':[str(p.relative_to(SOURCE)) for p in sorted(original_py)],
               'core_entry_import_closure':[str(local_names[n].relative_to(SOURCE)) for n in sorted(closure)],
               'all_build_python':[str(p.relative_to(SOURCE)) for p in sorted((SOURCE/'build').glob('*.py'))],
               'note':'Shipped source includes historical alternatives; presence is not a claim that every file ran in the final model.'}
    (result_dir/'actual-code-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
    result={'scope':'Whole-file comparisons and synthetic mathematical oracles after the four actual local confirmatory runs; no external validation.',
            'artifact_comparisons':entries,'synthetic_tests':synthetic,'split_checks':split_checks,
            'outer_test_exactly_once_per_repeat':exact_coverage,
            'model_source_copy_byte_identical':byte_identical,
            'all_passed':all(r['passed'] for r in entries+synthetic+split_checks) and exact_coverage and byte_identical}
    (result_dir/'artifact-comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'all_passed':result['all_passed'],'artifact_comparisons':len(entries),
                      'failures':[r for r in entries if not r['passed']],
                      'synthetic_passed':sum(t['passed'] for t in synthetic),
                      'source_copy_byte_identical':byte_identical},ensure_ascii=False))
    return 0 if result['all_passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
