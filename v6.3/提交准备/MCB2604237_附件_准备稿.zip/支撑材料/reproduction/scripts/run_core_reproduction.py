#!/usr/bin/env python3
"""Re-run the frozen model source in a fresh project, without a plugin ledger.

AI assistance: OpenAI Codex helped write this verification runner on 2026-10-29.
The precise serving model/version and historic human review remain unverified.
This runner does not alter model source, register an experiment, or certify a
human contribution. Raw contest attachments must be supplied separately.
"""
from __future__ import annotations

import argparse
import csv
import datetime
import hashlib
import importlib.metadata
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def frozen_references(source):
    """Read comparison targets from the shipped v6.2 tables, not the new run."""
    refs = {}
    paths = []
    rows = []
    jaccards = []
    for repeat in range(3):
        path = source / f'outputs/q2/v62_clean/repeat{repeat}/strict_top3_by_method.csv'
        table = list(csv.DictReader(path.open(encoding='utf-8', newline='')))
        paths.append(path)
        rows.extend(table)
        dimensions = sorted({r['dimension'] for r in table})
        methods = sorted({r['method'] for r in table})
        for dimension in dimensions:
            sets = {method: {r['compound'] for r in table
                             if r['dimension'] == dimension and r['method'] == method}
                    for method in methods}
            for first, second in itertools.combinations(methods, 2):
                a, b = sets[first], sets[second]
                jaccards.append(len(a & b) / len(a | b))
    refs['q2'] = {
        'metrics': {'topk-jaccard': sum(jaccards) / len(jaccards),
                    'sign_stability_mean': sum(float(r['sign_stability']) for r in rows) / len(rows),
                    'sign_stability_legacy_mean': sum(float(r['p_positive_legacy']) for r in rows) / len(rows),
                    'pi_mean': sum(float(r['pi']) for r in rows) / len(rows)},
        'derivation': 'v6.2 frozen strict by-method tables: 3 x 600 rows; Jaccard over 3 x 50 x 6 method pairs',
        'files': {str(p.relative_to(source)): sha(p) for p in paths},
    }
    energy_path = source / 'outputs/q3/energy_summary.csv'
    energy = next(r for r in csv.DictReader(energy_path.open(encoding='utf-8', newline=''))
                  if r['scope'] == 'allStyles')
    constraints_path = source / 'outputs/q3/constraints.csv'
    residuals = {}
    for row in csv.DictReader(constraints_path.open(encoding='utf-8', newline='')):
        residuals[row['sample_id']] = max(residuals.get(row['sample_id'], 0.0), float(row['residual']))
    refs['q3_generation'] = {
        'metrics': {'constraint-satisfaction': sum(v <= 0 for v in residuals.values()) / len(residuals),
                    'energy-distance': float(energy['V_normalized']),
                    'energy-V-raw': float(energy['V']),
                    'energy-U-signed': float(energy['U_signed'])},
        'derivation': 'v6.2 frozen allStyles energy summary and sample-level maximum declared constraint residual',
        'files': {str(p.relative_to(source)): sha(p) for p in [energy_path, constraints_path]},
    }
    for role, rel in [('q1', 'outputs/q1/metrics.json'),
                      ('q3_transfer', 'outputs/q3/transfer_metrics.json')]:
        path = source / rel
        refs[role] = {'metrics': json.loads(path.read_text()),
                      'derivation': 'v6.2 frozen metric artifact', 'files': {rel: sha(path)}}
    return refs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=HERE / 'engine')
    parser.add_argument('--raw-root', type=Path, required=True,
                        help='Directory containing the original 2.csv and 6.csv')
    parser.add_argument('--run-root', type=Path, default=None,
                        help='Fresh output directory; default is a new timestamped runs/ directory')
    args = parser.parse_args()
    source = args.source_root.resolve()
    root = (args.run_root or HERE / 'runs' /
            (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6])).resolve()
    if root.exists():
        raise SystemExit(f'Refusing to reuse an existing run root: {root}')
    root.mkdir(parents=True)
    result_dir = root / 'verification'
    result_dir.mkdir()
    for rel in ['src', 'data/clean', 'data/splits', 'data/processed']:
        shutil.copytree(source / rel, root / rel,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    raw_specs = [
        ('2.csv', '415709ac10f2f730-2.csv',
         '415709ac10f2f730d31f249bd6ac108250bdfbfd62e0055f4d8db9b41ec9cc4c'),
        ('6.csv', 'a55004fb0390299a-6.csv',
         'a55004fb0390299a5c8089f0c37d3bfc006e7049963c84d7d9652affabe614ae'),
    ]
    raw_dir = root / 'data/raw/imported'
    raw_dir.mkdir(parents=True)
    for input_name, dest_name, expected in raw_specs:
        original = args.raw_root / input_name
        if sha(original) != expected:
            raise SystemExit(f'Raw attachment checksum mismatch: {original}')
        shutil.copy2(original, raw_dir / dest_name)
    alias_dir = root / 'MathorCup_A_独立审查与重跑方案'
    alias_dir.mkdir()
    shutil.copy2(root / 'data/processed/sensory_name_alignment.csv',
                 alias_dir / 'sensory_name_alignment.csv')
    manifest = {
        'kind': 'local-confirmatory-model-rerun',
        'started_at': datetime.datetime.now().astimezone().isoformat(),
        'source_root': str(source), 'run_root': str(root),
        'runner': str(Path(__file__).resolve()), 'runner_sha256': sha(__file__),
        'python': sys.executable, 'python_version': sys.version,
        'packages': {name: importlib.metadata.version(name) for name in
                     ['numpy', 'pandas', 'scipy', 'matplotlib']},
        'mode': 'local-file outputs; no plugin ledger registration',
        'tolerance': {'absolute': 1e-9, 'relative': 1e-6},
        'source_files': {str(p.relative_to(root)): sha(p)
                         for p in sorted((root / 'src').glob('*.py'))},
        'inputs': {str(p.relative_to(root)): sha(p)
                   for p in sorted((root / 'data').rglob('*')) if p.is_file()},
        'runs': [], 'all_passed': False,
    }
    references = frozen_references(source)
    (result_dir / 'frozen-references.json').write_text(json.dumps(references, ensure_ascii=False, indent=2) + '\n')
    env = dict(os.environ)
    for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
              'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']:
        env[k] = '1'
    env['MPLCONFIGDIR'] = str(root / 'state/mplconfig')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONPATH'] = str(root / 'src')
    env.pop('MODELING_PROJECT_DIR', None)
    logs = root / 'logs'
    logs.mkdir()
    targets = [
        ('q1', 'q1_fix.py', 'EXP-0073',
         source / 'outputs/q1/metrics.json',
         ['mae', 'mae_median', 'mae_all50', 'mae_ridge0', 'mae_graph_ridge', 'skill_af30']),
        ('q2', 'q2_fix.py', 'EXP-0107',
         None,
         ['topk-jaccard', 'sign_stability_mean', 'sign_stability_legacy_mean', 'pi_mean']),
        ('q3_generation', 'q3_fix.py', 'EXP-0109',
         None,
         ['constraint-satisfaction', 'energy-distance', 'energy-V-raw', 'energy-U-signed']),
        ('q3_transfer', 'q3_transfer_fix.py', 'EXP-0110',
         source / 'outputs/q3/transfer_metrics.json',
         ['nonincrease-rate', 'transfer-energy', 'qp-status-optimal',
          'qp-max-primal-residual', 'qp-max-stale-halfspace-residual']),
    ]
    for role, name, historical_id, reference, keys in targets:
        out = root / 'experiments' / historical_id
        out.mkdir(parents=True)
        (out / 'LOCAL-ONLY.json').write_text(json.dumps({
            'historical_layout_label': historical_id,
            'not_a_registered_plugin_experiment': True,
            'actual_run_date': manifest['started_at'],
        }, indent=2) + '\n')
        run_env = dict(env, MODELING_EXPERIMENT_DIR=str(out))
        command = [sys.executable, str(root / 'src' / name), '--repeat', 'all']
        start = time.monotonic()
        proc = subprocess.run(command, cwd=root, env=run_env,
                              capture_output=True, text=True, timeout=1800)
        elapsed = time.monotonic() - start
        (logs / (role + '.stdout.log')).write_text(proc.stdout)
        (logs / (role + '.stderr.log')).write_text(proc.stderr)
        metric_path = out / 'metrics.json'
        if not metric_path.exists():
            metric_path = out / 'transfer_metrics.json'
        produced = json.loads(metric_path.read_text()) if metric_path.exists() else {}
        expected = references[role]['metrics']
        comparisons = {}
        for key in keys:
            got, want = produced.get(key), expected.get(key)
            delta = abs(float(got) - float(want)) if got is not None and want is not None else None
            passed = delta is not None and (delta <= 1e-9 or delta <= 1e-6 * max(abs(float(want)), 1e-12))
            comparisons[key] = {'produced': got, 'reference': want,
                                'absolute_delta': delta, 'passed': passed}
        record = {'role': role, 'historical_layout_label': historical_id,
                  'source': 'src/' + name, 'command': command,
                  'exit_code': proc.returncode, 'elapsed_seconds': elapsed,
                  'reference': references[role]['derivation'],
                  'reference_files': references[role]['files'],
                  'comparisons': comparisons,
                  'passed': proc.returncode == 0 and all(v['passed'] for v in comparisons.values()),
                  'stdout_tail': proc.stdout.splitlines()[-5:],
                  'stderr_tail': proc.stderr.splitlines()[-5:]}
        manifest['runs'].append(record)
        (result_dir / 'reproduction.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({'role': role, 'exit': proc.returncode, 'passed': record['passed'],
                          'seconds': round(elapsed, 2)}, ensure_ascii=False), flush=True)
    manifest['all_passed'] = all(r['passed'] for r in manifest['runs'])
    manifest['finished_at'] = datetime.datetime.now().astimezone().isoformat()
    (result_dir / 'reproduction.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    return 0 if manifest['all_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
