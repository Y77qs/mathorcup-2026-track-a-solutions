# 冻结主模型的本地复现与收尾核验

2026-10-29 已真实重跑问题一、问题二、问题三生成、问题三迁移的全部 3 次重复。问题二每次重复均执行 500 次风格分层 bootstrap。未修改主模型、超参数、冻结数据划分或评价定义，未在原建模插件台账登记新实验。

## 本次实际完成

| 角色 | 实际耗时 | 主指标 | 与冻结 v6.2 指标的最大绝对差 |
| --- | ---: | --- | ---: |
| Q1 | 3.24 秒 | A/F30 MAE 0.35929156588219174 | 1.67e-16 |
| Q2 | 97.30 秒 | 方法间 Jaccard 0.2091111111111111 | 2.78e-17 |
| Q3 生成 | 70.88 秒 | 归一化 V 0.8726874826148657 | 5.33e-15 |
| Q3 迁移 | 8.06 秒 | 转移 V 2.079886135191688 | 4.44e-16 |

- 20 个整表比较全部通过，覆盖 1,794,600 个有限数值单元格；最大单元格绝对差 5.57e-10（原生成谱的极端坐标处），低于声明的 1e-9 表格容差。迁移表用 1e-8 容差。
- 包含 Q1 四模型 150,000 行长表、750 行主候选预测、3 次重复各 4 张 Q2 榜、Q3 生成谱、感官画像、约束、迁移谱与迁移约束。Q2 历史别名 `alternative_rank4` 与规范别名 `alternative_first_valid` 的同义关系另行检查。
- 5 个数学合成算例通过；Q3 原有已知答案测试 91 通过、0 失败。9 个外折无训练/测试交叠，每次重复的 250 个测试样本各出现一次。
- 原 v6.2 根目录 270 项、支撑目录 261 项 SHA256SUMS 均通过；原模型源码复制逐字节一致。
- Q3 的 `q3_v62_diagnostics.py` 和 `q3_v62_answer_tables.py` 已从本次新生成产物实际执行成功（分别 18.21 秒、0.43 秒）；诊断脚本全部 54 条断言通过，重建了同锚点消融、极端坐标敏感性和三张实体答案表。
- 原 v6.2 论文构建器的三组表格、论文 Markdown、表格同步与 Pandoc/TeX 转换共 6 步通过。本次模型核验没有再次编译该旧版 PDF；最终修订论文由另外的论文构建入口负责。

证据见 `results/reproduction.json`、`artifact-comparison.json`、`q3-oracle.json`、`acquisition.json`。初次比较使用了绘图专用的裁剪参照，缺少 Q2 Jaccard 字段和 Q3 metrics 文件；原诊断保存在 `reproduction-initial-reference-diagnostic.json`。其后参照独立改从 v6.2 冻结 CSV 推导，未编辑实际运行输出，也没有为比较输入缺失而重复训练。

## 第三人如何重跑

本次实测环境为 Python 3.13.7、NumPy 2.4.4、pandas 3.0.2、SciPy 1.17.1、matplotlib 3.10.9；核心四角色不需要 sklearn/openpyxl。本次确认环境清单见 `requirements-confirmed.txt`。原工程 requirements.txt 是队友旧环境的声明，并非本机已安装版本。

在最终支撑包根目录运行（`PYTHON` 替换为自己的解释器路径）：

```bash
PYTHON=python3
"$PYTHON" reproduction/scripts/run_core_reproduction.py \
  --source-root model \
  --raw-root '/原赛题附件目录' \
  --run-root '/新的可写目录/local-model-run'
"$PYTHON" reproduction/scripts/audit_completed_runs.py \
  --source-root model \
  --run-root '/新的可写目录/local-model-run'
```

`--raw-root` 中须含主办方原附件 `2.csv`、`6.csv`。脚本在复制到本次运行目录前核对完整 SHA256；原始赛题附件不放入提交压缩包。清洗数据、冻结划分、名称对齐表来自 `model/data/`。名称对齐的旧路径仅复制一个内容相同的别名文件，模型代码不改。

运行目录必须不存在，避免混入上轮输出；不提供 `--run-root` 时创建新的带时间目录。运行产生的 `verification/reproduction.json` 与整表核验结果都写入新运行目录，不覆盖本包已冻结的核验记录。`experiments/EXP-xxxx` 仅沿用历史目录布局，内含 `LOCAL-ONLY.json`，不是新注册的插件实验。

`run_core_reproduction.py` 不依赖历史 experiments/、旧电脑路径、建模插件或本聊天。运行后原脚本直接写出完整数值产物。`results/generated-output-manifest.json` 记录本次实际生成文件的哈希；提交包可保留日志与清单，不必重复放入本地 200 MB 的 bootstrap 重跑副本。

## 入口与历史脚本的范围

主模型的实际导入闭包是 `q1_fix.py`、`q2_fix.py`、`q3_fix.py`、`q3_transfer_fix.py`、`q1_lib.py`、`q2_lib.py`、`q3_lib.py`、`q_common.py`、`target_columns.py`、`v6_common.py`，共 10 个文件。全部随附模型 Python 文件为 55 个，另有 8 个旧论文构建 Python 文件；文件存在不表示它参与了最终主模型。完整清单在 `results/actual-code-inventory.json`。

原 `src/q2_v62_regen.py` 是修复旧 bug 快照的一次性迁移脚本，故意断言“修复前有 34 条重合”。它对当前已经修正的主模型新输出会拒绝执行，不能列为当前完整重跑的必需步骤。本次实际拒绝记录在 `postprocessing-reproduction.json` 与日志，不能把该历史前置条件失败说成当前 Q2 模型失败。当前 12 张新榜与冻结 v6.2 清洁榜已经逐格比较通过。

原 `model/build/build_all.sh` 是 v6.2 历史论文构建入口，末尾依赖包外 `.rework/pdf_audit.py` 且会吞掉该审计错误；它不负责重建本轮修订的最终论文，也不重跑主模型。不要用这个旧入口覆盖修订论文。

## 这次没有完成或不能证明的事项

这次没有重新执行历史稳健性注册、Q1 半 lambda 扰动实验或重建插件台账，也没有跑所有 55 个历史/辅助脚本。已完成的是当前主协议、整表数值、数据划分和已知答案核验。没有独立外部验证集、迁移后感官标签或真实酿造试验；确定性重现不等于独立实现，也不能证明团队核心工作由人工独立完成。工具具体型号、历史重要交互、真实人工贡献与签名仍须按实际情况提供。

`../provenance/CORRECTION-MANIFEST.json` 给出已同步到model的旧支撑摘要纠正清单，包括陈旧的约束计数、旧生成/迁移指标和误粘的稳健性说明。`samples_raw.csv` 是本次真实生成的投影前谱，属于结果而非原始赛题附件。原文件应保存在 provenance，再将纠正副本同步到最终工程。
