# MCB2604237 · A题支撑材料

这是当前论文提交准备稿对应的完整工程集合。主模型保留；本轮补充全源码附录、透明AI披露、运行封装、真实重跑验证及陈旧摘要修正。

## 目录及唯一入口

- `model/`：v6.2完整模型代码、清洗/冻结划分数据与输出；主程序只改AI注释，Python AST与原件相同。当前摘要修正另列清单。
- `paper/`：当前唯一修订稿的`main.tex`、完整`source_appendix.tex`及10张图所用资源。
- `build_current_paper.py`：当前论文构建入口，自动更新随包全部程序的完整源码附录并编译两次。
- `paper-revision/`：上一轮文字、表格和图形修订脚本及冻结重绘数据。
- `reproduction/`：本轮核心计算重跑入口、环境、命令、日志及对照结果。其历史EXP编号只是本地目录标签，不是新注册的插件实验。
- `verification/`：论文结构/源码/数值及版式检查证据。
- `AI说明/AI工具使用详情说明.pdf`：已知AI参与、关键交互和待确认信息的事实核对版。
- `provenance/`：旧源码、旧摘要、旧AI材料和原始哈希，只供追溯，不作为当前人工事实或当前实验摘要。

## 构建当前论文

需要Python、pypdf、XeLaTeX及字体Times New Roman / Arial / Menlo / Songti SC。在本目录运行：

```sh
python build_current_paper.py
```

生成`paper/main.pdf`；结构检查写入`verification/paper-build.json`。程序会检查编译错误、缺字、溢出、页码和正文30页界限。第一次编译的引用提醒应由第二次消除。

不要用`model/build/build_all.sh`构建当前论文：该脚本保留用于旧v6.2来源追溯，曾引用包外`.rework/pdf_audit.py`；会生成旧版稿件。本套当前入口不依赖该脚本或外部插件。

AI真实记录补齐后，可运行`python z_build_ai_disclosure.py`从`AI说明/`两份Markdown重建AI详情PDF（另需pandoc）；生成后须重新检查版式与事实。

## 核心计算复跑

本轮实测Python3.13.7、NumPy2.4.4、pandas3.0.2、SciPy1.17.1、Matplotlib3.10.9。原工程的`model/requirements.txt`保留原声明；实测配置另见`requirements-reproduced.txt`。本次四主程序不需要scikit-learn。安装依赖后，在本目录执行：

```sh
python reproduction/scripts/run_core_reproduction.py --source-root model --raw-root /实际路径/原题附件目录 --run-root /实际路径/新的复跑目录
```

原题附件目录需含原始`2.csv`和`6.csv`，入口验证SHA-256。这两份原始附件不重复打入提交附件；请从题目材料原包另行提供。清洗后的三问主输入与固定划分已在`model/data/`中。运行目录必须是新路径，入口拒绝覆盖已有实验。

该命令在新目录执行三重复Q1、Q2的三重复每次500次分层bootstrap、Q3生成和迁移，比较冻结输出。参数、参考指标和容差随结果记录，不把脚本执行成功误写成晋级保证。详细边界与其余检验见`reproduction/README.md`。

## 结果和AI记录的解释

主结果对应论文：Q1 A/F30 MAE .3593（中位数.3982）、全50维.3505（.3919）；Q2平均Jaccard .2091、方向一致率.9817；Q3生成.8727未胜过重采样.8137；QP迁移2.0799，同锚点直接投影2.0903，增量约.50%。

新注释和AI披露不声称队员已完成尚未确认的人工检查。准确工具型号、历史交互和核心独立贡献仍待队友核实；必须如实更新后才可认定完成正式材料。本文档和GitHub归档均不代表平台提交成功。
