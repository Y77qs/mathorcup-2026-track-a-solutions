#!/usr/bin/env python3
"""Build the fact-check AI disclosure PDF from retained Markdown sources.

AI assistance: OpenAI Codex, GPT-6 family (exact identifier not fully
retained), OpenAI, 2026-10-29. Generates disclosure layout and records
mechanical QA; it does not certify human contributions or missing metadata.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import shutil
import re
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent / "AI说明"
BUILD = ROOT / "pdf-build"
BUILD.mkdir(exist_ok=True)
detail = ROOT / "AI工具使用详情说明.md"
interactions = ROOT / "AI关键交互记录.md"
combined = (
    detail.read_text(encoding="utf-8")
    + "\n\n\\clearpage\n\n"
    + interactions.read_text(encoding="utf-8")
)
source = BUILD / "ai-disclosure-combined.md"
source.write_text(combined, encoding="utf-8")
header = BUILD / "header.tex"
header.write_text(r"""
\usepackage{xeCJK}
\setCJKmainfont[AutoFakeBold=2]{Songti SC}
\setCJKsansfont[AutoFakeBold=2]{Songti SC}
\setCJKmonofont{Songti SC}
\usepackage{fancyhdr}
\usepackage{lastpage}
\usepackage{xurl}
\usepackage{microtype}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.45em}
\setlength{\emergencystretch}{3em}
\renewcommand{\arraystretch}{1.16}
\AtBeginEnvironment{longtable}{\small}
\pagestyle{fancy}
\fancyhf{}
\fancyfoot[L]{\footnotesize AI使用事实核对版 · MCB2604237}
\fancyfoot[R]{\footnotesize \thepage\ / \pageref{LastPage}}
\renewcommand{\headrulewidth}{0pt}
\renewcommand{\footrulewidth}{0.2pt}
\setlength{\footskip}{24pt}
""", encoding="utf-8")
tex = BUILD / "ai-disclosure.tex"
cmd = [
    shutil.which("pandoc") or "pandoc", str(source), "--standalone", "--from=markdown+pipe_tables+raw_tex",
    "--to=latex", "-o", str(tex), "--include-in-header", str(header),
    "-V", "documentclass=article", "-V", "fontsize=10pt",
    "-V", "mainfont=Times New Roman", "-V", "sansfont=Arial", "-V", "monofont=Menlo",
    "-V", "geometry:a4paper", "-V", "geometry:top=18mm", "-V", "geometry:bottom=21mm",
    "-V", "geometry:left=18mm", "-V", "geometry:right=18mm", "-V", "linestretch=1.08",
    "-V", "colorlinks=true", "-V", "linkcolor=blue", "-V", "urlcolor=blue",
]
subprocess.run(cmd, check=True, capture_output=True, text=True)
# xurl provides legal wrapping points for long hashes, commit IDs and paths.
# Preserve the text while avoiding unbreakable monospace cells in tables.
generated_tex = tex.read_text(encoding="utf-8")
def wrap_literal(match):
    content = match.group(1)
    if any(ord(char) > 127 for char in content) or r"\ " in content or " " in content:
        return match.group(0)
    content = content.replace(r"\_", "_").replace(r"\%", "%").replace(r"\#", "#")
    return r"\nolinkurl{" + content + "}"
generated_tex = re.sub(r"\\texttt\{([^{}]*)\}", wrap_literal, generated_tex)
def adjust_table(match):
    table = match.group(0)
    spec, body = table.split(r"\toprule", 1)
    head = body.split(r"\endhead", 1)[0]
    if "用户提示原文" in head:
        weights = iter(["0.08", "0.42", "0.50"])
    elif "回复/执行内容摘要" in head:
        weights = iter(["0.08", "0.26", "0.34", "0.32"])
    elif "未闭合事实" in head:
        weights = iter(["0.12", "0.35", "0.53"])
    elif "工具" in head and "已能确认的信息" in head:
        weights = iter(["0.24", "0.38", "0.38"])
    else:
        return table
    spec = re.sub(r"\\real\{[0-9.]+\}", lambda m: r"\real{" + next(weights) + "}", spec)
    return spec + r"\toprule" + body
generated_tex = re.sub(r"\\begin\{longtable\}.*?\\end\{longtable\}", adjust_table, generated_tex, flags=re.S)
tex.write_text(generated_tex, encoding="utf-8")
logs = []
for run in (1, 2):
    result = subprocess.run([
        shutil.which("xelatex") or "xelatex", "-no-shell-escape", "-interaction=nonstopmode",
        "-halt-on-error", tex.name,
    ], cwd=BUILD, capture_output=True, text=True)
    logs.append(result.stdout + result.stderr)
    (BUILD / f"compile-{run}.log").write_text(logs[-1], encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"XeLaTeX pass {run} failed: " + logs[-1][-5000:])
pdf = ROOT / "AI工具使用详情说明.pdf"
pdf.write_bytes(tex.with_suffix(".pdf").read_bytes())
reader = PdfReader(pdf)
pages = [(page.extract_text() or "") for page in reader.pages]
for index, content in enumerate(pages, 1):
    (BUILD / f"page-{index:02}.txt").write_text(content, encoding="utf-8")
text = "\n".join(pages)
required = ["AI工具使用详情说明", "AI关键交互记录", "MCB2604237", "事实核对版",
            "你来完成剩余任务", "我找队友确认", "AST", "64", "AI-F07"]
missing = [phrase for phrase in required if phrase not in text.replace(" ", "")]
warnings = re.findall(r"(?:Overfull \\[hv]box|Missing character|undefined references|Rerun to get).*", logs[-1])
qa = {
    "status": "built_pending_visual_QA",
    "kind": "fact-check-draft_not_fully_confirmed_submission",
    "pdf": str(pdf), "pages": len(reader.pages), "bytes": pdf.stat().st_size,
    "sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
    "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (detail, interactions)},
    "required_text_missing": missing,
    "compile_warnings": warnings,
    "human_contribution_or_missing_history_certified": False,
}
(ROOT / "pdf-qa.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(qa, ensure_ascii=False, indent=2))
if missing or warnings:
    raise SystemExit("PDF needs repair before visual QA")
