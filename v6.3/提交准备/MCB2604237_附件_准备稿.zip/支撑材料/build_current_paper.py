#!/usr/bin/env python3
"""Build this revision, including every bundled active program in appendix C.
AI assistance: OpenAI Codex, GPT-6 family (exact serving model pending),
OpenAI, 2026-10-29. Human review is not certified by this program.
"""
from pathlib import Path
import argparse, hashlib, json, re, shutil, subprocess

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory-only',action='store_true')
    args=parser.parse_args()
    paper=ROOT/'paper'
    records=[]
    for file in sorted(ROOT.rglob('*')):
        relative=file.relative_to(ROOT)
        if file.is_file() and file.suffix in {'.py','.sh','.js','.m'} and not set(relative.parts)&{'provenance','__pycache__'}:
            records.append({'file':relative.as_posix(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
                            'bytes':file.stat().st_size,'lines':len(file.read_text().splitlines())})
    appendix=[r'\fvset{fontsize=\fontsize{7.2}{8.6}\selectfont,breaklines=true,breakanywhere=true,breakindent=0pt,numbers=left,numbersep=4pt,xleftmargin=15pt,tabsize=4}',
              r'\renewcommand{\theFancyVerbLine}{\tiny\arabic{FancyVerbLine}}']
    for i,row in enumerate(records,1):
        appendix.extend([r'\subsection*{C.'+str(i)+r'\quad \path{'+row['file']+'}}',
                         r'{\footnotesize SHA-256：\texttt{'+row['sha256'][:32]+r'}\texttt{'+row['sha256'][32:]+r'}。}',
                         r'\VerbatimInput{../'+row['file']+'}'])
    (paper/'source_appendix.tex').write_text('\n'.join(appendix)+'\n')
    (ROOT/'code-inventory.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    if args.inventory_only:
        print(json.dumps({'programs':len(records),'lines':sum(x['lines'] for x in records)}));return
    engine=shutil.which('xelatex')
    if engine is None:raise SystemExit('xelatex is required; install TeX Live and the documented fonts.')
    verification=ROOT/'verification';verification.mkdir(exist_ok=True)
    logs=[]
    for number in (1,2):
        proc=subprocess.run([engine,'-no-shell-escape','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=paper,text=True,capture_output=True)
        log=verification/f'paper-compile-{number}.log';log.write_text(proc.stdout+proc.stderr)
        logs.append(str(log.relative_to(ROOT)))
        if proc.returncode:raise SystemExit(f'Compilation failed; inspect {log}')
    log=(verification/'paper-compile-2.log').read_text()
    errors=[name for name,pattern in [('overfull',r'Overfull'),('missing glyph',r'Missing character:'),('undefined',r'undefined'),('rerun',r'Rerun to get'),('TeX error',r'^! ')] if re.search(pattern,log,re.M|re.I)]
    if errors:raise SystemExit('Paper compilation checks failed: '+str(errors))
    from pypdf import PdfReader
    pdf=paper/'main.pdf';reader=PdfReader(pdf)
    texts=[p.extract_text() or '' for p in reader.pages]
    appendix_page=next(i+1 for i,t in enumerate(texts) if i>1 and '附录A支撑材料' in re.sub(r'\s+','',t))
    body_pages=appendix_page-3
    if body_pages>30:raise SystemExit(f'Body page limit exceeded: {body_pages}')
    footers=[int(t.strip().splitlines()[-1]) for t in texts[2:]]
    if footers!=list(range(1,len(texts)-1)):raise SystemExit('Nonconsecutive printed page numbers')
    report={'programs':len(records),'source_lines':sum(x['lines'] for x in records),'total_pages':len(texts),
            'body_including_references_and_AI_pages':body_pages,'body_within_30':True,
            'continuous_centered_footer_numbers':True,'compile_errors':errors,
            'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'compile_logs':logs,
            'scope':'PDF structure/build checks; not human review or competition compliance certification'}
    (verification/'paper-build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
