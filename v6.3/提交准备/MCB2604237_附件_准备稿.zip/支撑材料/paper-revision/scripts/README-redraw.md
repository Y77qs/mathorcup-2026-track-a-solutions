# 七张图的便携重绘

保持 `scripts/redraw_figures.py` 与相邻的 `repro-data/` 所在根目录关系，即可从任意工作目录运行脚本。默认输出 `project/figures/`，逐图元数据写入 `results/figure_revision.json`。

```sh
python3 scripts/redraw_figures.py
python3 scripts/redraw_figures.py --only 1
python3 scripts/redraw_figures.py --data-dir repro-data --output-dir project/figures --metadata-dir results
```

依赖 Python 3、numpy、pandas、scipy、matplotlib。英文字体须有 Times New Roman；中文首选 SimSun，本次在 macOS 使用已探测的 Songti SC 回退。字体缺失时会明确失败；脚本不会联网下载字体或数据。选择图4或5会同时重新生成这两张相关网络图。

每次出图先验证 `repro-data/manifest.json` 中的冻结文件SHA256。数据经过列或JSON键投影，保留了绘图所需的全部行；各子集来源hash和提取规则均在manifest中。图4重算冻结200行训练数据的Spearman相关系数，其余图的具体算术见manifest.figure_operations。不会拟合预测模型、重新bootstrap、运行生成器或求解QP。

本次验证：便携输入重新生成7张图，PNG字节与修订项目对应图一致，所有保留的科学数值摘要一致；图1标题按要求改为“排序第1–25项”和“排序第26–50项”。
