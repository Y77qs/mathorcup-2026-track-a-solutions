# AI辅助：OpenAI Codex / GPT-6系列（精确型号待核），开发机构OpenAI。
# 使用日期：2026-10-28至2026-10-29；用于论文/图表修订和自动检查。
# 实际人工采纳、修改及核验记录见AI工具使用详情说明；不预先认证人工完成。
"""Build reviewable v6.2 paper sources from the unchanged frozen baseline.

Only prose corrections, table layout and evidence-preserving plots are applied.
Compile the generated project/main.tex separately with XeLaTeX.
"""
from pathlib import Path
import hashlib
import json
import re

from prose_fixes import apply as fix_prose
from table_fixes import apply as fix_tables

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'baseline'
PROJECT = ROOT / 'project'
RESULTS = ROOT / 'results'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    expected = '8c9a9e3d64b54c2d812724f6a3c994b8c25275bbd1371f1dca21b3071bcdeab3'
    assert sha(BASE / 'paper_final.tex') == expected
    text = (BASE / 'paper_final.tex').read_text()
    text, prose = fix_prose(text)
    text, tables = fix_tables(text)
    # Historical source hashes are evidence IDs, not hashes of the revised blocks.
    text = text.replace('%% ---- build provenance, injected with -V buildmeta=... ----',
        '%% ---- original frozen build provenance (historical, not this revision) ----')
    text = re.sub(r'%% table-id: ([^\n]+?) sha256:',
                  r'%% baseline-table-id: \1 baseline-source-sha256:', text)
    text = text.replace('%% header.tex — page/table formatting for the FINAL v6.2 paper (plugin-free)',
        '%% Revised standalone v6.2 paper; build provenance in ../results/revision_build.json')
    text = text.replace(r'pdfcreator={build-paper.py}', r'pdfcreator={XeLaTeX; v6.2 local revision}')
    text = re.sub(r'\.\./figures/confirmatory_v2/([^}\s]+)', r'figures/\1', text)
    manifest = json.loads((RESULTS / 'figure_revision.json').read_text())
    # Captions state the statistical scope and avoid causal/validation overclaims.
    overrides = {
        '1': r'图低秩模型逐目标相对误差改善，按数值从小到大排序后分为两列。改善为\(1-\mathrm{MAE}_{\text{模型}}/\mathrm{MAE}_{\text{中位数}}\)，均取同一内部嵌套验证的折外预测；斜线为其他20维，12维劣于中位数基线。',
        '4': r'训练数据的Spearman相关网络（\(|\rho|\geq0.5\)）：231节点、732边、51分量。左图为最大分量（172节点），右图为全部分量规模；颜色表示变量类别，大小表示节点度。该全训练集描述图不替代折内建图，相关边不表示因果。',
        '5': r'附件2的描述性Spearman相关网络（\(|\rho|\geq0.5\)）：231节点、645边、52分量，最大分量175节点。节点位置读取已存\texttt{nodes.csv}；颜色表示变量类别，大小表示节点度。该全样本网络不进入预测验证。',
        '9': r'五种迁移策略的存储位移、标准化\(z\)位移和约束残差，编号见公共图例。每策略99条迁移、3762条约束记录；图(e)按残差大于\(10^{-8}\)计数，图(f)只展示这些超限记录。位移与残差分别描述改动大小和约束违反；存储单位随变量而异，\(z\)空间无量纲。',
        '10': r'四组预定扰动的绝对极差与相对极差分别展示。Q1计划含3组，Q2及Q3生成、迁移计划各含2组，补充块未并入；红线为各自相对极差上限。迁移不增率两组均为1，零极差来自指标饱和，不能解释为性能提升。',
    }
    figure_changes = []
    for num, meta in manifest['figures'].items():
        old = meta['old']
        pattern = (r'\\includegraphics\[[^\]]+\]\{figures/' + re.escape(old) +
                   r'\}\s*\\captionof\{figure\}\{[^\n]+\}')
        assert len(re.findall(pattern, text)) == 1, old
        path = 'figures/' + Path(meta['new_pdf']).name
        caption = overrides.get(num, meta['suggested_caption'])
        new = (r'\includegraphics[' + meta['suggested_tex_size'] + ']{' + path + '}\n' +
               r'\captionof{figure}{' + caption + '}')
        text = re.sub(pattern, lambda _: new, text)
        text = text.replace('%% figure-src: figures/' + old,
                            '%% revised-figure: ' + path)
        figure_changes.append({'figure':int(num), 'path':path, 'caption':caption,
                               'size':meta['suggested_tex_size']})
    assert len(re.findall(r'\\captionof\{figure\}', text)) == 10
    for path in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}', text):
        assert (PROJECT/path).is_file(), path
    PROJECT.mkdir(exist_ok=True)
    (PROJECT/'main.tex').write_text(text)
    appendix = (BASE/'source_appendix.tex').read_text()
    assert appendix.count(r'\u3000') == 5
    fixed_appendix = appendix.replace(r'\u3000',r'\quad ')
    blocks = lambda s: re.findall(r'\\begin\{Verbatim\}.*?\\end\{Verbatim\}',s,re.S)
    assert len(blocks(appendix)) == 5
    assert blocks(appendix) == blocks(fixed_appendix)
    (PROJECT/'source_appendix.tex').write_text(fixed_appendix)
    (RESULTS/'prose_changes.json').write_text(json.dumps(prose,ensure_ascii=False,indent=2))
    (RESULTS/'table_changes.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2))
    build = {'baseline_tex_sha256':expected,
             'baseline_commit':'c42dae7849a52f08162545a83f52ea82b0c7e47d',
             'main_tex_sha256':sha(PROJECT/'main.tex'),
             'appendix_sha256':sha(PROJECT/'source_appendix.tex'),
             'prose_change_groups':len(prose),'table_change_groups':len(tables),
             'figure_changes':figure_changes,
             'appendix_heading_fixes':5,'all_five_code_blocks_identical':True,
             'scope':'Paper revision from frozen evidence; no model training or scientific-results rerun.'}
    (RESULTS/'revision_build.json').write_text(json.dumps(build,ensure_ascii=False,indent=2))
    print(json.dumps({'prose':len(prose),'tables':len(tables),'figures':len(figure_changes),
                      'appendix_headings':5,'code_blocks_unchanged':True}))

if __name__ == '__main__':
    main()
