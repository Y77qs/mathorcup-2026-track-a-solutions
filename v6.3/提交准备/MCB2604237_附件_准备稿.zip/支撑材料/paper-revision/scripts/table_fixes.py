# AI辅助：OpenAI Codex / GPT-6系列（精确型号待核），开发机构OpenAI。
# 使用日期：2026-10-28至2026-10-29；用于论文/图表修订和自动检查。
# 实际人工采纳、修改及核验记录见AI工具使用详情说明；不预先认证人工完成。
"""Portrait table layout patch for v6.2. No model result is recalculated.

apply(text) returns (patched_tex, list_of_change_records). The original table
numbers/labels and all reported data cells are retained. Run as a script to
write an isolated preview and a layout change log.
"""
from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import re


def _block(text, env, label):
    matches = [m for m in re.finditer(r"\\begin\{" + env + r"\}.*?\\end\{" + env + r"\}", text, re.S)
               if r"\label{tab:" + label + "}" in m.group()]
    if len(matches) != 1:
        raise ValueError(f"expected one {env} block for {label}: {len(matches)}")
    return matches[0]


def _rows(block):
    """Get data rows of a simple tabular (all input data rows are single-line)."""
    body = block.split(r"\midrule", 1)[1].split(r"\bottomrule", 1)[0]
    return [[c.strip() for c in line.strip()[:-2].split(" & ")]
            for line in body.splitlines() if line.strip().endswith(r"\\") and " & " in line]


def _caption(block):
    return re.search(r"\\caption(?:of\{table\})?\{([^\n]+?)\}\\label\{([^}]+)\}", block).groups()


def _note(block):
    return re.search(r"\\begin\{tablenote\}(.*?)\\end\{tablenote\}", block, re.S).group(1)


def _num_cells(rows):
    return Counter(v for row in rows for v in row if re.fullmatch(r"\d+(?:\.\d+)?", v))


def _row(cells):
    return " & ".join(cells) + r" \\" + "\n"


def _portrait_grades(block):
    rows = _rows(block)
    assert len(rows) == 5 and all(len(r) == 11 for r in rows)
    title, label = _caption(block)
    metrics = [r[:4] for r in rows[:4]]
    counts = [[r[0].replace("参照等级（真实标签同映射）", "参照标签")] + r[4:] for r in rows]
    assert _num_cells(rows) == _num_cells(metrics + counts)
    s = r"""\begin{bptable}
\setcounter{table}{2}
% Revision: portrait; all original grade counts remain below the summary.
\captionof{table}{""" + title + r"}\label{" + label + r"}" + "\n" + r"""\small
\begin{tabular}{@{}lrrr@{}}
\toprule
模型 & 等级 MAE & 整级一致率 & 二次加权 $\kappa$ \\
\midrule
""" + "".join(_row(r) for r in metrics) + r"""\bottomrule
\end{tabular}
\par\smallskip
\begin{tabular}{@{}lrrrrrrr@{}}
\toprule
模型或参照 & 等级0 & 等级1 & 等级2 & 等级3 & 等级4 & 等级5 & 等级6 \\
\midrule
""" + "".join(_row(r) for r in counts) + r"""\bottomrule
\end{tabular}
\begin{tablenote}""" + _note(block) + r"""\end{tablenote}
\end{bptable}"""
    return s, {"table": 3, "action": "portrait_two_panels", "numeric_cells_preserved": sum(_num_cells(rows).values()), "original_rows": 5}


def _portrait_scores(block, number):
    rows = _rows(block)
    assert len(rows) == 10 and all(len(r) == 11 for r in rows)
    title, label = _caption(block)
    paired = [[r[0]] + [f"{r[i]}/{r[i+5]}" for i in range(1, 6)] for r in rows]
    # Check every integer through its source row, rather than relying on a PDF
    # string comparison after the prediction/reference cells have been paired.
    recovered = [[r[0]] + [c.split("/")[0] for c in r[1:]] + [c.split("/")[1] for c in r[1:]] for r in paired]
    assert recovered == rows
    s = r"\begin{bptable}" + "\n" + rf"\setcounter{{table}}{{{number-1}}}" + "\n" + r"\captionof{table}{" + title + r"}\label{" + label + r"}" + "\n" + r"""\small
\begin{tabular}{@{}lccccc@{}}
\toprule
样本 & 麦芽总体 & 酒花总体 & 柑橘 & 酯香总体 & 乙酸异戊酯 \\
\midrule
""" + "".join(_row(r) for r in paired) + r"""\bottomrule
\end{tabular}
\begin{tablenote}注：每个单元为“预测/参照”，顺序固定。""" + _note(block).removeprefix("注：") + r"""\end{tablenote}
\end{bptable}"""
    return s, {"table": number, "action": "portrait_prediction_reference_pairs", "samples": 10, "paired_dimensions": 5, "original_numeric_cells_preserved": 100}


def _portrait_robustness(block):
    rows = _rows(block)
    assert len(rows) == 4 and all(len(r) == 10 for r in rows)
    title, label = _caption(block)
    names = ["问题一", "问题二", "问题三生成", "问题三迁移"]
    simplified = []
    for name, r in zip(names, rows):
        simplified.append([name, r[2], r[3], r[4], r[5], r[6].replace("（relative-\\allowbreak{}range）", "").replace("（min-\\allowbreak{}value）", "") + "；" + r[7]])
    widths = [.115, .255, .105, .105, .105, .315]
    spec = "@{}" + "".join(r">{\raggedright\arraybackslash}p{\dimexpr " + f"{x:.3f}" + r"\linewidth-6pt\relax}" for x in widths) + "@{}"
    # Input widths slightly exceeded the text block; the compact table must not.
    assert abs(sum(widths) - 1.) < 1e-12
    s = r"\begin{bptable}" + "\n" + r"\setcounter{table}{17}" + "\n" + r"\captionof{table}{" + title + r"}\label{" + label + r"}" + "\n" + r"\small" + "\n" + r"\begin{tabular}{" + spec + "}\n" + r"""\toprule
对象 & 计划执行值 & 补充块 & 绝对极差 & 相对极差 & 规则与判定 \\
\midrule
""" + "".join(_row(r) for r in simplified) + r"""\bottomrule
\end{tabular}
\begin{tablenote}""" + _note(block) + r"""\par\smallskip
\textbf{逐项指标、扰动与限制：}\par
"""
    for name, r in zip(names, rows):
        s += r"\textbf{" + name + r"}：" + r[1] + "；" + r[8] + "。" + r[9] + r"\par" + "\n"
    s += r"\end{tablenote}" + "\n" + r"\end{bptable}"
    # Every original scalar, plan-value string, supplementary value, measure,
    # perturbation and limitation remains verbatim (upper-limit rule is reflowed).
    for r in rows:
        for i in (1, 2, 3, 4, 5, 8, 9):
            assert r[i] in s
    return s, {"table": 18, "action": "portrait_numeric_summary_and_item_notes", "original_rows": 4, "all_original_metrics_values_methods_limitations_retained": True}


def _top3_layout(block):
    # Keep all candidates and statistics in the same five columns. Widen the
    # Chinese sensory dimension from 6.61% to 12.5% and give each rank a stable
    # second line for pi/S and direction/type. Do not invent chemical translations.
    original_rows = block.split(r"\endfoot", 1)[1].split(r"\end{longtable}", 1)[0]
    old_line = next(line for line in block.splitlines() if line.startswith(r"\begin{longtable}"))
    widths = [.125, .225, .225, .225, .200]
    spec = "@{}" + "".join(r">{\raggedright\arraybackslash}p{\dimexpr " + f"{x:.3f}" + r"\linewidth-6pt\relax}" for x in widths) + "@{}"
    block = block.replace(old_line, r"\begin{longtable}{" + spec + "}", 1)
    data = []
    for line in original_rows.splitlines():
        if not line.strip():
            continue
        cells = line.strip()[:-2].split(" & ")
        assert len(cells) == 5
        for i in (1, 2, 3):
            name, stats, kind = cells[i].split("｜")
            stats = stats.replace(r"\allowbreak{}", "")
            kind = kind.replace(r"\allowbreak{}", "")
            # pi/S and the direction/type remain unaltered. A deliberate line
            # break separates identifier text from numeric evidence.
            cells[i] = name + r"\newline " + stats + r"\allowbreak{}｜" + kind
        data.append(_row(cells))
    new_rows = "\n" + "".join(data)
    block = block.replace(original_rows, new_rows, 1)
    block = block.replace("单元格格式为“名称｜π/S｜方向·类型”", "第1–3位单元格分行显示名称与“π/S｜方向·类型”")
    # Ignore deliberate line breaks/soft wrapping in an exact data identity check.
    def normalize(v):
        return re.sub(r"\s+", "", v.replace(r"\allowbreak{}", "").replace(r"\newline", "").replace("｜", ""))
    assert normalize(original_rows) == normalize(new_rows)
    return block, {"table": 7, "action": "wider_dimension_and_deliberate_stat_lines", "dimensions": 20, "rank_candidates": 60, "all_candidates_pi_S_sign_type_alternatives_preserved": True}


def _keep_style_groups(block):
    before, rest = block.split(r"\endfoot", 1)
    body, after = rest.split(r"\end{longtable}", 1)
    lines = body.splitlines()
    data = [(i, line) for i, line in enumerate(lines) if " & " in line and line.strip().endswith(r"\\")]
    assert len(data) == 18
    for k, (i, line) in enumerate(data):
        # No break after the first five rows of each six-row style group. The
        # whole next style may start on a fresh page, rather than leaving a tail.
        if k % 6 != 5:
            lines[i] = line + "*"
    return before + r"\endfoot" + "\n".join(lines) + r"\end{longtable}" + after


def _continuation_heads(text):
    log = []
    count = 0
    def replace(m):
        nonlocal count
        block = m.group()
        count += 1
        # Number of columns = number of top-level header cells. Header bodies
        # may contain minipages but never an alignment ampersand within a cell.
        if r"\endfirsthead" in block:
            first, rest = block.split(r"\endfirsthead", 1)
            repeat, tail = rest.split(r"\endhead", 1)
            first_header = first.split(r"\toprule", 1)[1]
            ncol = first_header.split(r"\midrule", 1)[0].count(" & ") + 1
            caption = _caption(block)[0]
            marker = r"\multicolumn{" + str(ncol) + r"}{@{}l@{}}{\small 续表~\thetable\quad " + caption + r"}\\" + "\n"
            block = first + r"\endfirsthead" + "\n" + marker + repeat.lstrip() + r"\endhead" + tail
            log.append({"numbered": True, "caption": caption, "columns": ncol})
        else:
            # Pandoc unnumbered outline/data-summary tables already repeat the
            # head. Distinguish first head and use a descriptive continuation.
            start = block.index(r"\toprule")
            prefix = block[:start]
            first, tail = block[start:].split(r"\endhead", 1)
            ncol = first.split(r"\midrule", 1)[0].count(" & ") + 1
            names = {1: "任务与评价对象", 2: "数据类别与用途", 3: "评价协议", 4: "问题一候选设置", 10: "支撑材料长表索引"}
            title = names.get(count, "数据与说明")
            marker = r"\multicolumn{" + str(ncol) + r"}{@{}l@{}}{\small 续表：" + title + r"}\\" + "\n"
            block = prefix + first + r"\endfirsthead" + "\n" + marker + first + r"\endhead" + tail
            log.append({"numbered": False, "caption": title, "columns": ncol})
        return block
    text = re.sub(r"\\begin\{longtable\}.*?\\end\{longtable\}", replace, text, flags=re.S)
    return text, {"action": "continued_titles_and_repeated_heads", "tables": log, "longtable_count": count}


def apply(text):
    log = []
    for label, transformer in [
        ("q1-grades", _portrait_grades),
        ("q1-scores-aroma", lambda b: _portrait_scores(b, 4)),
        ("q1-scores-flavour", lambda b: _portrait_scores(b, 5)),
        ("rob-confirmatory", _portrait_robustness),
    ]:
        match = _block(text, "sidewaystable", label)
        new, item = transformer(match.group())
        text = text[:match.start()] + new + text[match.end():]
        log.append(item)
    match = _block(text, "bpLTsmall", "q2-core-top3")
    new, item = _top3_layout(match.group())
    text = text[:match.start()] + new + text[match.end():]
    log.append(item)
    match = _block(text, "bpLTsmall", "q3-profile-chem")
    new = _keep_style_groups(match.group())
    text = text[:match.start()] + new + text[match.end():]
    log.append({"table": 10, "action": "keep_each_six_row_style_together", "styles": 3, "numeric_changes": 0})
    text, item = _continuation_heads(text)
    log.append(item)
    assert r"\begin{sidewaystable}" not in text
    return text, log


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    result, changes = apply(args.input.read_text())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(result)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text(json.dumps({"scope": "table layout only; no model data changed", "changes": changes}, ensure_ascii=False, indent=2))
