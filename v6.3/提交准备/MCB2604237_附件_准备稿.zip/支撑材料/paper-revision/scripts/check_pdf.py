# AI辅助：OpenAI Codex / GPT-6系列（精确型号待核），开发机构OpenAI。
# 使用日期：2026-10-28至2026-10-29；用于论文/图表修订和自动检查。
# 实际人工采纳、修改及核验记录见AI工具使用详情说明；不预先认证人工完成。
"""Structural and evidence-preservation checks; visual QA is recorded separately."""
from pathlib import Path
import re, json, hashlib
from pypdf import PdfReader
from PIL import Image, ImageOps, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RESULTS=ROOT/'results'
PDF=ROOT/'project/main.pdf'
tex=(ROOT/'project/main.tex').read_text()
aux=(ROOT/'project/main.aux').read_text()
log=(ROOT/'results/compile-final.log').read_text()
reader=PdfReader(PDF)
texts=[p.extract_text() or '' for p in reader.pages]
for i,t in enumerate(texts,1):
    (RESULTS/f'page-{i:02d}.txt').write_text(t)
text_compact=[re.sub(r'\s+','',t) for t in texts]
appendix_a=next(i+1 for i,t in enumerate(text_compact) if i>1 and '附录A支撑材料' in t)
appendix_c=next(i+1 for i,t in enumerate(text_compact) if i>1 and '附录C核心源程序' in t)
reference=next(i+1 for i,t in enumerate(text_compact) if i>1 and '参考文献' in t)
ai=next(i+1 for i,t in enumerate(text_compact) if i>1 and 'AI工具使用声明' in t)
errors=[]
for p in [r'Overfull',r'Missing character:',r'undefined',r'^! ',r'Rerun to get']:
    if re.search(p,log,re.M|re.I): errors.append(p)
assert not errors,errors
table_labels=re.findall(r'\\newlabel\{tab:([^}]+)\}\{\{(\d+)\}\{(\d+)\}',aux)
assert len(table_labels)==20 and [int(x[1]) for x in table_labels]==list(range(1,21))
assert len(re.findall(r'\\captionof\{figure\}',tex))==10
assert not re.search(r'\\begin\{sidewaystable\}',tex)
assert not re.search(r'\\item\s+~',tex)
assert r'\u3000' not in (ROOT/'project/source_appendix.tex').read_text()
assert '231×750格' not in ''.join(text_compact)
assert not re.search(r'表\s+q3-',tex)
assert r'\$' not in tex
for t in text_compact[:appendix_c-1]:
    assert 'textbackslash' not in t and 'textasciicircum' not in t
    assert 'q3-profile-chem' not in t and 'q3-transfer-example' not in t
validation={
    'pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),
    'total_pages':len(texts),'reference_first_physical_page':reference,
    'AI_statement_physical_page':ai,'appendix_A_physical_page':appendix_a,
    'appendix_C_physical_page':appendix_c,
    'body_including_AI_last_printed_page':appendix_a-3,
    'appendices_excluded_from_body':True,
    'body_within_30_pages':appendix_a-3<=30,
    'table_count':20,'figure_count':10,
    'tables':[{'label':a,'number':int(b),'printed_page':int(c)} for a,b,c in table_labels],
    'no_overfull_missing_glyphs_undefined_refs_or_rerun_warnings':True,
    'no_rotated_tables':True,'no_empty_item':True,'appendix_headings_fixed':5,
    'no_visible_internal_table_IDs_or_escaped_math':True,
    'scientific_scope':'Result-preserving paper revision; not independent rerun of all support.'}
assert validation['body_within_30_pages'],validation
(RESULTS/'pdf-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
print(json.dumps(validation,ensure_ascii=False))

pages=sorted((RESULTS/'pages').glob('page-*.png'))
if pages:
    assert len(pages)==len(texts)
    for start in range(0,len(pages),6):
        canvas=Image.new('RGB',(1230,1190),'#e3e3e3')
        draw=ImageDraw.Draw(canvas)
        for k,p in enumerate(pages[start:start+6]):
            im=Image.open(p).convert('RGB');im.thumbnail((390,552))
            x=(k%3)*410+10;y=(k//3)*595+30
            canvas.paste(im,(x+(390-im.width)//2,y))
            draw.text((x,y-20),f'PDF page {start+k+1:02d}',fill='black')
        canvas.save(RESULTS/f'contact-{start+1:02d}-{min(start+6,len(pages)):02d}.png')
