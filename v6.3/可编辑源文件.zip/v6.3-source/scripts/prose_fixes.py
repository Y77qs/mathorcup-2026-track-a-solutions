"""Scoped corrections to frozen v6.2 prose; AI notes state only known revision facts."""
import re

def apply(text):
    log = []
    def replace(old, new, count=None, key=''):
        nonlocal text
        found = text.count(old)
        if not found and len(old.split()) > 1:
            pattern = r'\s+'.join(re.escape(part) for part in old.split())
            matches = list(re.finditer(pattern, text))
            if count is not None and len(matches) != count:
                raise ValueError(f'{key}: expected {count} matches, found {len(matches)}')
            if matches:
                text = re.sub(pattern, lambda _: new, text)
                log.append({'key': key, 'occurrences': len(matches), 'old': old, 'new': new})
                return
        if count is not None and found != count:
            raise ValueError(f'{key}: expected {count} matches, found {found}')
        if not found:
            raise ValueError(f'{key}: missing source fragment {old[:60]}')
        text = text.replace(old, new)
        log.append({'key': key, 'occurrences': found, 'old': old, 'new': new})

    replace('复制率与边饱和按 231×750 格',
            '批内重复率按 750 行；边饱和按 173250 个单元格', 5, 'table9-denominators')
    replace('批内整行重复率为 750 行生成样本中与同批次另一行完全相同的行占比',
            r'批内整行重复率按各批次的 \(1-n_{\mathrm{unique}}/n\) 计算，再按生成样本数加权汇总（总计750行）',
            1, 'duplicate-definition')
    replace('最近邻距离、复制率与边饱和比例', '最近邻距离、批内整行重复率与边饱和比例',
            1, 'metric-name-list')
    replace('最近邻 15.5202、复制率 0、边饱和比例 0.1237',
            '最近邻 15.5202、批内整行重复率 0、边饱和比例 0.1237', 1, 'metric-name-result')
    replace('三条读数须与``198 个 optimal\'\'并列：',
            '其中，容差边界需与``198 个 optimal\'\'并列说明：', 1, 'list-count')
    old = '\\item ~\n  \\subsection{不增率的饱和性、完整可行域基线与代理越界}'
    new = '\\end{itemize}\n\n\\subsection{不增率的饱和性、完整可行域基线与代理越界}'
    if text.count(old) != 1:
        raise ValueError('empty-list-item source changed')
    a = text.index(old)
    b = text.index('\\end{itemize}', a)
    tail = text[b + len('\\end{itemize}'):]
    middle = text[a:b].replace(old, new, 1)
    text = text[:a] + middle + tail
    log.append({'key': 'empty-list-item-and-heading', 'occurrences': 1})
    replace(r"半空间 \$a'z\textbackslash{}le b\$", r'半空间 \(a^{\top}z\le b\)',
            1, 'table15-math')
    replace('qc 表按全部约束统计的', '表13按全部约束统计的', 1, 'internal-table-reference')
    replace('每折截距由 b = a\'z\\_\\allowbreak{}source + 1e-9 反解，198 个证书全部为负',
            '每折感官岭回归代理的截距；198个证书记录的截距均为负',
            1, 'intercept-provenance')
    replace('两类都不计入可核验分母，也不计为失败',
            '条件成立198条与已验证3465条合计3663条具有可判定记录；不可识别99条不并入该合计。条件成立仍不等于实测已验证，两类均不因该状态而计为失败',
            1, 'conditional-record-denominator')
    start = text.index(r'\textbf{完整可行域基线是公平对照的主体。}')
    end = text.index(r'\textbf{迁移侧的两个缺陷命题分开读。}', start)
    old = text[start:end]
    new = r'''\textbf{同约束对照与同锚点消融分开解释。} 均值投影与交付QP具有相同可行域，
其转移能量分别为6.3792与2.0799；该比较同时包含分位数锚点和后续优化的作用。
进一步固定同一分位数锚点，直接投影到完整可行域时，转移能量为2.0903；
交付QP为2.0799，增量约0.50\%（表17）。因此，接近目标分布的主要收益来自
分位数映射，QP在声明的改动代价与约束下作进一步细化，不把总体变化全部归因于QP。

'''
    text = text[:start] + new + text[end:]
    log.append({'key':'migration-attribution','old':old,'new':new})
    replace('处于训练分布附近而非贴附训练点',
            '该数值描述设计谱到训练行的距离；是否接近训练分布，仍需同尺度的真实样本距离参照',
            1, 'nearest-distance-claim')
    replace('本附录完整收录三问全部核心建模、求解与评价算法源码；含命令行封装与自检断言的完整工程脚本原件见支撑材料',
            '本附录收录三问核心建模、求解与评价算法源码；完整可复现工程源码（含命令行封装、依赖模块与自检断言）见支撑材料',
            1, 'appendix-scope')
    replace(r'\textbf{全部来自首轮重复的折外评价侧}：',
            r'\textbf{均来自折外评价侧}。表3与图3汇总三次重复的750行折外结果（37500个等级格）；表4--5只展示首轮重复。',
            1, 'q1-grade-repeat-scope')
    replace(r'\$L\_1\$', r'\(L_1\)', 2, 'table17-L1-math')
    replace(r'\$2.2\textbackslash{}times10\textasciicircum{}\{-16\}\$',
            r'\(2.2\times10^{-16}\)', 1, 'table17-tolerance-math')
    replace('2.0799（归一化 0.1134）、四条化学列不增率\n  1；同一完整可行域的均值投影基线 \\(V=\\) 6.3792、不增率 1。',
            '2.0799（归一化 0.1134）、四条化学列不增率1；同一完整可行域的均值投影基线\\(V=6.3792\\)、不增率1；同锚点直接投影为\\(V=2.0903\\)，QP相对其改善约0.50\\%。',
            1, 'q3-answer-attribution')
    replace('1，转移能量低于同一完整可行域基线（2.0799 对 6.3792），但``不增率 =\n1\'\'不构成改善证据。',
            '1，转移能量低于同一完整可行域均值投影基线（2.0799 对6.3792）；同锚点直接投影为2.0903，QP相对其增量约0.50\\%。接近目标分布的主要收益来自分位数映射，``不增率=1\'\'本身不构成改善证据。',
            1, 'conclusion-migration-attribution')
    replace('第一，四组检验都只覆盖三个冻结种子中的两个，且扰动只改变冻结种子（问题一另有一次内层\n\\(\\lambda\\) 网格乘 0.5\n的参数扰动），没有对参数空间做系统扫描；因此任何``种子稳健\'\'或``参数不敏感\'\'的说法，最宽也只覆盖\n3 个冻结种子中的 2 个。',
            '第一，问题一的计划含3组，问题二及问题三生成、迁移的计划各含2组冻结种子块。问题一另含一次内层\\(\\lambda\\)网格乘0.5的扰动。这些检验只覆盖有限种子块和一次正则参数扰动，没有对参数空间作系统扫描，不能据此推断普遍的参数不敏感性。',
            1, 'robustness-scope-details')
    replace('第四，稳健性覆盖不全。四组检验都只覆盖三个冻结种子中的两个；扰动只改变冻结种子，不是参数空间扫描；固定种子复跑仅证确定性重现；迁移侧指标饱和使极差为零，不能解释为稳健。',
            '第四，稳健性覆盖不全。问题一计划含3组，问题二及问题三生成、迁移的计划各含2组冻结种子块；另有一次问题一内层正则参数扰动，并非参数空间扫描。固定种子复跑仅证确定性重现；迁移侧指标饱和使极差为零，不能解释为普遍稳健。',
            1, 'robustness-scope-conclusion')
    for label in ('q3-profile-chem', 'q3-profile-sensory', 'q3-transfer-example', 'q3-defect-control'):
        pattern = r'表\s+' + re.escape(label)
        assert len(re.findall(pattern, text)) == 1, label
        text = re.sub(pattern, lambda _: r'表\ref{tab:' + label + '}', text)
        log.append({'key':'cross-reference-' + label,'occurrences':1})
    replace(r'\$c=10\textasciicircum{}x\$', r'\(c=10^x\)', 1, 'table10-log-calibration-math')
    replace(r'\$c=x\$', r'\(c=x\)', 1, 'table10-linear-calibration-math')
    replace('四组计划都只做\\textbf{冻结种子块上的扰动}，扰动对象是协议常量\n\\texttt{SEEDS}/repeat，其余设置不变：',
            '四组检验主要比较\\textbf{冻结种子块}（协议常量\\texttt{SEEDS}/repeat）；问题一另含一次内层\\(\\lambda\\)网格扰动，其余计划设置保持不变：',
            1, 'robustness-unified-method')
    replace('登记原文见附录\n  B.4。',
            '计划范围与执行读数见表\\ref{tab:rob-confirmatory}及“稳健性与限制”一节。',
            2, 'remove-nonexistent-appendix-B4-reference')
    replace('逐项稳定性读数（18 行）见表 19。',
            '逐项稳定性读数见表\\ref{tab:q2-stability}。',1,'table19-stale-row-count')
    replace('逐列分布见图 9 第 (1)\n组', '逐列分布见图9的(a)、(b)面板',1,'figure9-updated-panel-label')
    ai_start = text.index('\\section*{AI\n工具使用声明}')
    ai_end = text.index('\\newpage\n\\appendix', ai_start)
    old_ai = text[ai_start:ai_end]
    new_ai = r'''{[}6{]} OpenAI. Codex（本次论文修订会话）. AI辅助复核、文字修正与图表排版工具，2026-10-28。使用范围及本轮检查记录见随附《本次修订AI辅助记录》。

\section*{AI工具使用声明}\label{ai-ux5de5ux5177ux4f7fux7528ux58f0ux660e}
\addcontentsline{toc}{section}{AI 工具使用声明}

本文使用AI辅助工具。原稿所列DeepSeek Harness使用记录见《AI工具使用详情说明》（参考文献{[}5{]}）；本轮新增使用OpenAI Codex（参考文献{[}6{]}）完成论文复核、表述修正与图表排版，已知范围说明如下。

\textbf{本轮使用范围。} AI参与了指标口径、评价范围与结论措辞的复核和纠错建议，修改LaTeX文字、表格与交叉引用，基于已冻结的折外预测和实验输出重绘7张图，并辅助数值一致性检查、编译及逐页排版检查。AI辅助范围包括指标和结论表述复核，最终取舍与责任由参赛队承担。

\textbf{本轮核验范围。} 未重新训练预测模型、生成器或运行迁移求解。检查了20张表的原有结果数值保留、重绘图与冻结输入的一致性，以及附录5段代码正文在修订前后的逐字一致性；这些检查不等于对全部支撑材料作独立复现，也不替代队员的人工审阅。

\textbf{记录与责任。} 本次修订记录列明实际完成的AI辅助工作。原稿涉及的其他工具名称、版本、完整使用过程及人工核验情况，须由参赛队依据实际记录核对并补齐；不把尚未确认的人工逐段审阅写作已完成事实。参赛队须核对赛题解释、评价协议、指标阈值、实验结论与最终提交内容，并对真实性、准确性及原创性负责。

'''
    text = text[:ai_start] + new_ai + text[ai_end:]
    log.append({'key':'AI-revision-factual-disclosure','old':old_ai,'new':new_ai,
                'history_not_invented':True,'team_history_confirmation_remaining':True})
    return text, log
