#!/usr/bin/env python3
"""Read-only replot of seven v6.2 scientific figures from saved evidence.

No fitted predictor, generator, bootstrap or optimisation routine is executed.
The original figure input equations are retained; only layout, text and units
are clarified. All sources and preserved numerical summaries are recorded.
"""
from pathlib import Path
import os, json, hashlib, sys, argparse
BASE = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-dir',type=Path,default=BASE/'repro-data',help='Frozen plotting inputs (default: sibling repro-data).')
parser.add_argument('--output-dir',type=Path,default=BASE/'project/figures',help='PDF/PNG output directory.')
parser.add_argument('--metadata-dir',type=Path,default=BASE/'results',help='Plot metadata and font cache directory.')
parser.add_argument('--only',type=int,nargs='+',choices=[1,4,5,6,8,9,10],help='Redraw only selected figure numbers.')
ARGS=parser.parse_args()
ARGS.metadata_dir.mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR'] = str(ARGS.metadata_dir/'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from matplotlib.collections import LineCollection
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from scipy.stats import rankdata

D=ARGS.data_dir/'draft'
S=ARGS.data_dir/'support'
V=ARGS.data_dir/'legacy'
OUT=ARGS.output_dir
OUT.mkdir(parents=True,exist_ok=True)
BLUE='#285577'; LIGHT='#83b7d4'; RED='#b84242'; ORANGE='#c2772a'; GREY='#929292'; GREEN='#5f8c63'
KINDS=['single_compound','element_or_index','physical_parameter','derived_sum']
KCOL=dict(zip(KINDS,[BLUE,RED,ORANGE,'#468a88']))
KLABEL=dict(zip(KINDS,['单体化合物','元素／指数','物理参数','衍生总量']))
fonts={n:[f.fname for f in fm.fontManager.ttflist if f.name==n] for n in ['SimSun','Songti SC','Times New Roman']}
assert fonts['Times New Roman']
CHINESE='SimSun' if fonts['SimSun'] else 'Songti SC'
assert fonts[CHINESE]
plt.rcParams.update({'font.family':['Times New Roman',CHINESE], 'font.size':9.5,
 'axes.labelsize':9.5,'axes.titlesize':10.5,'xtick.labelsize':9,'ytick.labelsize':9,
 'legend.fontsize':9,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,
 'mathtext.fontset':'custom','mathtext.rm':'Times New Roman','mathtext.it':'Times New Roman:italic',
 'mathtext.bf':'Times New Roman:bold','mathtext.default':'regular',
 'pdf.fonttype':42,'ps.fonttype':42,'figure.dpi':160,'savefig.dpi':320,
 'axes.linewidth':.7,'grid.alpha':.22,'savefig.facecolor':'white'})
REC={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return pd.read_csv(p,float_precision='round_trip')
def js(p):return json.loads(p.read_text())
def close(a,b,eps=1e-9):assert np.allclose(a,b,rtol=eps,atol=eps), (a,b)
def save(fig,number,old,new,sources,values,caption,size=None):
    for suffix in ['pdf','png']:fig.savefig(OUT/(new+'.'+suffix),bbox_inches='tight',pad_inches=.06)
    plt.close(fig)
    REC[str(number)]={'old':old,'new_pdf':str(OUT/(new+'.pdf')),'new_png':str(OUT/(new+'.png')),
      'sources':[{'path':str(p),'sha256':sha(p)} for p in sources],
      'preserved_values':values,'suggested_caption':caption,'suggested_tex_size':size,
      'outputs':{s:sha(OUT/(new+'.'+s)) for s in ['pdf','png']}}
def panel(ax,title):
    ax.set_title(title,loc='left',pad=7)
    ax.grid(axis='x' if ax.name!='polar' else 'both',zorder=0)
    ax.set_axisbelow(True)

def q1_skill():
    p=S/'q1/oof_predictions_750.csv'; mp=D/'experiments/EXP-0073/metrics.json'
    o=rd(p); targets=[c[8:] for c in o if c.startswith('y_true__')]
    Y=o[['y_true__'+t for t in targets]].to_numpy(); pred=o[['y_pred__'+t for t in targets]].to_numpy()
    base=np.empty_like(Y)
    for repeat in sorted(o.repeat.unique()):
        for fold in sorted(o.outer_fold.unique()):
            test=(o.repeat==repeat)&(o.outer_fold==fold)
            train=(o.repeat==repeat)&(o.outer_fold!=fold)
            base[test]=np.median(Y[train],axis=0)
    mae=np.abs(pred-Y).mean(0); bmae=np.abs(base-Y).mean(0); skill=1-mae/bmae
    af=np.array([t.startswith(('A_','F_')) for t in targets]); m=js(mp)
    close(mae[af].mean(),m['mae_graph_lowrank']); close(bmae[af].mean(),m['mae_median'])
    close(mae.mean(),m['mae_all50']); close(bmae.mean(),m['mae_all50_median'])
    order=np.argsort(skill); fig,axes=plt.subplots(1,2,figsize=(6.35,5.7))
    fig.subplots_adjust(left=.18,right=.98,bottom=.09,top=.94,wspace=.87)
    for k,ax in enumerate(axes):
        ix=order[k*25:(k+1)*25]; y=np.arange(len(ix))
        bars=ax.barh(y,skill[ix],color=[GREEN if v>=0 else RED for v in skill[ix]],height=.72)
        for bar,j in zip(bars,ix):
            if not af[j]:bar.set_hatch('///');bar.set_edgecolor('#444');bar.set_linewidth(.35)
        ax.set_yticks(y,labels=[targets[j] for j in ix],fontsize=8.8); ax.invert_yaxis()
        ax.axvline(0,c='#333',lw=.7)
        ax.set_xlim(min(skill)*1.16,max(skill)*1.12)
        ax.set_xlabel('相对误差改善（无量纲）')
        panel(ax,'(a) 排序第1–25项' if k==0 else '(b) 排序第26–50项')
    handles=[Patch(facecolor=GREEN,label='改善'),Patch(facecolor=RED,label='劣于基线'),Patch(facecolor='#ddd',edgecolor='#444',hatch='///',label='其他 20 维')]
    fig.legend(handles=handles,loc='lower center',ncol=3,bbox_to_anchor=(.55,-.02),frameon=False)
    save(fig,1,'Q1-per-target-skill.png','q1-per-target-skill',[p,mp],
      {'mae_af30':float(mae[af].mean()),'baseline_af30':float(bmae[af].mean()),'skill_af30':float(1-mae[af].mean()/bmae[af].mean()),'skill_all50':float(1-mae.mean()/bmae.mean()),'negative_targets':int((skill<0).sum()),'target_values':dict(zip(targets,skill.tolist()))},
      '图低秩模型的逐目标相对误差改善；按数值从小到大分为两列。相对误差改善为 $1-\\mathrm{MAE}_{模型}/\\mathrm{MAE}_{中位数}$，两者均取同一内部嵌套交叉验证的折外预测。斜线为其他20维；12维劣于中位数基线。',r'width=0.98\linewidth,height=0.52\textheight,keepaspectratio')

def force_layout(edges,seed=20261025,iterations=700):
    n=int(edges.max())+1; rng=np.random.default_rng(seed); pos=rng.uniform(-1,1,(n,2)); k=1.6/np.sqrt(n); temp=.18
    for _ in range(iterations):
        delta=pos[:,None,:]-pos[None,:,:]; dist=np.sqrt((delta**2).sum(-1));np.fill_diagonal(dist,np.inf)
        disp=((k*k/dist**2)[:,:,None]*delta).sum(1)
        for i,j in edges:
            vec=pos[i]-pos[j]; d=np.hypot(*vec)+1e-9; f=d*d/k; u=vec/d; disp[i]-=u*f;disp[j]+=u*f
        disp-=.06*(pos-pos.mean(0)); norm=np.linalg.norm(disp,axis=1,keepdims=True)+1e-12
        pos+=disp*np.minimum(1,temp/norm);temp*=.992
    pos-=pos.mean(0);return pos/(np.abs(pos).max()+1e-12)

def network_plot(number,old,new,pos,edges,rho,kinds,degree,sizes,sources,values):
    fig,axes=plt.subplots(1,2,figsize=(6.35,3.15),gridspec_kw={'width_ratios':[2,1]})
    fig.subplots_adjust(bottom=.25,wspace=.28)
    ax=axes[0]
    seg=pos[edges]
    for negative in [False,True]:
        mask=(rho<0)==negative
        ax.add_collection(LineCollection(seg[mask],colors=RED if negative else '#989898',linewidths=.7 if negative else .32,alpha=.75 if negative else .28,zorder=1))
    ax.scatter(*pos.T,s=7+1.7*degree,c=[KCOL[k] for k in kinds],edgecolors='white',linewidths=.28,zorder=3)
    ax.autoscale();ax.set_aspect('equal',adjustable='datalim');ax.axis('off')
    ax.set_title('(a) 最大连通分量' if number==4 else '(a) 附件2全部节点',loc='left')
    ax=axes[1];ordered=np.sort(sizes)[::-1]
    ax.bar(np.arange(1,len(sizes)+1),ordered,color=BLUE,width=.8);ax.set_yscale('log');ax.set_ylim(.7,ordered[0]*1.5)
    ax.set_title('(b) 分量规模',loc='left');ax.set_xlabel('分量序号（按规模排序）');ax.set_ylabel('节点数（对数轴）');ax.grid(axis='y');ax.set_axisbelow(True)
    ax.annotate(str(ordered[0]),xy=(1,ordered[0]),xytext=(7,0),textcoords='offset points',fontsize=10)
    handles=[Patch(facecolor=KCOL[k],label=KLABEL[k]) for k in KINDS]
    handles+=[Line2D([0],[0],color=RED,lw=1.2,label='负相关边'),Line2D([0],[0],color='#888',lw=.7,label='正相关边')]
    fig.legend(handles=handles,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,-.015),columnspacing=1.5)
    caption=('训练数据的相关网络（阈值 $|\\rho|\\geq0.5$）。左图为最大连通分量，右图为全部分量规模；节点颜色为变量类别，大小为节点度。' if number==4 else '附件2的描述性相关网络（阈值 $|\\rho|\\geq0.5$），位置直接读取已存 nodes.csv。节点颜色为变量类别，大小为节点度；该全样本网络不进入预测验证。')
    save(fig,number,old,new,sources,values,caption,r'width=0.98\linewidth,height=0.34\textheight,keepaspectratio')

def networks():
    p=S/'exp/EXP-0107/outputs.json';q=js(p)['q2']; meta=V/'data/clean/q2_chem_meta.json';features=[x['name'] for x in js(meta)['features']]
    train=D/'data/splits/SPLIT-0001/train.csv'
    f=rd(train);X=f[['chem__'+n for n in features]].to_numpy();X=np.where(np.isfinite(X),X,np.nanmedian(X,axis=0));r=rankdata(X,axis=0);r-=r.mean(0);r/=np.maximum(np.linalg.norm(r,axis=0),1e-12);rho=r.T@r
    adj=np.abs(rho)>=.5;np.fill_diagonal(adj,False);n,lab=connected_components(csr_matrix(adj));sizes=np.bincount(lab);pairs=np.argwhere(np.triu(adj,1))
    close(len(pairs),q['modules']['edgeCount'],0);close(n,q['modules']['count'],0);close(max(sizes),q['modules']['largestModuleSize'],0)
    category={n:k for k,ns in q['categoryMembers'].items() for n in ns}
    subset=np.where(lab==np.argmax(sizes))[0];local={int(v):i for i,v in enumerate(subset)}; ep=np.array([[local[int(i)],local[int(j)]] for i,j in pairs if i in local and j in local]); rr=np.array([rho[subset[i],subset[j]] for i,j in ep]);pos=force_layout(ep)
    network_plot(4,'Q2-network.png','q2-training-network',pos,ep,rr,[category[features[j]] for j in subset],adj.sum(0)[subset],sizes,[p,meta,train],{'nodes':231,'edges':len(pairs),'components':n,'largest':int(max(sizes)),'plotted_nodes':len(subset),'layout_seed':20261025,'layout_iterations':700})
    npth=S/'q2/attachment2_network/nodes.csv';epth=S/'q2/attachment2_network/edges.csv';sp=S/'q2/attachment2_network/component_summary.json'
    nodes=rd(npth).sort_values('nodeId');edges=rd(epth);summary=js(sp);pairs=edges[['sourceIndex','targetIndex']].to_numpy(int)
    adj=np.zeros((len(nodes),len(nodes)),bool);adj[tuple(pairs.T)]=True;adj|=adj.T;n,lab=connected_components(csr_matrix(adj));sizes=np.bincount(lab)
    assert len(edges)==summary['edgeCount']==645 and n==summary['nComponents']==52
    network_plot(5,'Q2-attachment2-network.png','q2-attachment-network',nodes[['x','y']].to_numpy(),pairs,edges.rho.to_numpy(),nodes.kind,adj.sum(0),sizes,[npth,epth,sp],{'nodes':len(nodes),'edges':len(edges),'components':n,'largest':int(max(sizes)),'positive_edges':int((edges.rho>0).sum()),'negative_edges':int((edges.rho<0).sum()),'layout':'unchanged nodes.csv x/y'})

def q2_stability():
    files=[S/f'exp/EXP-{e}/outputs.json' for e in ['0125','0126','0131']]; frames=[]
    for i,p in enumerate(files):
        f=pd.DataFrame(js(p)['q2']['top3_strict']);assert len(f)==600;f['repeat']=i;frames.append(f)
    board=pd.concat(frames,ignore_index=True);m=js(S/'exp/EXP-0107/metrics.json')
    close(board.pi.mean(),m['pi_mean']);close(board.sign_stability.mean(),m['sign_stability_mean']);close(board.p_positive_legacy.mean(),m['sign_stability_legacy_mean'])
    methods=['total_spearman','within_style_spearman','graph_lowrank','consensus'];labels=['总体相关','风格内相关','图低秩','共识'];colors=[LIGHT,ORANGE,GREEN,BLUE]
    fig,ax=plt.subplots(2,2,figsize=(6.35,4.9));fig.subplots_adjust(left=.1,right=.98,bottom=.15,top=.95,hspace=.67,wspace=.38)
    a=ax[0,0];a.hist(board.pi,bins=np.linspace(0,1,21),color=BLUE,edgecolor='white',lw=.4);a.axvline(.5,c=RED,ls='--',lw=.8);a.axvline(board.pi.mean(),c=ORANGE,lw=1)
    a.text(.97,.95,f'均值 {board.pi.mean():.4f}',transform=a.transAxes,ha='right',va='top',fontsize=9,color=ORANGE)
    a.set_xlabel('入选频率（无量纲）');a.set_ylabel('记录数');a.set_title('(a) Top-3 入选频率',loc='left')
    a=ax[0,1];g=board.groupby(['method','rank']).pi.mean();w=.19
    for i,(method,label,c) in enumerate(zip(methods,labels,colors)):
        a.bar(np.arange(3)+(i-1.5)*w,[g.loc[(method,j)] for j in [1,2,3]],w,color=c,label=label)
    a.set_xticks([0,1,2],['第1名','第2名','第3名']);a.set_ylabel('平均入选频率');a.set_ylim(0,.9);a.set_title('(b) 排名与入选频率',loc='left')
    a=ax[1,0]
    for i,(method,c) in enumerate(zip(methods,colors)):
        for k,col in enumerate(['sign_stability','p_positive_legacy']):
            bp=a.boxplot([board.loc[board.method==method,col]],positions=[i+(-.17 if k==0 else .17)],widths=.29,patch_artist=True,showfliers=False,medianprops={'color':'#222','linewidth':.7})
            bp['boxes'][0].set_facecolor(c if k==0 else '#ddd')
            if k==1:bp['boxes'][0].set_hatch('///')
    a.set_xticks(range(4),['总体','风格内','图低秩','共识']);a.set_ylim(-.05,1.08);a.set_ylabel('重采样比例（无量纲）');a.set_title('(c) 同向率与旧正相关率',loc='left')
    handles=[Patch(facecolor='#777',label='与点估计同向'),Patch(facecolor='#ddd',hatch='///',label='旧口径：正相关率')]
    # Colour = current point-direction agreement; hatching = legacy positive
    # frequency. Explain in the caption, so the legend cannot cover boxes.
    vals=[js(S/f'exp/EXP-{e}/metrics.json')['topk-jaccard'] for e in ['0125','0126','0131']]
    a=ax[1,1];a.bar(range(3),vals,color=[BLUE,LIGHT,'#ddd'],edgecolor=['white','white','#888'],hatch=[None,None,'///'])
    for i,v in enumerate(vals):a.text(i,v+.006,f'{v:.4f}',ha='center',fontsize=9)
    a.set_xticks(range(3),['参照块','计划扰动块','补充块']);a.set_ylabel('Top-3 Jaccard');a.set_ylim(0,.28);a.set_title('(d) 冻结种子块扰动',loc='left')
    fig.legend(handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,labels)],loc='lower center',ncol=4,frameon=False,bbox_to_anchor=(.54,.015),fontsize=9)
    save(fig,6,'Q2-stability.png','q2-selection-stability',files+[S/'exp/EXP-0107/metrics.json'],{'rows':len(board),'pi_mean':float(board.pi.mean()),'below_half':int((board.pi<.5).sum()),'same_sign_mean':float(board.sign_stability.mean()),'legacy_positive_mean':float(board.p_positive_legacy.mean()),'jaccard_blocks':vals},'Top-3 的入选频率与方向稳定性（3个冻结重复、4种方法，共1800条记录；每块500次风格分层重采样）。虚线0.5为参考线。图(c)实色为与点估计同向的比例，斜线为旧正相关比例；两者不等价。图(d)前两块属于计划内扰动，第三块为补充结果。',r'width=0.98\linewidth,height=0.45\textheight,keepaspectratio')

def q3_style():
    p=S/'exp/EXP-0109/q3_metrics.csv'; op=S/'exp/EXP-0109/outputs.json';d=rd(p);d=d[(d.stage=='design')&(d.model=='copula-selected')&(d.n_excluded_from_energy==0)]
    b={style:{'V':float(np.average(f.E_V_norm,weights=f.n_gen)),'n':int(f.n_gen.sum())} for style,f in d.groupby('style')}
    names=sorted(b,key=lambda n:b[n]['V']);vals=[b[n]['V'] for n in names];primary=['Tripel','Kriek','Lambic'];pool=float(np.average(d.E_V_norm,weights=d.n_gen));x=d[d['style'].isin(primary)];three=float(np.average(x.E_V_norm,weights=x.n_gen));q=js(op)['q3']['energy_summary'];close(pool,q['allStyles']['V_normalized']);close(three,q['excludedStylesSubset']['V_normalized'])
    fig,a=plt.subplots(figsize=(6.35,5.0));fig.subplots_adjust(left=.28,right=.96,bottom=.16,top=.97)
    a.barh(range(len(names)),vals,color=[ORANGE if n in primary else BLUE for n in names],height=.68)
    a.set_yticks(range(len(names)),labels=names,fontsize=9.2);a.set_xscale('log');a.set_xlim(min(vals)*.7,max(vals)*2.4)
    for i,v in enumerate(vals):a.text(v*1.06,i,f'{v:.4f}',va='center',fontsize=9)
    a.axvline(pool,c=BLUE,ls='--',lw=.9);a.axvline(three,c=ORANGE,ls='--',lw=.9);a.set_xlabel('归一化 V 能量距离（对数轴，无量纲）');a.grid(axis='x');a.set_axisbelow(True)
    h=[Patch(facecolor=BLUE,label='其他可估风格'),Patch(facecolor=ORANGE,label='指定三风格'),Line2D([0],[0],c=BLUE,ls='--',label=f'21风格池化 {pool:.4f}'),Line2D([0],[0],c=ORANGE,ls='--',label=f'三风格池化 {three:.4f}')]
    fig.legend(handles=h,loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.58,-.015),fontsize=9)
    save(fig,8,'Q3-per-style-energy.png','q3-per-style-energy',[p,op],{'style_values':b,'pooled_21':pool,'pooled_three':three,'estimable_cells':len(d)},'约束设计谱的逐风格归一化V能量距离，按生成样本数加权；数值越小越好。橙色为Tripel、Kriek、Lambic，21风格池化与三风格池化分别为0.8727与1.8079。Faro因无可估单元未画入。',r'width=0.98\linewidth,height=0.48\textheight,keepaspectratio')

def q3_transfer():
    p=S/'exp/EXP-0110/transfers.csv';c=S/'exp/EXP-0110/transfer_constraints.csv';f=rd(p);con=rd(c)
    strategies=['qp-quantile-anchor','qp-source-anchor','target-mean-projection-full','target-mean-projection','source-fixed'];cols=[c for c in f if c.startswith('opt__chem__')];src=['src__chem__'+c[11:] for c in cols];assert len(cols)==231 and all(x in f for x in src)
    arrays={};res={}
    upper=con.bound_type.str.startswith('upper');violation=np.where(upper,np.maximum(con.stored_after-con.bound_value,0),np.maximum(-con.stored_after,0));close(violation,con.residual,1e-8)
    for s in strategies:
        q=f[f.strategy==s];assert len(q)==99;delta=np.abs(q[cols].to_numpy()-q[src].to_numpy());close(q.l1_change_z,q.mean_abs_change_z*231)
        arrays[s]={'max':delta.max(0),'mean':delta.mean(0),'zmean':q.mean_abs_change_z.to_numpy(),'zl1':q.l1_change_z.to_numpy()}
        v=violation[(con.strategy==s).to_numpy()];assert len(v)==3762;res[s]={'records':len(v),'violations':int((v>1e-8).sum()),'max':float(v.max())}
    colors=[BLUE,LIGHT,GREEN,ORANGE,GREY];fig,axes=plt.subplots(3,2,figsize=(6.35,6.15));fig.subplots_adjust(left=.105,right=.98,bottom=.22,top=.96,hspace=.67,wspace=.38)
    def boxes(a,k,title,ylabel):
        bp=a.boxplot([arrays[s][k] for s in strategies],patch_artist=True,widths=.55,flierprops={'marker':'o','markersize':1.2,'alpha':.4},medianprops={'color':'#222','linewidth':.8})
        for patch,color in zip(bp['boxes'],colors):patch.set_facecolor(color)
        threshold=.01 if k!='zl1' else .1
        a.set_xticks(range(1,6),labels=range(1,6));a.set_yscale('symlog',linthresh=threshold);a.set_ylim(-threshold*.1,max(float(arrays[s][k].max()) for s in strategies)*1.5);a.set_ylabel(ylabel);a.set_title(title,loc='left');a.grid(axis='y');a.set_axisbelow(True)
    boxes(axes[0,0],'max','(a) 存储位移：逐列最大值','存储单位（各列不同）')
    boxes(axes[0,1],'mean','(b) 存储位移：逐列均值','存储单位（各列不同）')
    boxes(axes[1,0],'zmean','(c) z位移：逐行均值','z单位（无量纲）')
    boxes(axes[1,1],'zl1','(d) z位移：逐行 L1','z单位（无量纲）')
    a=axes[2,0];counts=[res[s]['violations'] for s in strategies];a.bar(range(1,6),counts,color=colors)
    for i,v in enumerate(counts,1):a.text(i,v+max(counts)*.04,str(v),ha='center',fontsize=9)
    a.set_xticks(range(1,6));a.set_ylim(0,max(counts)*1.35);a.set_ylabel('超差约束记录数');a.set_title('(e) 约束残差超差记录',loc='left');a.grid(axis='y');a.set_axisbelow(True)
    a=axes[2,1];v=violation[violation>1e-8];a.hist(v,bins=min(24,max(6,len(v)//3)),color=ORANGE,edgecolor='white');a.set_xlabel('残差（相应约束的存储单位）');a.set_ylabel('约束记录数');a.set_title('(f) 超差记录的残差分布',loc='left');a.grid(axis='y');a.set_axisbelow(True)
    labels=['1 分位数锚点QP','2 源锚点QP','3 目标均值全约束投影','4 仅箱约束投影','5 源样本不变']
    fig.legend(handles=[Patch(facecolor=cc,label=l) for cc,l in zip(colors,labels)],loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.54,-.015),fontsize=9)
    summary={s:{k:float(np.max(v)) for k,v in arrays[s].items()} for s in strategies}
    save(fig,9,'Q3-transfer-shift.png','q3-transfer-shift',[p,c],{'maxima':summary,'constraint_residual':res,'strategies':strategies,'rows_per_strategy':99},'五种迁移策略的存储位移、标准化z位移和约束残差；横轴编号见公共图例。每策略99条迁移、3762条约束记录。位移描述改动大小，残差描述约束违反，二者不可混用；存储单位随变量而异，z空间无量纲。',r'width=0.98\linewidth,height=0.58\textheight,keepaspectratio')

def robustness():
    p=D/'report/evidence_manifest.json';q=js(p)['questions'];keys=['Q1','Q2','Q3gen','Q3mig'];labels=['Q1\nMAE','Q2\nJaccard','Q3生成\n归一化V','Q3迁移\n非增加率'];groups=[q[k]['robustnessPlan'] for k in keys];values=[g['values'] for g in groups];absolute=np.array([max(v)-min(v) for v in values]);relative=np.array([a/v[0] for a,v in zip(absolute,values)])
    sources=[p]
    for g in groups:
        for e,v in zip(g['experimentIds'],g['values']):
            mp=S/'exp'/e/'metrics.json'
            if not mp.exists():mp=D/'experiments'/e/'metrics.json'
            sources.append(mp);close(js(mp)[g['metricKey']],v)
    fig,axes=plt.subplots(1,2,figsize=(6.35,2.8));fig.subplots_adjust(left=.11,right=.98,bottom=.2,top=.88,wspace=.38)
    for a,vals,title,ylabel,col in [(axes[0],absolute,'(a) 绝对极差','各自指标单位',BLUE),(axes[1],relative,'(b) 相对参照值的极差','无量纲',ORANGE)]:
        a.bar(range(4),vals,color=col,width=.55)
        for i,v in enumerate(vals):a.text(i,v+.0011,f'{v:.4f}',ha='center',fontsize=9)
        a.set_xticks(range(4),labels);a.set_ylabel(ylabel);a.set_title(title,loc='left');a.grid(axis='y');a.set_axisbelow(True)
    axes[0].set_ylim(0,max(absolute)*1.7);axes[1].set_ylim(0,.123)
    for i,g in enumerate(groups[:3]):
        limit=g['decisionRule']['limit'];axes[1].plot([i-.33,i+.33],[limit]*2,c=RED,lw=1.4);axes[1].text(i,limit+.003,f'{limit:.2f}',ha='center',color=RED,fontsize=9)
    axes[1].plot([],[],c=RED,label='相对极差上限');axes[1].legend(loc='upper left',frameon=False,fontsize=9)
    save(fig,10,'ROB-summary.png','rob-perturbation-summary',sources,{'values':dict(zip(keys,values)),'absolute_range':dict(zip(keys,absolute.tolist())),'relative_range':dict(zip(keys,relative.tolist()))},'四组预定扰动的绝对极差与相对极差分别展示。Q1计划含3组，Q2与Q3两组计划各含2组，补充块未并入；红线为各自的相对极差上限。迁移非增加率两组均为1，零极差来自约束指标饱和，不能解释为性能提升。',r'width=0.98\linewidth,height=0.29\textheight,keepaspectratio')

if __name__=='__main__':
    data_manifest=js(ARGS.data_dir/'manifest.json')
    for entry in data_manifest['files']:
        assert sha(ARGS.data_dir/entry['path'])==entry['sha256'], 'Frozen plot input hash differs: '+entry['path']
    selected=set(ARGS.only or [1,4,5,6,8,9,10])
    if 1 in selected:q1_skill()
    if selected & {4,5}:networks()
    if 6 in selected:q2_stability()
    if 8 in selected:q3_style()
    if 9 in selected:q3_transfer()
    if 10 in selected:robustness()
    result={'scope':'Presentation-only replot from saved v6.1 evidence, whose original ten images are pixel-identical to v6.2 PDF images; no training, bootstrap, QP solve or generator run.','python':sys.version,'font_check':fonts,'chinese_fallback':CHINESE,'figures':REC}
    result['data_manifest']={'path':str(ARGS.data_dir/'manifest.json'),'sha256':sha(ARGS.data_dir/'manifest.json')}
    metadata=ARGS.metadata_dir/'figure_revision.json'
    if metadata.exists() and ARGS.only:
        previous=js(metadata);previous['figures'].update(REC);result['figures']=previous['figures']
    metadata.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({k:{'old':v['old'],'new_pdf':v['new_pdf']} for k,v in REC.items()},ensure_ascii=False,indent=2))
