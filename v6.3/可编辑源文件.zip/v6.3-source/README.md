# v6.3 可编辑论文源文件

本目录为v6.3论文的可编辑源及便携重绘证据，基于原v6.2修订交付。PDF内容与已验证版本相同，模型主结果及5段代码附录正文保留。完整修改列表见[修改说明.md](修改说明.md)，来源边界见[ARCHIVE-NOTES.md](ARCHIVE-NOTES.md)。

## 编译

进入`project/`，运行两遍：

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
```

入口为`project/main.tex`，依赖同目录`source_appendix.tex`及`figures/`。字体需要Times New Roman、Arial、Menlo、Songti SC；换字体应重查分页与缺字。已在独立目录两轮编译验证58页文本逐页一致。正文含AI声明止于编号30页，附录31页起。

## 修订与重绘

从本目录运行`python3 scripts/build_revision.py`，从未修改的`baseline/`重建论文TeX；运行`python3 scripts/redraw_figures.py`从包内`repro-data/`重绘7图。重绘依赖Python、NumPy、pandas、SciPy、Matplotlib及相应字体；详情见[scripts/README-redraw.md](scripts/README-redraw.md)。

`results/`保留文字差异、表格/代码同一性、图形来源、PDF与独立编译核对记录。历史v6.1/v6.2路径、哈希、EXP编号及模型脚本名保留原身份。`修订来源说明.md`是上一修订交付的原README归档，不作为本v6.3的新模型结论。

本包可编译论文、重绘指定图，完整三问训练和原始输出仍需共享仓库`v6.2/支撑材料/`。原Markdown/插件构建源未同步补丁，后续以本包TeX编辑或先同步生成源。校验：`shasum -a 256 -c SHA256SUMS`。
