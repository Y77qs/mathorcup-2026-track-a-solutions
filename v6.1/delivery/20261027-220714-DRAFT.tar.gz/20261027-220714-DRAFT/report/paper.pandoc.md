---
title: 基于稳健表示、共表达网络与风格条件生成的啤酒化合物—感官强度建模
author: ""
date: ""
lang: zh-CN
---

# 摘要 {.unnumbered}


\begin{draftbanner}
\textbf{DRAFT——科学证据与交付限制见文末，非最终提交版。} 本文是论文源的工作稿：正文数字除数据集与协议的结构常量外，一律以占位符引用本轮真实执行、未过期的确认轮实验（三问各含主实验、对照实验与稳健性种子块；逐条实验记录与证据登记见附录 B.4 与支撑材料清单）。交付检查未通过最终门禁（\texttt{final=false}、\texttt{qualityPassed=false}），因此本文不得作为最终提交稿或对外结果引用。
\end{draftbanner}


针对啤酒化学谱与感官强度之间的高维、非线性关联，以及风格样本不均衡和缺陷控制要求，本文以 250 款啤酒的 231 个化学及理化变量与 50 个标准化感官标签为基础，建立预测、关联识别与风格条件生成的统一框架，并在每一问内先固定评价协议、再比较候选。

问题一在训练折内完成缺失处理与稳健表示，比较逐目标中位数、普通 Ridge、图 Ridge 与图正则低秩四模型（同一嵌套交叉验证、预处理与截距约定）。主候选 Aroma/Flavour 30 维等权 MAE 为 0.35929156588219174、同协议中位数基线 0.39817732837288883；全 50 维 0.350504156920024、基线 0.3918800487369867。误差都在所给标签尺度上、且均为折外误差，不是 0–6 原始等级误差；0–6 等级由训练折标签的中点经验分布标定，只是训练分布内的相对推断等级。图 Ridge 与普通 Ridge 几乎相同，低秩相对两者的改善按**低秩收缩**归因，不读成“加图收益”。

问题二把候选宇宙拆为 216 个严格单体化合物与 15 个扩展指标两张表，用总体 Spearman、风格内残差化 Spearman、图低秩系数与三者百分位均值四种方法，经风格分层 bootstrap 给出逐维 Top-3。方法间 Top-3 平均两两 Jaccard 0.2091111111111111，是集合一致性而非识别准确率。方向稳定性取“与总体 Spearman 点估计同方向的一致率”0.9816877777777778；旧口径 $P(\rho>0)$ 0.7225544444444444 只作历史对照。附件 2 描述性网络（231/645/52）与训练折内网络是两个不同产物（图 4、图 5），前者只作结构解释、不进入验证。

问题三把生成与迁移分开。生成侧用含编码质量点的层次收缩边际与收缩高斯 Copula，投影后给出非负浓度设计谱，归一化经验 V 能量距离 0.8726874826148657，仍高于同量源样本重采样参照，故不宣称优于该参照。化学反-2-壬烯醛不增（0 条），感官 t2n 代理仍增加 366 条（0.488），两命题分列。迁移侧 198 个证书均最优、源状态分层核验通过（3465 / 分母 3663），交付策略转移能量 2.0798861351916886，优于同一完整可行域的均值投影基线，而两者综合不增率都是 1。

稳健性按问题分列：问题一 3 个执行块（参考 + 种子块 + 内层正则扰动）；问题二、三为**冻结种子块参数扰动**、计划内各 2 块，另有登记后补跑的补充块单列未并入计划记录。所有相对极差在预注册限内，但每组只覆盖 3 个冻结种子中的 2 个，固定种子复跑只证确定性重现。问题一的划分完整性/留出评价、问题三的原生优化检查结构性未通过，三问选择状态均为草稿选择；交付检查未过最终门禁，本稿是 DRAFT。

**关键词：** 图正则低秩回归；嵌套交叉验证；风格混杂；分层 bootstrap；收缩 Copula；凸二次规划证书

\newpage
\thispagestyle{empty}
\tableofcontents
\newpage
\pagenumbering{arabic}

# 问题重述与分析

## 题目要求与建模对象

赛题要求三项相互关联的任务：估计评分卡定义的 Aroma 与 Flavour 感官强度并输出 0–6 分级；用化合物相关矩阵构建共表达图，识别每个感官维度的 Top-3 并论证稳定性与化学合理性；学习以 `tasting_category_fine` 为条件的化合物谱生成模型，展示 Tripel、Kriek、Lambic 的感官画像，并把 Pils/Lager 化学谱迁移至 Tripel、同时控制指定缺陷 [1]。

共同难点：特征数接近样本量、化合物高度相关；标准化感官值与原始整数评分之间缺少可逆标定；风格差异可能使总体相关偏离风格内关系；小样本风格难以独立估计高维联合分布。本文先核实数据尺度与编码规则，再为每问固定评价协议、最后比较候选。

| 任务 | 建模对象 | 核心输出 | 主要评价 |
|---|---|---|---|
| 感官评分 | $Y=f(X)+E$ | 折外连续预测与 0–6 相对分级 | 30 维与 50 维等权平均 MAE、平均 $R^2$、Skill |
| 关键因素 | 化学成分与感官的同期关联 | 每个维度 3 个候选及其稳定性 | 入选频率、方法间 Jaccard、方向一致率 |
| 生成 | $p(X\mid s)$ | 风格谱、感官代理画像、缺陷对照 | 归一化能量距离、约束分层核验 |
| 迁移 | 声明模型下的迁移算子 | 迁移前后化学与感官对照 | 转移能量、完整可行域基线、约束分层与求解证书 |

生成与迁移在第 6 章分列成两个对象，评价对象不同，不能合并成一个“问题三成功率”。

## 三问的评价对象与证据边界

本文区分四类陈述：**已登记的计划**、**真实执行**（状态成功、退出码与结果文件真实存在）、**验证通过**（检查项通过且未过期）、**被选为最终方案**（选择记录与冻结身份一致）。四者不可互相替代。

按此口径，本轮三问的证据状态如下，正文与文末限制按实际状态书写，不做统一化表述：

- 问题一：泄漏检查、基线比较检查与固定种子独立复跑三项通过；但该问没有留出集、也没有登记数据划分，划分完整性与留出评价两项检查结构性不可满足，因此选择状态只到草稿选择（provisional）。
- 问题二的泄漏检查与固定种子独立复跑通过；但“稳定性”与“集合一致性”不等于识别准确率，附件交叉相关表与本研究同源。该问的选择状态当前同样是草稿选择。
- 问题三：生成侧与迁移侧的泄漏检查、固定种子独立复跑均通过；但原生优化检查要求“一个声明的优化模型 + 一个解文件”，而本实验是一批带逐问题证书的 QP，工具据此对优化可行性与优化目标检查给出具名拒绝，本文不声称通过。单一选择字段无法同时表示生成与迁移两个对象，选择状态为草稿选择。

三问都未到达“被选为最终方案”：交付冻结被工具拒绝、交付检查未过最终门禁（`final=false`），本文只声明到“真实执行 + 部分验证通过”。

## 与附件实际结构不符的三处修正

第一，评分工作簿是空白评分卡。附件 `3.xlsx` 含 `beer_1` 至 `beer_12` 与一张汇总页，各页均为带 0–6 刻度的空白模板，不含已填写的原始整数评分，也不含该量表的标定参数。因此本文的 0–6 等级只能定义为可复核的相对等级，而不能声称恢复了人工评分。评分卡上还印有一项 **Acetaldehyde（青苹果、果皮）**，但标签表 `4.csv` 没有它的列：该项列入维度映射说明，不预测、不分级、不造真值。

第二，交叉相关表的感官列顺序与主表不一致。附件 `6.csv` 尾部的列序为 Carbonation、Aftertaste、Body、Overall，而目标表为 aftertaste、body、co2、overall 的顺序，按位置对齐会错位三列，并连带使化学行与候选索引错配。本文改为按名称一对一对齐：化学行经化学元数据映射到特征名，感官列经 50 条字面字典映射到目标名，任何重复、歧义或未匹配的行按名报告并中止，不做静默丢弃。

第三，先导轮实现存在三处名实不符，本轮全部重做。其一是“普通 Ridge”实际带有图正则，不是普通 Ridge；其二是低秩拟合每轮刷新截距而 Ridge 参照固定标签均值，两者不在同一截距约定下可比；其三是“折外”表把样本内预测与留出预测混在同一张表里。确认轮把四模型放在同一嵌套协议、同一预处理规则与同一截距公式下重算，并对“秩 50 且 $\gamma=0$ 应还原普通 Ridge”作逐折数值核对。

本轮另有一处**数据源冲突**：附件 `8.xlsx` 的校准值与主输入 `1.csv` 在 33 个线性校准列的 80 个单元格上不一致（其中 79 个相对偏差超过 1%），涉及 24 款酒、32 个字段；37 个对数校准列没有冲突。本文采用 `1.csv` 为主输入，不替换、不插补、不宣称两侧一致，冲突成因仍属**未知**；这一处理与其影响见第 2 章“尺度、编码点与物理浓度”一节。

# 数据核实与统一字典

## 样本对齐与主键

化学表、感官表与跨来源描述符表均按 `beer` 序号连接：`beer` 是 1..250 的置换，可整行对齐 1.csv 与 4.csv；后两表的 `beer_id` 只有 96 个唯一值，存在截断，不能作为可靠连接键。化学表规模为 250 行、231 列，感官表 50 列，风格变量共 22 类。

## 尺度、编码点与物理浓度

利用附件校准表覆盖的 70 个变量逐列回算，37 列与 $\log_{10}c$ 一致，33 列与原始浓度 $c$ 一致，其余 161 列缺少直接校准依据。在已确认的对数列中，$x<0$、$x=0$、$x>0$ 分别对应以指定单位计量的 $0<c<1$、$c=1$、$c>1$；该逻辑不适用于未经确认的列。

37 个对数列中有 755 个单元格对应校准表记录的零值，其存储值为该列最小正浓度一半的 $\log_{10}$。另有 142 个未校准列共享约 $-1.8178$ 的地板编码，合计 6807 个单元格。这些数值首先表示观测编码，不能据此断言真实浓度为零或已知低于某个仪器检出限。生成模型因此显式保留地板质量点，物理阈值比较只在尺度与单位已确认时进行。

**校准附件与主输入的 80 格冲突（本轮新增披露）。** 把 `1.csv` 的存储值与 `8.xlsx` 校准表按同尺度逐格比较（对数校准列比 $\log_{10}c$，线性校准列比 $c$，容差 $10^{-7}$）：可比单元格共 16613 个，其中 80 个单元格不一致，79 个相对偏差超过 1%。冲突**全部落在 33 个线性校准列**（24 款酒、32 个字段，含反-2-壬烯醛、双乙酰、4VG 相关列），37 个对数校准列零冲突。本文的处理规则是先声明、不修补：`1.csv` 是主输入，`8.xlsx` 只用于确定尺度与单位，冲突单元格不替换、不插补，也不宣称两侧一致；冲突成因**未知**，本文不把它解释成任一方有误。直接比较存储值与校准值会得到更大的差异数（约 8531 格），但那主要是 $\log_{10}$ 变换本身而非数据冲突，故不采用。

| 数据类别 | 数量 | 用途及处理 |
|---|---:|---|
| 已校准 log10 变量 | 37 | 预测时使用存储值；物理比较时反变换 $c=10^x$ |
| 已校准线性变量 | 33 | 保留原单位；物理比较时施加非负下界 |
| 未直接校准变量 | 161 | 以存储尺度建模，只在声明的观测支撑内取值 |
| 其中派生汇总量 | 5（含于上两行，不另计） | 热量、总酸、总酯、酒花香气及硫化物汇总；属子集，合计仍为 231 |
| 感官目标 | 50 | 用于预测与评价，不作为生成器的化学输入 |

## 缺失处理与三套评价协议

化学表有 73 个缺失单元格，分布于 9 列、63 行，其中乙酸戊酯 27 个、酒花香气汇总 13 个、甲基吡嗪 12 个、双乙酰 9 个、3-甲基丁醛 7 个，其余 4 列合计 5 个。预测模型在当前训练折内部进行中位数填补，并增加 9 个缺失指示列；验证折与评价行沿用训练折参数。生成模型估计边际时只使用有效观测，不把填补值的堆积当作真实概率质量点。

本轮存在三套并行的评价协议，正文不把它们混为一谈：

- **问题一采用全样本嵌套交叉验证（评价协议）**：3 次重复 × 3 个外层折 × 每折 3 个内层折，覆盖全部 250 款啤酒，每次重复的折外预测合起来恰好覆盖 250 行，三次重复合计 750 行预测。该协议没有任何留出集，因此“留出泛化”类陈述在本文中不成立。
- **问题一的 250 行评分表是展示协议，不是评价协议**：它由冻结候选在全部 250 行上重拟合一次得到，只用于给出连续预测与 0–6 相对等级，其样本内拟合误差**不**作为性能估计，也不参与任何 MAE、$R^2$、基线或结论计算。评价侧与展示侧分别是 `oof_predictions_750.csv`（750 行，250 款酒 × 3 次重复）与 `beer_scores_250.csv` / `grades_250.csv`（各 250 行）；维度字典 `dimension_map.csv` 共 51 行 = 50 个有标签维度 + 1 个无标签卡面项。两侧不可互换。
- **问题二使用注册的 200 行训练集**：保留的 50 行为控制重复曝光而不参与拟合，也不用于评价。问题二的 bootstrap 只在该 200 行内进行。

三套协议的对象不同，其误差与距离数值不可横向比较。

## 防止信息泄露

缺失处理、稳健表示、目标中心化、图估计、超参数选择与分级切点全部在训练折内拟合。任一啤酒的折外预测都来自不含该啤酒的训练集：外层测试行不参与填补中位数、不参与标准化参数、不参与图估计、不参与内层选参、不参与分级切点。附件 `2.csv` 的全样本相关矩阵只用于构造第 5 章“两个用途不同的网络”一节的描述性网络，本轮把它作为独立产物重算并登记；它不参与任何 Top-3 选择，也不进入预测或关联模型的验证。预测与关联模型的正则化图必须由当前训练折重新计算。跨来源感官描述符与附件提供的既有模型重要性均不作为化学输入。

# 模型假设、符号与总体框架

## 主要假设

第一，已对齐的同期样本可用于估计本数据分布内的化学—感官关系；该关系不直接代表未来批次或其他市场。第二，可确认尺度的变量按校准字典解释，未校准变量仅作为存储尺度上的观测量。第三，风格内秩残差可减少风格组间差异的影响，但不能消除未观测混杂。第四，条件生成模型近似描述既有风格的观测分布；缺陷约束是数学筛查规则，不能单独保证真实啤酒的工艺可实现性。第五，迁移结论只在声明的变量空间、目标函数与约束集合下成立。

## 符号说明

| 符号 | 含义 |
|---|---|
| $X\in\mathbb R^{n\times p}$ | 存储尺度化学及理化特征，$p=231$ |
| $Z$ | 当前训练折拟合的稳健表示，含 9 个缺失指示列，共 240 维 |
| $Y\in\mathbb R^{n\times q}$ | 标准化感官标签，$q=50$；Aroma 与 Flavour 各 15 维记作 $q_{AF}=30$ |
| $s_i$ | 第 $i$ 款啤酒的细粒度风格，共 22 类 |
| $G=(V,E,W),L_G$ | 训练折内估计的带符号关联图及其拉普拉斯矩阵 |
| $B,r$ | 多输出回归系数及秩约束 |
| $\rho^{\mathrm{total}},\rho^{\mathrm{within}}$ | 总体及风格内残差化秩相关 |
| $S_{jt}$ | 候选 $j$ 在维度 $t$ 的综合分 |
| $F_{j,s},R_s$ | 风格条件边际分布与 Copula 相关矩阵 |
| $c_j,T_j$ | 已确认单位的物理浓度与感官阈值 |
| $z$ | 迁移二次规划的变量，为折叠标准化存储空间中的 231 维向量 |
| $P,D,C$ | 迁移目标风格的主成分载荷、得分标准差对角阵与其收缩相关矩阵 $C=0.9\widehat R_T+0.1I$ |
| $V,U$ | 经验能量距离（非负）与带符号能量诊断量（可负，不截零） |
| $\pi_{jt},\text{sign\_stability}_{jt}$ | 候选入选频率与“与点估计同方向”的复制一致率 |

## 总体框架

统一框架以字典为基础：问题一估计多输出感官预测器并给出相对分级；问题二使用同族图低秩回归的系数，与总体关联和风格内关联共同识别候选；问题三先条件生成化学谱，再在声明的凸二次规划下做风格迁移。三问共享标签体系与化学字典，但评价对象不同：问题一评价逐维误差，问题二评价集合一致性，问题三评价分布距离与求解证书。任何跨问的“综合得分”在本文中都不使用。

# 问题一：图正则低秩预测与相对分级

## 训练折内稳健表示

231 个化学特征与 9 个缺失指示列构成 240 维输入。对化学变量比较两种表示：存储尺度 z 分数与 Rank-Gauss 表示。

$$
z_{ij}^{\mathrm{zs}}=\operatorname{clip}\!\left(\frac{x_{ij}-\mu_{j,\mathrm{train}}}{s_{j,\mathrm{train}}},\,-8,\,8\right),
\qquad
u_{ij}=\widehat F_{j,\mathrm{train}}(x_{ij}),\quad
z_{ij}^{\mathrm{rg}}=\Phi^{-1}\{\operatorname{clip}(u_{ij},\varepsilon,1-\varepsilon)\},\quad
\varepsilon=(2n_{\mathrm{train}})^{-1}.
$$

z 分数按冻结规则截断在 $\pm8$，避免单个极端值主导最小二乘；截断只发生在表示层，不改变原始浓度。重复观测使用中秩，验证样本沿用训练经验分布。目标**只在所给标签尺度上中心化**：$\widetilde y_{it}=y_{it}-\mu_t$，$\mu_t$ 为该折训练行的标签均值；代码不把目标除以训练标准差，也没有任何目标尺度字段参与求解。此前的论文文字把它写成“除以训练标准差”，与实现不符，本轮按代码更正。为什么必须写准而不是含糊：惩罚项作用在系数 $B$ 上，目标列缩放会改变解，低秩拟合并非尺度不变，因此不能用一个没在跑过的目标变换去解释已报出的误差。

## 图正则低秩多输出回归

模型同时利用感官维度之间的共享结构及化学变量的共线性，求解

$$
\min_{B,b}\ \frac{1}{n_{\mathrm{train}}}\|\widetilde Y-ZB-\mathbf1b^\top\|_F^2
+\lambda\|B\|_F^2+\gamma\operatorname{tr}(B^\top L_GB),\qquad \operatorname{rank}(B)\le r.
$$

训练图的边权为 $w_{jk}=\widehat\rho_{jk}\mathbf1\{|\widehat\rho_{jk}|\ge\tau\}$，$w_{jj}=0$，其中 $\tau=0.5$ 在任何拟合之前冻结；$\widehat\rho$ 由训练折的中秩 Spearman 计算。取 $L_G=D_{|W|}-W$，其惩罚可写为

$$
\operatorname{tr}(B^\top L_GB)=\frac12\sum_{j,k}|w_{jk}|\|B_{j\cdot}-\operatorname{sign}(w_{jk})B_{k\cdot}\|_2^2 .
$$

正相关变量倾向具有相近系数，负相关变量倾向具有反向系数。$D_{|W|}-W$ 由 Gershgorin 圆盘定理保证半正定（特征值位于 $[0,\,2\max_i\sum_j|w_{ij}|]$），因此实现中不再对特征值作截断；缺失指示列的图惩罚块设为零。

低秩解取闭式形式而非迭代近似：令 $Z_c,\widetilde Y_c$ 为训练块的中心化矩阵，

$$
A=\frac{1}{n}Z_c^\top Z_c+\lambda I+\gamma L_G,\qquad C=\frac{1}{n}Z_c^\top \widetilde Y_c,\qquad
B=A^{-1}CV_rV_r^\top,
$$

其中 $V_r$ 为 $C^\top A^{-1}C$ 的前 $r$ 个特征向量。该解是有秩约束问题的精确最小化点，$r=q$ 时退化为满秩惩罚解；实现只做 Cholesky 分解与三角回代，不显式求逆。

四个线性模型统一使用同一截距公式

$$
b=\bar y-\bar z\,B,\qquad \widehat y=\bar y+(z-\bar z)B,
$$

其中 $\bar z,\bar y$ 为训练块均值。该约定使“秩 50 且 $\gamma=0$”必须还原普通 Ridge；逐折核对的最大预测差为 3.9968028886505635e-15，机器精度通过。

## 四个同协议模型与内层选参

同一进程中运行四个模型，预处理规则、截距约定、外层划分与分级切点完全一致：

| 模型 | 定义 | 内层搜索 |
|---|---|---|
| 逐目标训练中位数 | 每维取外层训练标签的中位数 | 无参数 |
| 普通 Ridge | $\gamma=0$，$r=50$（无秩约束） | 表示、$\lambda$ |
| 图 Ridge | $\gamma>0$，$r=50$ | 表示、$\lambda$、$\gamma\in\{0.1,1\}$ |
| 图正则低秩 | $\gamma\ge0$，$r\in\{3,6,10\}$ | 表示、$\lambda$、$\gamma\in\{0,0.1,1\}$、$r$ |

$\lambda$ 的网格为 $\{0.1,1,10\}$，表示在 z 分数与 Rank-Gauss 之间选择。每个外层训练集内部再切 3 个内层折选参，内层网格的每一个单元都写入实验目录，使参数选择可逐格复核。外层评价使用 3 次重复 × 3 个外层折，重复种子在协议中冻结。

## 预测结果：同协议四模型对照



\begin{bptable}
\setcounter{table}{0}
%% table-id: q1-models sha256:89369169d05f5d7d0901a347096f00fd3edacfeacbc822adf1eb72965d39ace9
\captionof{table}{同一嵌套协议下四种模型的预测误差}\label{tab:q1-models}
\par\smallskip
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
模型 & A/\allowbreak{}F30 等权 MAE & 全 50 维 MAE & 宏平均 R²（A/\allowbreak{}F30） & Skill（A/\allowbreak{}F30） & 相对中位数差值（A/\allowbreak{}F30） & 相对中位数差值（全 50 维） \\
\midrule
最小中位数基线 & 0.3982 & 0.3919 & -0.0584 & 0.0000 & 0.0000 & 0.0000 \\
普通 Ridge & 0.3667 & 0.3582 & 0.1584 & 0.0791 & -0.0791 & -0.0860 \\
图 Ridge & 0.3664 & 0.3575 & 0.1576 & 0.0798 & -0.0798 & -0.0879 \\
图正则低秩 & 0.3593 & 0.3505 & 0.1854 & 0.0977 & -0.0977 & -0.1056 \\
\bottomrule
\end{tabular}
}%
\begin{tablenote}注：三次重复 × 三次外折的折外池化结果；A/F30 为香气 15 维与风味 15 维的等权平均，“全 50 维”另加其余 20 维。Skill（A/F30）= 1 − MAE / 中位数基线 MAE；相对中位数差值 =（本模型 MAE − 中位数基线 MAE）/ 中位数基线 MAE，负值表示优于基线。普通 Ridge 固定无图惩罚（γ=0）且不含低秩项；图 Ridge 不含低秩项；图正则低秩的秩在 \{3, 6, 10\} 中由内层验证选参，图惩罚强度 γ 与正则强度 λ 的选参网格为 γ∈\{0, 0.1, 1\}、λ∈\{0.1, 1, 10\}。本表只描述同一协议下的相对拟合差异，不构成对任一分量的显著性结论。\end{tablenote}
\end{bptable}


同一协议下，中位数基线的 Aroma/Flavour 30 维等权 MAE 为 0.39817732837288883，全部 50 维为 0.3918800487369867。图正则低秩模型把 30 维 MAE 降到 0.35929156588219174，50 维降到 0.350504156920024；平均 $R^2$ 由基线的负值转为 0.1854199218782663，汇总 Skill 为 0.09765940881064172。

本文使用两个 Skill 口径，二者不可混用：逐维 $\mathrm{Skill}_t=1-\mathrm{MAE}_{t,\mathrm{model}}/\mathrm{MAE}_{t,\mathrm{median}}$，以及汇总 $\mathrm{Skill}=1-\overline{\mathrm{MAE}}_{\mathrm{model}}/\overline{\mathrm{MAE}}_{\mathrm{median}}$。前者正负混杂时后者仍可为正，因此逐维 Skill 图与汇总值必须分别解读。


\begin{bpfigure}
%% figure-id: FIG-0041 sha256:2557001da5d9510a8f8afbfd682d4149c2b276b294901892dbc45ee0c8cf5838
%% figure-src: ../figures/confirmatory_v2/Q1-per-target-skill.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q1-per-target-skill.png}
\captionof{figure}{问题一：逐目标相对误差改善 1−MAE模型/MAE中位数（图低秩，内部嵌套CV折外池化）；A/F30 0.0977、全50维 0.1056，12 个目标为负。}
\end{bpfigure}



\begin{bpfigure}
%% figure-id: FIG-0042 sha256:a461da972ec8e999b9d643e945cf792f262d61c88aa85680fc67e7ba8119122e
%% figure-src: ../figures/confirmatory_v2/Q1-model-comparison.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q1-model-comparison.png}
\captionof{figure}{问题一：四模型同协议折外MAE（内部3×3×3嵌套重验证，非holdout）：中位数0.398、岭0.367、图岭0.366、图低秩0.359；全50维另列。}
\end{bpfigure}


值得注意的是三个**负结果**，它们共同决定了本文对组件作用的措辞。

第一，普通 Ridge 的 30 维 MAE 为 0.3666617580105253，图 Ridge 为 0.3664110157826924，两者的差在小数点后第 4 位（表 1），远小于它们与中位数基线的差距。也就是说：在本协议下，**仅加入图正则几乎不改变误差**。

第二，图低秩相对普通 Ridge 的改善（0.3666617580105253 → 0.35929156588219174）同样不大。这里必须把归因写对：这一改善发生在“秩约束 $r\in\{3,6,10\}$ 被激活”的模型里，因此本文把它归因为**低秩收缩**；而“普通 Ridge → 图 Ridge”的差值属于图正则项的作用，两者都不是可以单独摘出来宣称的“加图收益”。我们没有跑“同协议、无图、但同样加低秩”的消融，所以**不保留“图结构带来预测增益”的主张**；图与低秩组件的作用被定位为“提供多输出共享结构、共线性去噪与可解释系数”。

第三，由于三条线性模型的误差都与中位数基线相差一个量级以内的改善，逐折波动与折间差异不能忽略：9 个折的 MAE 并不落在同一水平上（表 2），组间与折间差异的量级与模型间差异相当。因此任何“某组件稳定领先”的说法在本协议下都缺乏支撑。



\begin{bptable}
\setcounter{table}{1}
%% table-id: q1-groups sha256:346c55460e3fde077cdaf481cd0930060902cd08f0cf121bed75678c70c8228a
\captionof{table}{指标分组误差与折间波动}\label{tab:q1-groups}
\par\smallskip
\small
\begin{tabular}{@{}llrrr@{}}
\toprule
对象 & 口径 & MAE & 样本数 & 同折中位数基线 MAE \\
\midrule
香气 15 维（指标组） & 指标组 & 0.3646 & 15 & — \\
风味 15 维（指标组） & 指标组 & 0.3540 & 15 & — \\
其余 20 维（指标组） & 指标组 & 0.3373 & 20 & — \\
第 1 次重复 ·\allowbreak{} 第 1 折 & 折外分段 & 0.3549 & 91 & 0.4024 \\
第 1 次重复 ·\allowbreak{} 第 2 折 & 折外分段 & 0.3450 & 83 & 0.3794 \\
第 1 次重复 ·\allowbreak{} 第 3 折 & 折外分段 & 0.3635 & 76 & 0.4124 \\
第 2 次重复 ·\allowbreak{} 第 1 折 & 折外分段 & 0.3643 & 76 & 0.4039 \\
第 2 次重复 ·\allowbreak{} 第 2 折 & 折外分段 & 0.3618 & 91 & 0.3882 \\
第 2 次重复 ·\allowbreak{} 第 3 折 & 折外分段 & 0.3614 & 83 & 0.4044 \\
第 3 次重复 ·\allowbreak{} 第 1 折 & 折外分段 & 0.3492 & 83 & 0.3771 \\
第 3 次重复 ·\allowbreak{} 第 2 折 & 折外分段 & 0.3731 & 76 & 0.4165 \\
第 3 次重复 ·\allowbreak{} 第 3 折 & 折外分段 & 0.3623 & 91 & 0.4026 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：上三行为三个指标组的折外池化 MAE 与组内维数；下九行为三次重复 × 三次外折逐折的折外 MAE、折内行数与同一折的中位数基线 MAE，用于展示折间波动而非模型间比较。逐折行数不同是因为外折按风格分层切分。\end{tablenote}
\end{bptable}


分组的结论是方向性的而非量级性的：口感、缺陷与总体评价构成的 20 维组，其误差低于 Aroma 与 Flavour 两个 15 维组；Aroma 组最高。逐风格结果（支撑材料表（`report/tables/q1-styles.md|csv`））进一步显示，样本量极小的风格误差明显更大，且同一模型在不同风格上的排序并不稳定，这与其训练行数直接相关。


逐维结果见支撑材料表 `report/tables/q1-targets.md|csv`（30 维，按 Skill 升序排列以暴露恶化维度）：总体 Skill 为正并不意味着每一维都改善，把汇总值当作逐维结论是本协议下最常见的误读。

## 0–6 相对等级与典型评分表

由于附件未提供原始整数评分及其标准化参数，本文定义可复核的相对强度等级。以该目标外层训练标签的中点经验分布函数 $\widehat F_t^{\mathrm{mid}}$ 标定：

$$
a_{it}=\widehat F_t^{\mathrm{mid}}(\widehat y_{it}),\qquad
g_{it}^{\mathrm{cont}}=6a_{it},\qquad
g_{it}=\min\{6,\max[0,\lfloor 6a_{it}+1/2\rfloor]\}.
$$

对观测侧使用**同一个** $\widehat F_t^{\mathrm{mid}}$，因此两侧处于同一标尺，可比较的只有“相对等级一致性”，不是与原始人工评分的一致性。预测落在训练分布中位附近时等级约为 3，靠近两端时趋向 0 或 6。0 不表示该风味不存在，6 不表示恢复了人工满分，缺陷维度的高等级也不等于超出物理阈值。

本节的等级与相邻两张表来自**展示侧**（冻结候选在 250 行上重拟合一次，产物 `grades_250.csv`、`beer_scores_250.csv`），与用于评价的 750 行折外预测（`oof_predictions_750.csv`）是两件不同的东西：等级只能读作“训练分布内的相对推断等级”，不能读作“重新标定的人工评分”；展示侧的样本内拟合误差也不作为模型性能，任一 MAE、$R^2$、$\kappa$ 或基线数值都只从折外行重算。本章末尾的“实际答案”与“作用边界”两节给出这两侧的分界。

**维度映射的一项缺口。** 评分卡上印有 Acetaldehyde（青苹果、果皮），跨 Aroma 与 Flavour 两栏各出现一次，但标签表 `4.csv` 除 50 列之外没有这一项。本文在维度映射（`dimension_map.csv`，51 行）中把它单列为“有卡面文本、无标签列”的项：不预测、不分级、不与其他维度合并计数，也**不凭空造真值**。`7.csv` 里的同名 Ratebeer 描述符是外部支持数据（该列在本数据上缺失率 100%），不属于本问标签，未被映射进来。



\begin{sidewaystable}
\setcounter{table}{2}
%% table-id: q1-grades sha256:003871a907665e16bf0094c63cb04e80637c3fb52cff89ac95e07d60eb05f214
\centering
\caption{各模型的相对等级一致性}\label{tab:q1-grades}
\small
\begin{tabular}{@{}lrrrrrrrrrr@{}}
\toprule
模型 & 等级 MAE & 整级一致率 & 二次加权 κ & 等级 0 & 等级 1 & 等级 2 & 等级 3 & 等级 4 & 等级 5 & 等级 6 \\
\midrule
图正则低秩 & 1.4111 & 0.2289 & 0.3321 & 1315 & 1915 & 4151 & 9493 & 13092 & 7140 & 394 \\
图 Ridge & 1.4391 & 0.2150 & 0.2590 & 412 & 1007 & 3156 & 11488 & 15347 & 5985 & 105 \\
普通 Ridge & 1.4401 & 0.2105 & 0.2390 & 141 & 699 & 2787 & 12102 & 16372 & 5388 & 11 \\
最小中位数基线 & 1.5072 & 0.1650 & 0.0000 & 0 & 0 & 0 & 37500 & 0 & 0 & 0 \\
参照等级（真实标签同映射） & — & — & — & 3190 & 6229 & 6227 & 6189 & 6259 & 6211 & 3195 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：等级为训练折内经验中点分布映射出的 0–6 相对强度等级，参照等级是真实标准化标签经同一映射得到的等级；本表衡量的是相对等级的一致性，不是恢复人工感官评分，也不代表等级 0/6 对应原始评分卡的 0/6 分。二次加权 κ 与整级一致率均在 37500 个等级格（750 行 × 50 维）上计算；最小中位数基线的预测恒为中间等级，其等级分布只有一档，因此 κ 为 0。预测等级向中间收缩，说明离散等级仍有改善空间。\end{tablenote}
\end{sidewaystable}


回归预测向中部收缩，使预测等级分布集中在中间等级，而参照等级在 0–6 上接近均匀；两者的整级一致率、二次加权 $\kappa$ 与等级 MAE 因此受限（表 3）。这是本方法的真实短板，不作为可忽略的枝节。


\begin{bpfigure}
%% figure-id: FIG-0043 sha256:e2cf95cdb0e4fa5d16a79db21f08f1abc8f8136346a2b02612285ea60daa27d4
%% figure-src: ../figures/confirmatory_v2/Q1-grade-distribution.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q1-grade-distribution.png}
\captionof{figure}{问题一：相对等级 0–6 的折外预测分布与参照分布对照（内部嵌套CV、中秩经验CDF；属相对等级，未恢复人工评分）。}
\end{bpfigure}


表 4、q1-scores-flavour 依据 `beer` 的真实序号提取 Beer#1–Beer#10，与评分卡中的 Beer# 对齐，列出核心维度的相对等级；全部 250 款啤酒 × 50 维的连续预测与整数分级见 `beer_scores_250.csv` 与 `grades_250.csv`，维度字典见 `dimension_map.csv`，表中只截取核心维度。需要留意这两张表取自**首轮重复的折外预测**（评价侧），不是上面那个 250 行重拟合的展示侧：两者的等级可以在同一映射下比较，但身份不同，不能互换引用。



\begin{sidewaystable}
\setcounter{table}{3}
%% table-id: q1-scores-aroma sha256:0040ad38b0b93fa8a8f0ee6935edc3ad3d1da2916f6b9db8d38f360b526ba4d1
\centering
\caption{Beer\#1–Beer\#10 的 Aroma 核心维度相对等级}\label{tab:q1-scores-aroma}
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.0649\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0724\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1023\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0724\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1023\linewidth-6pt\relax}@{}}
\toprule
样本 & 香气·\allowbreak{}麦芽总体·\allowbreak{}预测 & 香气·\allowbreak{}酒花总体·\allowbreak{}预测 & 香气·\allowbreak{}柑橘·\allowbreak{}预测 & 香气·\allowbreak{}酯香总体·\allowbreak{}预测 & 香气·\allowbreak{}乙酸异戊酯·\allowbreak{}预测 & 香气·\allowbreak{}麦芽总体·\allowbreak{}参照 & 香气·\allowbreak{}酒花总体·\allowbreak{}参照 & 香气·\allowbreak{}柑橘·\allowbreak{}参照 & 香气·\allowbreak{}酯香总体·\allowbreak{}参照 & 香气·\allowbreak{}乙酸异戊酯·\allowbreak{}参照 \\
\midrule
Beer\#1 & 4 & 3 & 3 & 4 & 3 & 5 & 5 & 1 & 2 & 3 \\
Beer\#2 & 3 & 1 & 2 & 1 & 4 & 3 & 0 & 0 & 0 & 0 \\
Beer\#3 & 3 & 2 & 3 & 4 & 4 & 2 & 2 & 4 & 4 & 4 \\
Beer\#4 & 4 & 3 & 4 & 4 & 4 & 4 & 3 & 4 & 5 & 3 \\
Beer\#5 & 1 & 5 & 5 & 3 & 3 & 5 & 5 & 6 & 4 & 5 \\
Beer\#6 & 4 & 3 & 3 & 4 & 4 & 1 & 1 & 4 & 5 & 5 \\
Beer\#7 & 1 & 5 & 5 & 4 & 3 & 1 & 6 & 6 & 1 & 2 \\
Beer\#8 & 3 & 5 & 4 & 4 & 4 & 4 & 6 & 5 & 4 & 4 \\
Beer\#9 & 3 & 5 & 4 & 3 & 3 & 3 & 5 & 5 & 3 & 4 \\
Beer\#10 & 1 & 1 & 4 & 1 & 2 & 1 & 3 & 6 & 5 & 5 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：等级为训练折内经验分布映射得到的 0–6 相对强度等级，预测列为折外预测、参照列为真实标签经同一映射的等级；样本编号与题面评分卡的 Beer\# 对齐（第 n 号样本即 beer\_n 评分卡对应的啤酒）；表内为首轮重复的折外结果，五维为核心香气维度（麦芽总体、酒花总体、柑橘、酯香总体、乙酸异戊酯）；等级是相对强度，不是人工评分恢复，也不表示风味存在与否。\end{tablenote}
\end{sidewaystable}




\begin{sidewaystable}
\setcounter{table}{4}
%% table-id: q1-scores-flavour sha256:a1ab3464521df13d9e0f039f6bdaf35522034adc6015fb6022fbdd8830359165
\centering
\caption{Beer\#1–Beer\#10 的 Flavour 核心维度相对等级}\label{tab:q1-scores-flavour}
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.0649\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0724\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1023\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0724\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0923\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1023\linewidth-6pt\relax}@{}}
\toprule
样本 & 风味·\allowbreak{}麦芽总体·\allowbreak{}预测 & 风味·\allowbreak{}酒花总体·\allowbreak{}预测 & 风味·\allowbreak{}柑橘·\allowbreak{}预测 & 风味·\allowbreak{}酯香总体·\allowbreak{}预测 & 风味·\allowbreak{}乙酸异戊酯·\allowbreak{}预测 & 风味·\allowbreak{}麦芽总体·\allowbreak{}参照 & 风味·\allowbreak{}酒花总体·\allowbreak{}参照 & 风味·\allowbreak{}柑橘·\allowbreak{}参照 & 风味·\allowbreak{}酯香总体·\allowbreak{}参照 & 风味·\allowbreak{}乙酸异戊酯·\allowbreak{}参照 \\
\midrule
Beer\#1 & 3 & 3 & 3 & 4 & 3 & 5 & 4 & 1 & 5 & 6 \\
Beer\#2 & 3 & 1 & 2 & 1 & 4 & 4 & 0 & 3 & 0 & 0 \\
Beer\#3 & 3 & 2 & 3 & 4 & 4 & 2 & 2 & 4 & 3 & 5 \\
Beer\#4 & 4 & 3 & 3 & 4 & 4 & 5 & 4 & 3 & 6 & 4 \\
Beer\#5 & 2 & 5 & 5 & 2 & 3 & 5 & 6 & 4 & 4 & 3 \\
Beer\#6 & 4 & 3 & 3 & 4 & 4 & 2 & 2 & 4 & 4 & 4 \\
Beer\#7 & 2 & 5 & 5 & 4 & 4 & 2 & 6 & 5 & 3 & 1 \\
Beer\#8 & 4 & 5 & 4 & 4 & 4 & 2 & 6 & 4 & 6 & 4 \\
Beer\#9 & 4 & 5 & 4 & 3 & 3 & 3 & 5 & 6 & 3 & 1 \\
Beer\#10 & 0 & 0 & 4 & 1 & 3 & 0 & 3 & 6 & 6 & 6 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：等级为训练折内经验分布映射得到的 0–6 相对强度等级，预测列为折外预测、参照列为真实标签经同一映射的等级；样本编号与题面评分卡的 Beer\# 对齐（第 n 号样本即 beer\_n 评分卡对应的啤酒）；表内为首轮重复的折外结果，五维为核心风味维度（麦芽总体、酒花总体、柑橘、酯香总体、乙酸异戊酯）；等级是相对强度，不是人工评分恢复，也不表示风味存在与否。\end{tablenote}
\end{sidewaystable}


样本间差异已经体现在整数等级中：同一维度在不同酒款上跨越多个等级，说明该维度在本数据内可分；但相邻等级之间没有可核对的原始评分作为标尺，等级差 1 不应读作“强度差 1 个单位”。

## 问题一的实际答案

1. **能预测到什么程度**：冻结 3×3×3 嵌套交叉验证下，图正则低秩候选的 Aroma/Flavour 30 维等权 MAE 为 0.35929156588219174、同协议中位数基线 0.39817732837288883，全 50 维 0.350504156920024（基线 0.3918800487369867）；误差单位是所给标签尺度，不是 0–6 原始整数分。
2. **证据与产物**：主结论为问题一主实验（图正则低秩候选）相对同协议中位数基线实验的比较结果；稳健性覆盖三个执行块（参考块、种子块扰动、内层正则扰动）。可核对产物为 750 行折外预测、逐维/逐风格/逐折表（支撑材料表 `report/tables/q1-targets.md|csv`、`q1-styles.md|csv` 与表 2）、250 行展示评分与分级、51 行维度字典。
3. **限制**：改善主要来自低秩收缩而非图结构；0–6 只是相对等级；没有留出集；选择状态仍是草稿选择。

**证据登记：** 主结论与稳健性结论的登记原文、证据引用与限制见附录 B.4。

## 问题一的作用边界

第一，**没有留出集**：每一行都是折外预测，但不存在从未参与拟合的外部样本，“留出泛化”类陈述在本问不成立，最强只到“冻结协议下的内部折外重验证”。

第二，**划分完整性检查结构性不可满足**：评价实验未登记数据划分，工具对划分完整性给出具名拒绝，留出指标检查同理；这不是遗漏而是协议选择，本文如实披露而不另挂旧划分规避，选择状态只到草稿选择。

第三，**固定种子复跑只证确定性重现**：逐位一致说明同环境可重复，但不引入新样本、不是独立实现，不能作为泛化证据；稳健性只覆盖 3 个冻结种子中的 2 个。

第四，**结论只适用于当前候选、数据版本与协议**：更换候选、数据或划分后，本节误差与等级数字不可沿用。

第五，**等级侧短板是结构性的**：预测等级向中部收缩，整级一致率与二次加权 $\kappa$ 偏低（表 3），且缺少原始人工评分作标尺；不通过换切点或挑维度改善读数。

# 问题二：共表达网络、风格混杂与稳定 Top-3

## 候选宇宙：严格单体化合物与扩展指标分表

231 个化学及理化变量并非同一类对象。按化学语义拆分为四类：单体化合物、元素或成分指数、理化参数、派生汇总。严格单体化合物构成 216 项，是“关键化合物因素”的主表候选；元素与成分指数 3 项、理化参数 7 项、派生汇总 5 项共 15 项构成扩展表。原先被标为单体的铁含量、蛋白质总量与 $\beta$-葡聚糖三项在本轮被重新归类为元素或成分指数，不再进入严格表。



\begin{bptable}
\setcounter{table}{5}
%% table-id: q2-universe sha256:83af9df245dda67a83065e9a76f2423297dfaf46130b6480ca401951ef8b69bd
\captionof{table}{候选宇宙构成与两张表的划分}\label{tab:q2-universe}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.1222\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0745\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1222\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1222\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.5267\linewidth-6pt\relax}@{}}
\toprule
类别 & 候选数 & 进入严格榜 & 进入扩展榜 & 说明 \\
\midrule
单体化合物 & 216 & 是 & 否 & 严格榜唯一允许的宇宙：参与 50 维 Top-3 选择 \\
元素/\allowbreak{}指数 & 3 & 否 & 是 & 元素/\allowbreak{}指数项，非单体化合物，移出严格榜 \\
理化参数 & 7 & 否 & 是 & 理化参数，非化合物丰度，只进扩展榜 \\
派生和 & 5 & 否 & 是 & 派生汇总量，不是独立化合物，只进扩展榜 \\
合计 & 231 & — & — & 候选矩阵为 231 个候选 × 50 个维度 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：严格榜只允许单体化合物，元素/指数、理化参数与派生和另一张扩展榜单独报告，两张表不得混排；同一化合物在不同维度上的候选一致。候选矩阵共 231 个候选 × 50 个维度 = 11550 个候选-维度单元。\end{tablenote}
\end{bptable}


分表不是形式主义：把蛋白质总量、铁含量与“热量”一类的汇总量与挥发性风味分子混在同一张 Top-3 表里，会让“关键化合物”的语义失效。因此正文的核心表只含严格单体化合物，扩展表单独给出，两者不合并统计。

## 两个用途不同的网络

本问涉及两个**用途不同、统计量不可混用**的网络，本轮各自有独立产物与图。

**（一）训练折内网络。** 预测与关联模型使用的图每次都由当前训练行重新估计：中位数填补后的 231 列计算中秩 Spearman，取 $w_{jk}=\widehat\rho_{jk}\mathbf1\{|\widehat\rho_{jk}|\ge\tau\}$，$\tau=0.5$ 在拟合前冻结，对角置零。它是正则化与结构化系数提取的输入，随 bootstrap 重抽样逐次重建；在问题二注册输入上该网络复现 732 条边、51 个连通分量（图 4）。

**（二）附件 2 的描述性网络。** 为回答“这批样本里谁与谁共同变化”，本轮把附件 `2.csv` 的 231×231 相关矩阵按预先声明的规则（无向、$i<j$、$|\rho|\ge 0.5$、保留符号、无自环）构造成网络，并产出节点表、边表、阈值与规则文件、分量统计与图。实测节点 231、边 645、连通分量 52、最大分量 175；正边 629、负边 16；度中位 4、最大 30；孤立节点 48。该网络与附件同源，只用于本章“化学合理性”一节的模块归属与正负相关格局解释。

**两者分工与禁止事项。** 描述性网络回答“结构长什么样”，训练网络只承担正则化；连通分量只是阈值图上的传递连通，不等于经功能验证的生物化学模块，因此模块标签不进入 Top-3 综合打分。**附件 2 的全样本矩阵不进入任何验证**：它不会作为预测或关联模型的正则化图，也不参与 Top-3 选择与 bootstrap；独立预测用的图始终在训练行内重建，避免把全样本结构泄漏到评价里。反过来，训练网络的边数与分量数也不能当成“附件 2 网络”的统计量引用。


\begin{bpfigure}
%% figure-id: FIG-0044 sha256:4f8321a856a66e9a0f6807d11bb8e893630149be640c619b2355e9e3e09bcd9b
%% figure-src: ../figures/confirmatory_v2/Q2-network.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q2-network.png}
\captionof{figure}{问题二：τ=0.5 Spearman 阈值网络（由对应主实验注册输入重算，复现 732 边/51 分量）；严格单体216与扩展15分色，边非因果。}
\end{bpfigure}



\begin{bpfigure}
%% figure-id: FIG-0045 sha256:5b0c129a52cb17b02d8c25d30cb967adce0f2b0e6269f1b68a6eb510736ec80d
%% figure-src: ../figures/confirmatory_v2/Q2-attachment2-network.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q2-attachment2-network.png}
\captionof{figure}{问题二附件2：描述性化学相关网络（231 节点/645 边/52 分量，x/y 取自 nodes.csv）；仅解释网络结构，预测训练图仍在训练折内构建。}
\end{bpfigure}


## 风格混杂与残差化关联

总体关联定义为 $\rho^{\mathrm{total}}_{jt}=\operatorname{Spearman}(X_j,Y_t)$。为分离组间风格差异，令 $H$ 为风格虚拟变量与截距组成的设计矩阵，对秩残差化：

$$
P_H=H(H^\top H)^\dagger H^\top,\quad
r_j^X=(I-P_H)\operatorname{rank}(X_j),\quad
r_t^Y=(I-P_H)\operatorname{rank}(Y_t),\quad
\rho^{\mathrm{within}}_{jt}=\operatorname{Corr}(r_j^X,r_t^Y).
$$

该指标反映去除风格均值差异后的共同关联。风格内残差化能减少组间差异的影响，但不能消除未观测混杂；因此本文同时保留总体关联，让两种口径并列，而不是用一种替换另一种。

## 四种方法与综合打分

对候选 $j$ 与目标 $t$ 使用四种方法：总体 Spearman、风格内残差化 Spearman、图低秩回归系数 $\widehat B_{jt}$、以及三者的共识分

$$
S_{jt}=\frac13\left[R\!\left(|\rho^{\mathrm{total}}_{jt}|\right)+R\!\left(|\rho^{\mathrm{within}}_{jt}|\right)+R\!\left(|\widehat B_{jt}|\right)\right],
$$

其中 $R$ 为同一目标内、该表自身候选宇宙上的百分位秩；$\widehat B$ 来自固定 $\tau=0.5,\ \lambda=1,\ \gamma=0.1,\ r=6$ 的图低秩模型。四种方法各自给出 Top-3；交付表的排序规则是**入选频率优先**：先按 $\pi$ 降序，$\pi$ 并列时用原样本综合分 $S$ 裁决，再并列时沿用固定特征名字符序。方法间差异本身作为稳定性证据保留，不通过换排序规则来消除。

稳定性用风格分层 bootstrap 度量：在注册的 200 行训练集内，按 `tasting_category_fine` 分层、每层有放回重采样到自身规模，共重采样 500 次。每个重抽样样本都重新执行中位数填补、$\tau=0.5$ 的 Spearman 图估计、图低秩回归、风格内秩残差化与三项子分数，然后重新取 Top-3：

$$
\pi_{jt}=\frac{1}{B}\sum_{b=1}^{B}\mathbf1\{j\in\operatorname{Top3}^{(b)}_t\},\qquad
\mathrm{se}_{\mathrm{mc}}=\sqrt{\frac{\pi_{jt}(1-\pi_{jt})}{B}} .
$$

最终表按 $\pi$ 降序排列，并列时按原样本综合分 $S$ 裁决，再并列时沿用固定特征名的字符序。$S$ 表征原样本中的综合关联强度，$\pi$ 表征重抽样下的入选稳定性；候选方向取总体 Spearman 的符号，只是关联方向，不代表干预效应。每个入选条目旁同时报告同一参考模块内秩 4–10 的替代候选，使第三名的不稳定性不被隐藏。

**方向稳定性按“与点估计同方向”定义。** 对每个（候选，维度）单元，令点方向为该单元在 200 行训练集上的总体 Spearman 点估计符号；每一次 bootstrap 复制重算同一单元的总体 Spearman，并按预先固定的容差 $10^{-12}$ 分桶：

$$
\text{sign\_stability}_{jt}=
\frac{\#\{\text{复制与点方向同号}\}}{B-n_{\text{invalid}}},\qquad
p_{\text{positive}}=\frac{n_{\text{positive}}}{B-n_{\text{invalid}}} .
$$

点估计为负时，“同号”就是负方向；零（$|\rho|\le10^{-12}$）与不可计算（非有限值）都单列计数，绝不并入负方向，$1-p_{\text{positive}}$ 也不再被当作负方向频率。这一口径描述的是**总体相关方向**的稳定性，不是低秩模型系数方向，也不是因果方向。旧口径 $P(\rho>0)$ 把方向为负的条目一律计成“不一致”，其数值 0.7225544444444444 属定义造成的偏低，本文只作历史对照。

## 核心与完整 Top-3

核心 20 个 Aroma/Flavour 维度的 Top-3 见表 7；完整 50 维、每维 3 项共 150 条目（支撑材料表（`report/tables/q2-full-top3.md|csv`））以及 15 个扩展指标在 50 维上的 Top-3（支撑材料表（`report/tables/q2-extended.md|csv`））放在附录 A，同数据 CSV 与完整溯源在 `report/tables/INDEX.json`。三张表的候选集合不同，不能相互替代或合并计数；放在附录只为控制正文篇幅，数据行未删减。



\begin{bpLTsmall}
\setcounter{table}{6}
\begin{longtable}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.0605\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.2264\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.2480\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.2369\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1962\linewidth-6pt\relax}@{}}
%% table-id: q2-core-top3 sha256:b0b98a71dc2c4db096f7dbe7b88d35dfff710b2827a9da9869200ca293c03369
\caption{核心维度 Top-3 关键化学因素、入选频率与方向}\label{tab:q2-core-top3}\\
\toprule
感官维度 & 第 1 位 & 第 2 位 & 第 3 位 & 第 3 位同模块替代候选 \\
\midrule
\endfirsthead
\toprule
感官维度 & 第 1 位 & 第 2 位 & 第 3 位 & 第 3 位同模块替代候选 \\
\midrule
\endhead
\bottomrule
\endfoot
香气·\allowbreak{}麦芽总体 & furfural｜\allowbreak{}0.490/\allowbreak{}0.9767｜\allowbreak{}+·\allowbreak{}内 & X2.acetylfuran｜\allowbreak{}0.422/\allowbreak{}0.9597｜\allowbreak{}+·\allowbreak{}混 & beta.\allowbreak{}phellandrene｜\allowbreak{}0.340/\allowbreak{}0.9457｜\allowbreak{}−·\allowbreak{}混 & methylpyrazine \\
香气·\allowbreak{}谷物 & terpinen.4.ol｜\allowbreak{}0.296/\allowbreak{}0.9628｜\allowbreak{}−·\allowbreak{}混 & furfural｜\allowbreak{}0.252/\allowbreak{}0.9566｜\allowbreak{}+·\allowbreak{}混 & propylene.\allowbreak{}glycol｜\allowbreak{}0.200/\allowbreak{}0.9008｜\allowbreak{}−·\allowbreak{}内 & —（无） \\
香气·\allowbreak{}面包 & beta.\allowbreak{}phellandrene｜\allowbreak{}0.360/\allowbreak{}0.9581｜\allowbreak{}−·\allowbreak{}混 & X4.ethyl.\allowbreak{}guaiacol｜\allowbreak{}0.302/\allowbreak{}0.9457｜\allowbreak{}−·\allowbreak{}内 & furfural｜\allowbreak{}0.224/\allowbreak{}0.9287｜\allowbreak{}+·\allowbreak{}内 & —（无同模块替代） \\
香气·\allowbreak{}焦糖 & X2.methyl.\allowbreak{}benzofuran｜\allowbreak{}0.634/\allowbreak{}0.9674｜\allowbreak{}−·\allowbreak{}内 & furfural｜\allowbreak{}0.328/\allowbreak{}0.9674｜\allowbreak{}+·\allowbreak{}混 & X2.ethyl.1.hexanol｜\allowbreak{}0.238/\allowbreak{}0.8961｜\allowbreak{}−·\allowbreak{}混 & X2.acetylfuran \\
香气·\allowbreak{}烘烤 & ethyl.\allowbreak{}hydrocinnamate｜\allowbreak{}0.558/\allowbreak{}0.9860｜\allowbreak{}+·\allowbreak{}内 & selin.11.en.4.alpha.\allowbreak{}ol｜\allowbreak{}0.228/\allowbreak{}0.9380｜\allowbreak{}+·\allowbreak{}内 & SO2.mg.\allowbreak{}L.｜\allowbreak{}0.194/\allowbreak{}0.9287｜\allowbreak{}−·\allowbreak{}混 & —（无） \\
香气·\allowbreak{}酒花总体 & ethyl\_\allowbreak{}octanoate｜\allowbreak{}0.832/\allowbreak{}0.9829｜\allowbreak{}+·\allowbreak{}混 & cis.\allowbreak{}dihydro.\allowbreak{}beta.\allowbreak{}terpineol｜\allowbreak{}0.270/\allowbreak{}0.9271｜\allowbreak{}+·\allowbreak{}风 & DMS｜\allowbreak{}0.260/\allowbreak{}0.9209｜\allowbreak{}+·\allowbreak{}风 & —（无同模块替代） \\
香气·\allowbreak{}柑橘 & citronellol｜\allowbreak{}0.596/\allowbreak{}0.9674｜\allowbreak{}+·\allowbreak{}混 & geraniol｜\allowbreak{}0.502/\allowbreak{}0.9581｜\allowbreak{}+·\allowbreak{}混 & X1.alpha.\allowbreak{}terpineol｜\allowbreak{}0.238/\allowbreak{}0.9271｜\allowbreak{}+·\allowbreak{}内 & linalool \\
香气·\allowbreak{}热带水果 & beta.\allowbreak{}phellandrene｜\allowbreak{}0.666/\allowbreak{}0.9860｜\allowbreak{}+·\allowbreak{}内 & DMS｜\allowbreak{}0.648/\allowbreak{}0.9953｜\allowbreak{}+·\allowbreak{}混 & X.\allowbreak{}E..dihydro.\allowbreak{}apofarnesal｜\allowbreak{}0.202/\allowbreak{}0.9380｜\allowbreak{}−·\allowbreak{}混 & —（无） \\
香气·\allowbreak{}贵族酒花 & ethyl\_\allowbreak{}octanoate｜\allowbreak{}0.932/\allowbreak{}0.9953｜\allowbreak{}+·\allowbreak{}混 & ethyl\_\allowbreak{}decanoate｜\allowbreak{}0.692/\allowbreak{}0.9721｜\allowbreak{}+·\allowbreak{}混 & cis.\allowbreak{}dihydro.\allowbreak{}beta.\allowbreak{}terpineol｜\allowbreak{}0.200/\allowbreak{}0.9302｜\allowbreak{}+·\allowbreak{}混 & —（无同模块替代） \\
香气·\allowbreak{}木质 & X.\allowbreak{}E..ortho.\allowbreak{}methoxy.\allowbreak{}cinnamaldehyde｜\allowbreak{}0.306/\allowbreak{}0.8837｜\allowbreak{}+·\allowbreak{}内 & hydroxy.\allowbreak{}methyl.\allowbreak{}furfural｜\allowbreak{}0.188/\allowbreak{}0.8837｜\allowbreak{}+·\allowbreak{}内 & nonan.2.ol｜\allowbreak{}0.180/\allowbreak{}0.9209｜\allowbreak{}+·\allowbreak{}内 & hydroxy.\allowbreak{}methyl.\allowbreak{}furfural \\
香气·\allowbreak{}酯香总体 & acetaldehyde｜\allowbreak{}0.928/\allowbreak{}0.9984｜\allowbreak{}+·\allowbreak{}内 & isopentyl\_\allowbreak{}acetate｜\allowbreak{}0.458/\allowbreak{}0.9752｜\allowbreak{}+·\allowbreak{}内 & isoamyl\_\allowbreak{}alcohol｜\allowbreak{}0.416/\allowbreak{}0.9752｜\allowbreak{}+·\allowbreak{}内 & X2E.6Z.\allowbreak{}farnesal \\
香气·\allowbreak{}乙酸乙酯 & X2E.6Z.\allowbreak{}farnesal｜\allowbreak{}0.616/\allowbreak{}0.9922｜\allowbreak{}+·\allowbreak{}内 & acetaldehyde｜\allowbreak{}0.360/\allowbreak{}0.9442｜\allowbreak{}+·\allowbreak{}混 & phenethyl\_\allowbreak{}alcohol｜\allowbreak{}0.348/\allowbreak{}0.9457｜\allowbreak{}+·\allowbreak{}内 & —（无） \\
香气·\allowbreak{}乙酸异戊酯 & isopentyl\_\allowbreak{}acetate｜\allowbreak{}0.610/\allowbreak{}0.9876｜\allowbreak{}+·\allowbreak{}内 & acetaldehyde｜\allowbreak{}0.448/\allowbreak{}0.9845｜\allowbreak{}+·\allowbreak{}内 & X2E.6Z.\allowbreak{}farnesal｜\allowbreak{}0.362/\allowbreak{}0.9798｜\allowbreak{}+·\allowbreak{}内 & isoamyl\_\allowbreak{}alcohol \\
香气·\allowbreak{}花香 & beta.\allowbreak{}phellandrene｜\allowbreak{}0.530/\allowbreak{}0.9907｜\allowbreak{}+·\allowbreak{}内 & acetaldehyde｜\allowbreak{}0.358/\allowbreak{}0.9860｜\allowbreak{}+·\allowbreak{}内 & X.\allowbreak{}E..dihydro.\allowbreak{}apofarnesal｜\allowbreak{}0.300/\allowbreak{}0.9411｜\allowbreak{}−·\allowbreak{}内 & —（无） \\
香气·\allowbreak{}果香 & beta.\allowbreak{}phellandrene｜\allowbreak{}0.596/\allowbreak{}0.9814｜\allowbreak{}+·\allowbreak{}混 & lactic\_\allowbreak{}acid.\allowbreak{}mg.\allowbreak{}L.｜\allowbreak{}0.166/\allowbreak{}0.8744｜\allowbreak{}+·\allowbreak{}混 & propylene.\allowbreak{}glycol｜\allowbreak{}0.158/\allowbreak{}0.7767｜\allowbreak{}−·\allowbreak{}内 & —（无） \\
风味·\allowbreak{}麦芽总体 & acetaldehyde｜\allowbreak{}0.686/\allowbreak{}0.9876｜\allowbreak{}+·\allowbreak{}风 & MeSH｜\allowbreak{}0.220/\allowbreak{}0.8977｜\allowbreak{}+·\allowbreak{}风 & X.\allowbreak{}E..alpha.\allowbreak{}ionone｜\allowbreak{}0.204/\allowbreak{}0.9364｜\allowbreak{}−·\allowbreak{}风 & X2.acetylpyrrole \\
风味·\allowbreak{}酒花总体 & ethyl\_\allowbreak{}octanoate｜\allowbreak{}0.890/\allowbreak{}0.9798｜\allowbreak{}+·\allowbreak{}混 & cis.\allowbreak{}dihydro.\allowbreak{}beta.\allowbreak{}terpineol｜\allowbreak{}0.506/\allowbreak{}0.9659｜\allowbreak{}+·\allowbreak{}混 & DMS｜\allowbreak{}0.294/\allowbreak{}0.9349｜\allowbreak{}+·\allowbreak{}混 & ethyl\_\allowbreak{}decanoate \\
风味·\allowbreak{}柑橘 & geraniol｜\allowbreak{}0.600/\allowbreak{}0.9876｜\allowbreak{}+·\allowbreak{}混 & geosmin｜\allowbreak{}0.260/\allowbreak{}0.9535｜\allowbreak{}+·\allowbreak{}混 & phenethyl\_\allowbreak{}alcohol｜\allowbreak{}0.232/\allowbreak{}0.9240｜\allowbreak{}−·\allowbreak{}内 & —（无） \\
风味·\allowbreak{}酯香总体 & acetaldehyde｜\allowbreak{}0.976/\allowbreak{}1.0000｜\allowbreak{}+·\allowbreak{}混 & isopentyl\_\allowbreak{}acetate｜\allowbreak{}0.462/\allowbreak{}0.9674｜\allowbreak{}+·\allowbreak{}内 & isoamyl\_\allowbreak{}alcohol｜\allowbreak{}0.336/\allowbreak{}0.9690｜\allowbreak{}+·\allowbreak{}混 & isopentyl\_\allowbreak{}acetate \\
风味·\allowbreak{}乙酸异戊酯 & isopentyl\_\allowbreak{}acetate｜\allowbreak{}0.716/\allowbreak{}0.9876｜\allowbreak{}+·\allowbreak{}内 & acetaldehyde｜\allowbreak{}0.534/\allowbreak{}0.9767｜\allowbreak{}+·\allowbreak{}混 & isoamyl\_\allowbreak{}alcohol｜\allowbreak{}0.410/\allowbreak{}0.9705｜\allowbreak{}+·\allowbreak{}内 & ambroxide \\
\end{longtable}
\begin{tablenote}注：单元格格式为“名称｜π/S｜方向·类型”。π 为 500 次风格内分层 bootstrap 的入选频率，S 为四种方法在维度内百分位排名的共识分；方向为总体 Spearman 相关的符号；类型按原脚本口径判定——“内”表示 |风格内相关| ≥ 0.8|总体相关|，“风”表示未满足前者且 |总体相关| ≥ 0.25、|风格内相关| < 0.5|总体相关|，其余为“混”。维度取香气 15 维全部与风味 5 个核心维度；完整 50 维见附录长表。最后一列为第 3 位候选的同模块替代项：第 3 位入选频率偏低或符号混杂时，用它说明名次的不确定性；“无”表示该参考模块内没有其他可替代候选。\end{tablenote}
\end{bpLTsmall}


表中“类别”依据绝对关联强度分类：风格内关联不低于总体关联绝对值的 0.8 倍记作“内”，未满足前式且总体关联绝对值不低于 0.25、风格内关联低于总体 0.5 倍记作“风”，其余记作“混”。该分类依据强度变化构造，未单独检验风格间符号异质性。

## 稳定性、方法一致性与同源对照

逐项稳定性读数（18 行）见表 14。全部条目的入选频率均值为 0.42045666666666665，其中 1263 / 1800 个条目低于 0.5：多数候选在重抽样下仍与同维其他候选竞争，单维 Top-3 不是稳定不变的结论。按交付的严格共识榜（50 维每维 3 项，共 150 条）统计，其中 95 条的 $\pi<0.5$；这 95 条里方向为负的 29 条、为正的 66 条。也就是说，“入选不稳定”与“方向不稳定”是两件事，下面的方向一致率再高也不能抵消这一条。

三次重复之间的集合一致性为 0.8748333333333335，明显高于四方法之间的一致性 0.2091111111111111；也就是说，不稳定主要来自方法口径差异，而不是重复抽样噪声。按点估计口径（每次重复取点估计 Top-3 再平均）的平均两两 Jaccard 为 0.19766666666666666，与 $\pi$ 优先口径不同，两者描述不同的集合规则，不能互相替换。

必须强调 Jaccard 的语义：它是两个集合的交集除以并集，**不是识别准确率**。按定义，两个三元集合若恰有 1 个条目相同，Jaccard 即 0.2（这是定义恒等式，不是实测值）；本问的平均 Jaccard 见 0.2091111111111111，落在该量级附近，意味着多数方法对之间只有 1 个条目重合、剩余两个条目不同。这是“方法对候选排序的分歧程度”，而不是“哪一方正确”。


\begin{bpfigure}
%% figure-id: FIG-0046 sha256:bb03ab24177c345c2ef3ba0e251f78d2b1834a210b93d59c0872094dc6e84ab9
%% figure-src: ../figures/confirmatory_v2/Q2-stability.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q2-stability.png}
\captionof{figure}{问题二：Top-3 入选频率 π、符号一致率与旧口径 p\_positive；预登记的种子块计划为冻结种子块参数扰动（计划 n=2，补充块单列）。}
\end{bpfigure}


方向一致率方面，现行口径的均值为 0.9816877777777778：在 600 个交付格（50 维 × 4 方法 × 3 名次）× 500 次 × 3 重复共 $900{,}000$ 个 bootstrap 复制上，只有极少数复制与该单元的点估计方向相反。作为历史对照，旧口径 $P(\rho>0)$ 为 0.7225544444444444，它把方向为负的条目一律算作“不一致”，因此天然偏低，**不得再称为符号稳定性**。

分项计数与均值一起读，两个分母**不能混算**：交付的 1800 个（四方法 × 三重复池化）条目中，点估计方向为负 503 个、方向不确定 0 个；复制层面零方向 0 次、不可计算 0 次（都单列，不并入任何方向，也不写成“负方向频率”）。150 条严格共识中负 36 条、正 114 条；这 36 条的逐条方向一致率 0.978–1.000（见 `sign_stability_summary.json`），低旧值来自定义而非方向不稳。但方向稳定不等于入选稳定：其中 29 条 $\pi<0.5$、仅 7 条 $\pi\ge0.5$。这些条目的替代候选见表 7 最后一列，第 3 位频率偏低时应与正选并读。

附件 `6.csv` 的 44 行化学—感官交叉相关按名称对齐后，平均秩相关为 0.9210176180408739（严格子集 0.9080152788388083）。两个限制：与本研究同源，属同源对照而非外部验证；比较用绝对关联排序，只说明排序强度一致，不说明方向正确。按位置对齐的旧值偏低正是列错位三列所致，已作历史记录。

## 化学合理性：机理支持与关联标志分层

**酯类与果香。** 乙酸异戊酯、乙酸乙酯等是与酵母发酵相关的酯类，支持“酯香候选以酯类为主”的类别解释；啤酒化学—感官研究亦显示酯类与醇类共同变化，单一变量的重要性可能替代共相关的其他化合物 [2]。因此 Top-3 出现非酯类条目（如醛类）应读作代谢或工艺关联标志，不能由排序推导添加效果——**该解释在本数据上属待证**，本文未做加标或酿造干预。

**萜烯类与酒花柑橘、花香。** 香茅醇与香叶醇具描述词一致性，萜烯可随酒花或香料引入，风格差异也可能改变其出现方式 [2]。表 7 中标“混”的候选说明其排序不能脱离配方与风格解释，本文不对其作用强弱排序。

**高级醇、有机酸与醇厚、酸感。** 甘油等可与口感联系，有机酸与酸感具类别一致性 [2]；但未进 Top-3 的已知风味物质不能据此排除，共线候选间的名次差也不等于作用强弱。

**硫化物、双乙酰与缺陷。** 双乙酰可由 $\alpha$-乙酰乳酸转化、也可被酵母还原去除 [3]；DMS 既有热过程前体途径，也可由 DMSO 还原产生 [4]。这些机理支持把双乙酰与 DMS 作为缺陷监测对象，但统计排序与已知直接致味物并非一一对应，因此问题三直接约束已测得的 DMS、双乙酰与 4VG，而不以 Top-3 替代化学检测。

## 问题二的实际答案

1. **给出了什么**：严格单体 216 项（另有 15 项扩展指标单列）在 50 维上的逐维 Top-3，带入选频率 $\pi$、共识分 $S$、总体相关方向与同模块秩 4–10 替代候选；核心 20 维见表 7，完整 150 条与扩展表见附录 A 索引。附件 2 描述性网络（231/645/52）与训练折内网络（732 边/51 分量）是两种用途的独立产物。
2. **稳定性到什么程度**：方法间 Top-3 平均两两 Jaccard 0.2091111111111111、跨重复 0.8748333333333335；$\pi$ 均值 0.42045666666666665，1800 个交付条目中 1263 个低于 0.5；方向一致率 0.9816877777777778（旧口径 0.7225544444444444）。
3. **证据归属**：主结论为问题二主实验的共识榜结果；稳健性为其预登记的种子块计划（计划内参考块与扰动块，另有登记后补跑的一块）。登记原文见附录 B.4。
4. **限制**：Top-3 是排序假设而非已识别清单，150 条中 95 条入选频率低于 0.5；方向稳定不等于入选稳定；同期关联不是因果；同源对照不是外部验证。

**证据登记：** 主结论与稳健性结论的登记原文、证据引用与限制见附录 B.4。

## 问题二的作用边界

第一，**同期关联不等于因果**：任何“某化合物决定某风味”的表述都不成立，Top-3 是排序假设，需独立干预实验检验。

第二，**集合一致性不等于识别准确率**：方法间与跨重复 Jaccard 只描述排序分歧度，没有真值可对照。

第三，**方向一致率适用面很窄**：它只说同一单元总体相关方向在重抽样下可复现，既不涉及低秩系数方向，也不涉及因果；且 36 条负方向条目中 29 条仍属低入选频率。

第四，**同源对照不是外部验证**：`6.csv` 与描述性网络都与附件同源，只核对流程未把排序弄乱；描述性网络只是阈值图结构，不是功能模块或因果网络。

第五，**稳健性只改变冻结种子块**（计划内两块，另有补充块单列），固定种子复跑只证确定性重现，详见第 7 章。

# 问题三：风格条件生成与声明模型下的迁移

问题三包含两个不同对象：其一是按风格生成化学谱的条件生成器，其二是把 Pils/Lager 谱在声明约束下迁移到 Tripel 的优化算子。两者的指标、失败模式与边界都不同，本文分开评价，不合并为单一的“问题三成功率”。

## 生成目标与评价对象

主任务学习已出现风格的条件分布 $p(X\mid s)$，采用固定 3 折风格内留出：每次重复 22 个风格各 3 折，设计格总数 198、生成样本 750 份。能量距离只在**可估格**上算：177 个可估格、729 份可估生成；另有 21 个格因对照侧样本不足被排除并单列。可估数与总数不可互换。标签不进入化学边际或 Copula 的似然拟合，只用于独立的感官代理与评价。

## 原始抽样与约束设计谱的分离

本轮同时保存 `raw`（条件生成原始抽样）与 `design`（约束投影后设计谱），目的是让投影代价可测。33 个已校准线性列在抽样层即施物理非负下界，故两份谱的负浓度格数均为零——这是构造保证，不是“生成质量好”的证据。



\begin{bptable}
\setcounter{table}{7}
%% table-id: q3-raw-design sha256:ca7b31eddc30c870d75ad0b38c9024a5091e13432c9da81f84d441e3354d29f6
\captionof{table}{原始抽样与约束设计谱的对照}\label{tab:q3-raw-design}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.2932\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1235\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1065\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.4448\linewidth-6pt\relax}@{}}
\toprule
指标 & 未约束原始生成 & 约束后设计谱 & 说明 \\
\midrule
归一化经验能量距离 V & 0.8736 & 0.8727 & 按 n\_\allowbreak{}gen 加权池化；越小表示生成谱越接近真实谱 \\
无符号能量 V & 16.0178 & 15.9999 & 非负的分布差异量 \\
带符号能量 U & 1.6044 & 1.6154 & 可负、不截零；U 的符号只表示带符号统计量的读数方向，不用它推断偏移方向或过度分散 \\
约束满足率 & 0.1267 & 1.0000 & 同时满足全部声明约束的样本比例；设计侧由投影循环保证 \\
负浓度格数 & 0 & 0 & 线性非负约束被违反的格数 \\
约束投影轮数（均值） & — & 1.3232 & 逐格迭代直到最大残差 ≤ 1e-9；允许轮数上限 12 \\
约束投影轮数（最大） & — & 4 & 允许轮数上限 12，本轮实际最大 4 \\
约束投影最大残差 & — & 0.0000 & 投影后从写出的样本文件复核 \\
全列平均绝对改动（标准化单位） & — & 0.0089 & 约束投影相对未约束原始抽样的逐列平均绝对改动 \\
改动最大的列：二甲基硫（DMS） & — & 0.5720 & 约束投影相对未约束原始抽样的逐列平均绝对改动 \\
改动最大的列：双乙酰（2,3-丁二酮） & — & 0.2888 & 约束投影相对未约束原始抽样的逐列平均绝对改动 \\
改动最大的列：反-2-壬烯醛 & — & 0.0513 & 约束投影相对未约束原始抽样的逐列平均绝对改动 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：左侧为未施加约束的原始条件生成，右侧为约束投影后的设计谱。能量距离按可估格加权池化，V 与 U 是同一能量统计量的无符号与带符号读数。约束满足率在未约束原始生成上为 0.1267，在设计谱上为 1.0000，后者是投影循环的构造性质，不能当作分布质量证据。设计谱中真实化学反-2-壬烯醛的增加条数为 0；感官 t2n 代理的增加条数另计（366 / 750），两者是不同命题，不能互相替代。改动量以标准化单位给出，只描述“投影改了多少”，不是约束残差。\end{tablenote}
\end{bptable}


两项必须分开读：能量距离从原始抽样到设计谱的变化量度量“投影让分布偏离多少”；约束满足率从 0.12666666666666668 变为 1 则是**构造性质**（投影保证），不提供真实酿造可行性信息。未约束原始抽样只有小部分满足全部约束，说明缺陷约束在生成中是有效约束，但这同样只是数学筛查。

**两个缺陷命题必须分开报告。** 真实化学列反-2-壬烯醛在设计谱中**不增**：相对原始抽样增加 0 条（最大增量 0）。**感官代理** t2n 仍增加 366 条（0.488，分母 750 份生成）。前者是化学列检查通过，后者说明感官口径的“老化风味不增”未满足；代理不是实测感官、也未写成硬约束，本文不通过改措辞把它算作已满足——要变成硬约束需另行检查可行域并重跑。

## 含编码质量点的层次收缩边际

对每个变量采用风格内经验边际与池化边际的层次收缩。收缩权重不是风格行数，而是该风格该列的**有效观测数** $n^{\mathrm{eff}}_{j,s}$（未填补、非缺失）：

$$
\widehat F_{j,s}=\omega_{j,s}\widehat F^{\mathrm{emp}}_{j,s}+(1-\omega_{j,s})\widehat F_j^{\mathrm{pool}},
\qquad \omega_{j,s}=\frac{n^{\mathrm{eff}}_{j,s}}{n^{\mathrm{eff}}_{j,s}+\kappa}.
$$

经验边际只用原始有效观测：填补值即使写入输入矩阵也不进入经验样本；$n^{\mathrm{eff}}_{j,s}<3$ 时走预声明的 pooled fallback 并输出状态；连续部分与地板质量点分母分别声明。生成外层/内层、迁移目标/源边际四个入口共用同一套边际语义。

有地板编码的变量另以混合分布保留编码质量点：

$$
F_{j,s}^{\mathrm{obs}}(v)=\pi_{j,s}^{\mathrm{floor}}\mathbf1\{v\ge v_j^{\mathrm{floor}}\}
+(1-\pi_{j,s}^{\mathrm{floor}})F_{j,s}^{\mathrm{nonfloor}}(v).
$$

按相应概率抽取编码值，其余用经验分位数插值。该结构避免把大量重复地板值平滑成虚假连续浓度：37 个对数列的 755 个校准零值与 142 列的 6807 个共享地板编码都作为质量点保留。

## 收缩高斯 Copula

将条件边际映射至高斯坐标，估计风格依赖结构：

$$
z_{ij}=\Phi^{-1}[\widehat F_{j,s_i}(x_{ij})],\quad
\widehat R_s=\eta_s\widehat R_s^{\mathrm{emp}}+(1-\eta_s)\widehat R_{\mathrm{shared}},
\quad \eta_s=\frac{n_s}{n_s+\kappa_R}.
$$

相关矩阵特征值截断至 $\ge10^{-6}$，归一化后向单位阵收缩 5%；采样 $z^*\sim N(0,\widehat R_s)$，经 $u^*=\Phi(z^*)$ 与逆边际得 $X^*$。小样本风格更依赖池化信息。

参数选择在每个外层折内部用该折自己的 3 个内层折完成：$\kappa\in\{0,5,15\}$、$\kappa_R\in\{20,50,100\}$ 的 9 个组合逐折选择，不跨折池化、不用外层留出误差挑参。（先导轮曾把逐折选择表平均写回，使留出信息进入超参数；本轮已改为逐折独立。）

## 评价量：分布距离与结构统计

归一化经验能量距离为

$$
\mathcal E^2_{\mathrm{norm}}=\frac{\max(\mathcal E^2,0)}{D_{\mathrm{ref}}},
\qquad
\mathcal E^2=2\mathbb E\|X-Y\|-\mathbb E\|X-X'\|-\mathbb E\|Y-Y'\|,
$$

其中 $D_{\mathrm{ref}}$ 是该风格训练行的典型两两距离（$D_{\mathrm{train}}$），归一化只用它除一次。$V$ 与 $U$ 不是同一个量的两种写法，**对角项与分母都不同**，必须写清：

$$
V=2\overline{d(G,R)}-\frac{\sum_{i,i'}d(G_i,G_{i'})}{m^{2}}-\frac{\sum_{j,j'}d(R_j,R_{j'})}{n^{2}},
\qquad
U=2\overline{d(G,R)}-\overline{d(G,G)}^{\ast}-\overline{d(R,R)}^{\ast},
$$

其中 $m,n$ 为生成与参照样本数，$\overline{d(\cdot,\cdot)}^{\ast}$ 在 $m(m-1)$、$n(n-1)$ 个**非对角**对上取平均。$V$ 用全体有序对之和除以 $m^2$（含对角零项），$U$ 用非对角均值，故 $V-U=\frac{\sum d(G,G)}{m^{2}(m-1)}+\frac{\sum d(R,R)}{n^{2}(n-1)}\ge0$、$V\ge U$ 且 $V\ge0$。$U$ 可负；本文不截零、不开方，也**不以其正负判断偏移方向或过度分散**（那需另做检验，本文未做）。

此外分别报告边际误差、依赖谱 MAE、多样性（样本间平均距离）、最近邻距离、复制率与边饱和比例。它们各自回答一个问题，不能互相替代。

## 生成质量与参照对照



\begin{bptable}
\setcounter{table}{8}
%% table-id: q3-quality sha256:ef403bd2a8424723c611d5bd0afa1a057b453eacb0b271c7e5bf6b4c07d7de78
\captionof{table}{生成方案的分布质量与同协议参照对照}\label{tab:q3-quality}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.2132\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0918\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0855\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0966\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0966\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0855\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0855\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.2132\linewidth-6pt\relax}@{}}
\toprule
方案 & 归一化能量距离 V & 带符号 U & 多样性 & 最近邻距离 & 精确复制率 & 边饱和比例 & 范围说明 \\
\midrule
分层收缩混合 Copula 设计谱（主方案） & 0.8727 & 1.6154 & 17.4190 & 15.5202 & 0.0000 & 0.1237 & 能量/\allowbreak{}U/\allowbreak{}多样性/\allowbreak{}最近邻按 177 格 ·\allowbreak{} 729 份加权；复制率与边饱和按 231×750 格 \\
仅共享相关 Copula & 0.8718 & 1.5472 & 17.6151 & 15.8771 & 0.0000 & 0.1244 & 能量/\allowbreak{}U/\allowbreak{}多样性/\allowbreak{}最近邻按 177 格 ·\allowbreak{} 729 份加权；复制率与边饱和按 231×750 格 \\
风格内经验 Copula & 0.8655 & 1.4990 & 17.0534 & 14.4323 & 0.0000 & 0.1173 & 能量/\allowbreak{}U/\allowbreak{}多样性/\allowbreak{}最近邻按 177 格 ·\allowbreak{} 729 份加权；复制率与边饱和按 231×750 格 \\
独立边际 & 0.8697 & 1.4959 & 17.6165 & 16.3891 & 0.0000 & 0.1277 & 能量/\allowbreak{}U/\allowbreak{}多样性/\allowbreak{}最近邻按 177 格 ·\allowbreak{} 729 份加权；复制率与边饱和按 231×750 格 \\
源样本重采样参照 & 0.8137 & 0.1806 & 18.3913 & 16.0210 & 0.0000 & 0.1197 & 同风格训练行重采样参照，不是生成模型；能量/\allowbreak{}U/\allowbreak{}多样性/\allowbreak{}最近邻按 177 格 ·\allowbreak{} 729 份加权；复制率与边饱和按 231×750 格 \\
范围口径：21 个可估风格 ·\allowbreak{} 177 个可估格池化（归一化 V） & 0.8727 & 1.6154 & — & — & — & — & n\_\allowbreak{}gen=729；未归一化 V = 15.9999；与主方案同值，用于声明池化范围 \\
范围口径：Tripel/\allowbreak{}Kriek/\allowbreak{}Lambic 三风格 ·\allowbreak{} 27 个格单独池化（归一化 V） & 1.8079 & 1.0279 & — & — & — & — & n\_\allowbreak{}gen=147；未归一化 V = 33.7829；与上一行不是同一范围，不可互换 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：前五行为同一评价协议下不同采样方案的设计谱比较，能量距离越小越好；U 可负、不截零。\textbf{分母不同，不可混读}：归一化能量距离、带符号 U、多样性与最近邻距离按 177 个可估格、729 份生成的 n\_gen 加权口径计算；精确复制率与边饱和比例的分母是 231×750 = 173250 个存储单元格（750 行），其中包含未进入能量距离的 21 个不可估格 / 21 份生成，因此两类指标的分母不是同一批格。四个分布侧指标各自回答不同问题，不可互相解释：多样性为生成样本在标准化空间中的两两欧氏距离均值（按固定抽样次数子采样）；最近邻距离为每个样本到最近样本距离的均值；精确复制率为与已有行完全重复的行占比；边饱和比例为落在声明边界上的单元格占比（地板编码、观测支撑上下界、线性列零值）。源样本重采样参照直接复用同风格的训练行，其能量距离低于各生成方案；该行的作用是给出“不生成”的参照，不能与生成模型等同比较。后两行只声明池化范围：21 个可估风格 177 个可估格的池化值与三风格单独池化值不可互换，两者的带符号 U 也随范围变化，引用时必须写明范围。\end{tablenote}
\end{bptable}


设计谱的归一化能量距离 0.8726874826148657、未归一化 $V=$ 15.99994601104919、带符号 $U=$ 1.6153896894821214（只作并列读数，不解释符号）；多样性 17.4190014733392、最近邻 15.52015363005555、复制率 0、边饱和比例 0.1236709956709957。

关键对照是**源样本重采样**：同样本量、同风格、直接对训练行重采样得到的参照谱（表 9 的“源样本重采样参照”行），其归一化能量距离低于设计谱的 0.8726874826148657。也就是说，在本评价口径下，**生成器没有超过“直接重采样真实样本”这一最简参照**。这是本问最重要的负结果，本文据此明确不宣称生成模型优于基线。

同一张表还给出更不利的一条：**仅共享相关 Copula、风格内经验 Copula、独立边际三个对照方案的 $V$ 也都略低于交付的主方案**。因此“收缩混合 Copula”这一配置在本数据上并不占优；各方案之间的差距小于它们与重采样参照的差距，本文不据此宣称本生成器结构更优，也不把并列对照压成一句“主方案最好”。


\begin{bpfigure}
%% figure-id: FIG-0047 sha256:5de16529353bfeb2356d658dd72185713fe0ea819757a13e97dd8f8ab5866546
%% figure-src: ../figures/confirmatory_v2/Q3-energy-comparison.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q3-energy-comparison.png}
\captionof{figure}{问题三：归一化经验 V 能量距离（V/D\_train）对照；生成设计谱 0.8727 未优于源样本重采样 0.8137，带符号 U 单列不截零。}
\end{bpfigure}


依赖谱 MAE（0.005622900215633008）与协方差迹比（0.8370976437048002）显示 Copula 相对独立边际有收益，但三类收缩方案之间的能量距离差异小于它们与重采样参照的差异，故“依赖结构怎么估”不是主导误差来源。边际误差 0.49331012037675936 说明单变量分布未被完全复现；感官代理画像的池化秩相关 0.9045378151260504、逐格均值 0.4710350060024013、平均绝对误差 0.22434160673912668，同样只是代理口径。

## 三种目标风格必须与池化结果分开

设计谱在所有可估风格上按生成样本数加权池化为 0.8726874826148657（177 格、729 份），而 Tripel/Kriek/Lambic 单独池化（27 格）明显更高：未归一化 $V=$ 33.78288729066554，归一化值与 $U$ 见表 9。两口径不可互换或相减，未作显著性检验；三个小风格样本极少（Kriek 约 10 行、Lambic 约 11 行、Tripel 约 28 行），收缩后差异被平均，故**不得**用池化值代替三风格画像。

**逐风格缺陷如实列出。** 多数风格归一化能量距离在零点几量级，但 **Kriek 明显离群**（未归一化 $V$ 约 140、归一化约 7.4，为池化值 0.8726874826148657 的 8 倍以上），Tripel 反而最好（归一化约 0.28）。这一缺陷本轮未修好，使用 Kriek 生成结果必须按逐风格读数解读。可估风格/格的分母都小于设计格总数（198），被排除的格不填零、不并入；90 条感官 t2n 代理高于其风格内界，也是逐格诊断的一部分。


\begin{bpfigure}
%% figure-id: FIG-0048 sha256:69dda2f9ab9dcab9c926819e471bf0079de5a1ceb27f7401db6f25b135e73631
%% figure-src: ../figures/confirmatory_v2/Q3-per-style-energy.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q3-per-style-energy.png}
\captionof{figure}{问题三：逐风格 n\_gen 加权能量距离（21 可估风格）；三风格池化 1.8079 与 21 风格池化 0.8727 不得互替。}
\end{bpfigure}


约束核验（逐条明细见表 15）共 19670 通过、8211 条件成立、619 不可辨识、0 不可行，可核验比例 0.6901754385964912。分层各有来源：

- **不可识别（619）**：4VG 上界 494 条（源值缺测或地板编码）与线性非负 125 条；不计通过、不计失败。
- **条件成立（8211）**：双乙酰 750、反-2-壬烯醛 750、老化酒花代理 750、线性非负 5961；成立依赖训练折派生界、填补假设或代理变量。
- **已验证（19670）**：DMS 上界 750 与线性非负 18664 等，可在写出的样本文件上直接复核。

把不可识别与条件成立两类并入“通过”，会把“没测到”和“依赖假设”说成“已验证”；本文不这样做。


## 迁移：变量空间、目标与约束

迁移只在声明的凸二次规划下成立，因此必须把“模型”写全，并把它**实际用到的数据范围**写清——这里有一处容易含糊的地方，本文分开写：

数据范围分开写：每个外层折的**迁移上下文**由该折训练行中**排除被迁移源风格**后的行组成，目标均值、目标主成分/相关矩阵与感官代理都在其上估计；但**分位数锚点的源侧边际由该折训练集中的源风格行**拟合再经目标边际逆变换，所以“所有拟合都排除了源风格”是错的——源分位数边际确实用了训练源样本（不含被迁移那一行本身），只是不进入目标参照与代理。被迁移的源样本本身只作查询：原始值进入盒约束的源值上限与 $z_{\mathrm{source}}$。

变量取折叠标准化的存储空间 $z\in\mathbb R^{231}$，$D=\operatorname{diag}(s_d)$ 为目标风格主成分得分的标准差。声明的二次规划为

$$
\min_{z,t}\ (z-z_{\mathrm{ref}})^\top Q_t(z-z_{\mathrm{ref}})
+\lambda\|z-z_{\mathrm{anchor}}\|_2^2+\eta\sum_k t_k
\quad\text{s.t.}\quad
-t\le z-z_{\mathrm{source}}\le t,\ \ t\ge0,\ \ l\le z\le u,\ \ Az\le b,
$$

其中秩 10 的目标二次型写成与实现一致的形式

$$
Q_t=P^\top D^{-1}C^{-1}D^{-1}P,
\qquad C=0.9\widehat R_T+0.1I,
$$

$P$（$10\times231$）为主成分载荷，$\widehat R_T$ 为得分相关矩阵，$C^{-1}$ 为其收缩逆。**尺度只除一次**：得分 $s=D^{-1}P(z-\bar z_T)$，代回 $s^\top C^{-1}s$ 即为上式（早前两侧各平方一次、写成 $D^{-2}$ 的写法与实现不符，已更正）；中心化用拟合时的 $\bar z_T$，故“目标均值到自身”距离为零。$z_{\mathrm{anchor}}$ 为分位数保序锚点；$\eta>0$ 时最优解满足 $t=|z-z_{\mathrm{source}}|$，$t$ 在最优处消去。$l,u$ 承载声明支撑与四条逐坐标化学上限（DMS、双乙酰、4VG、反式-2-壬烯醛均不高于源样本），$Az\le b$ 是唯一一条 `stale_hops` 线性代理行——**代理**，不是实测化学约束。

**代理半空间的右端按截距修正。** 代理为 $f(z)=a^\top z+c$，要求 $f(z_{\mathrm{new}})\le f(z_{\mathrm{source}})+\epsilon$，整理后应为

$$
a^\top z_{\mathrm{new}}\le b,\qquad b=f(z_{\mathrm{source}})-c+\epsilon=a^\top z_{\mathrm{source}}+\epsilon ,
$$

$\epsilon=10^{-9}$。构造、预检、均值投影、QP、问题哈希、残差与证书都用同一个 $b$；九折截距 $c$ 全为负（-0.10860385674698787 至 -0.013708071262500055），漏掉 $-c$ 是把可行域收紧而非放宽。恒等式误差最大 8.274037093680878e-17，半空间残差最大 0。

求解用 ADMM 原-对偶：盒约束与单条半空间的投影用二分法，秩 10 二次型用 Woodbury 求逆；每个求解写入证书（问题哈希、状态、目标值、原/对偶残差、迭代数、可行性、KKT 平稳性与半空间字段 $a,c,b$、残差、增量），目标梯度另与中心差分核对，唯一允许偏差是 $|z-z_{\mathrm{source}}|=0$ 处的 $L_1$ 折点。若某次未达容差，交付点回退到源样本并记为“迁移未完成”、**不计入成功**；本轮计划内 198 次全部最优、无回退（fallback 份额 0）。注意该次数是**重复求解、不是等量独立啤酒**：设计为 11 源 × 9 训练上下文（3 重复 × 3 外折）× 2 策略。

## 求解证书与独立复算



\begin{bpLTsmall}
\setcounter{table}{9}
\begin{longtable}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.4064\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1576\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.4041\linewidth-6pt\relax}@{}}
%% table-id: q3-qp-certs sha256:7293aaac37ed419ad979138219e000dfd9b0b199c3bf9127a2bbbf01f100a12b
\caption{二次规划求解证书摘要}\label{tab:q3-qp-certs}\\
\toprule
指标 & 数值 & 口径与说明 \\
\midrule
\endfirsthead
\toprule
指标 & 数值 & 口径与说明 \\
\midrule
\endhead
\bottomrule
\endfoot
QP 求解次数 & 198 & 两种锚定策略分别 99 /\allowbreak{} 99 次 \\
求解设计：源 × 训练上下文 × 策略 & 11 × 9 × 2 & 同一源在 9 个训练上下文里被重复求解：这是重复求解，不是独立样本数 \\
状态 optimal & 198 & solver 返回最优 \\
状态 infeasible & 0 & 声明可行域内未出现不可行问题 \\
状态 未收敛 & 0 & 未出现未收敛 \\
唯一问题哈希数 & 198 & 逐问题哈希互不相同（不同问题实例），但同一源在 9 个训练上下文中被重复求解 \\
最大原始残差 & 9.995e-09 & ADMM 一致性分裂的 max |z − w| \\
最大对偶残差 & 2.105e-10 & 缩放对偶残差 rho·\allowbreak{}max|w\_\allowbreak{}k − w\_\{k−1\}| \\
最大约束违反 & 0.0000 & box 界与半空间约束的违反量 \\
最大 KKT 平稳性残差 & 4.069e-09 & 平滑梯度 + L1 次梯度 + 紧约束乘子的平稳性 \\
stale 半空间右端修正：截距 c 范围 & [-0.1086, -0.0137] & 每折截距由 b = a'z\_\allowbreak{}source + 1e-9 反解，198 个证书全部为负 \\
stale 半空间最大残差 & 0.0000 & 用修正后的右端复核 a'z − b \\
stale 半空间恒等式误差最大值 & 8.274e-17 & 预测值与代理预测通道的恒等式误差 \\
源状态分层：verified /\allowbreak{} conditional /\allowbreak{} not\_\allowbreak{}identifiable /\allowbreak{} failed & 3465 /\allowbreak{} 198 /\allowbreak{} 99 /\allowbreak{} 0 & 共 3762 条上界记录，可核验分母 3663；不可识别记录不计入分母，也不计为失败 \\
目标梯度有限差分最大绝对差 & 2.358e-09 & 198 个检查点的最大值 \\
目标梯度有限差分最大相对差 & 4.447e-05 & 同一批检查点 \\
策略分布 & 99 /\allowbreak{} 99 & QP·\allowbreak{}源锚定 /\allowbreak{} QP·\allowbreak{}分位数锚定 \\
最大迭代次数 & 49 & ADMM 迭代上限内收敛 \\
内部不一致记录 & 0 & 证书字段之间的自洽检查 \\
\end{longtable}
\begin{tablenote}注：本表是 198 个逐问题凸二次规划证书的汇总，不是原生优化验证，也不保证全局最优之外的任何性质。198 次求解是 11 个源 × 9 个训练上下文 × 2 个策略的重复求解，不能当作独立样本数。残差是求解器收敛读数，不是迁移准确率；约束违反为 0 说明解在声明的可行域内，可行域本身（box 界、一条 stale 半空间、秩 10 二次目标与两处正则项）由模型声明固定。stale 半空间右端已修正为 b = a'z\_source + 1e-9，截距 c 全为负、半空间残差与恒等式误差在浮点误差内；这只说明约束实现一致，不说明 stale 代理是实测老化指标——它是训练折内的岭回归代理。目标梯度有限差分只核对实现中的梯度与目标函数一致。\end{tablenote}
\end{bpLTsmall}


计划内 198 次求解全部最优（198；infeasible / 未收敛 0 / 0），最大原残差 9.994750582720258e-9、最大对偶残差 2.1051915766179263e-10、最大约束违反 0，均低于声明容差 $10^{-8}$；目标梯度与中心差分最大绝对偏差 2.3575514873641623e-9。三条读数须与“198 个 optimal”并列：

- **落在容差边界**：198 个解中 **131 个恰落在 1e-9 容差边界**（qp-quantile 67 + qp-source 64；495 行全策略合计 189/495），代理约束在这些点活跃，“不增”只在声明容差内成立，不是严格不等。
- **代理字段经独立复算**：$b=a^\top z_{\mathrm{source}}+\epsilon$、$f(z_{\mathrm{source}})=a^\top z_{\mathrm{source}}+c$、$\delta=(a^\top z-b)+\epsilon$ 违反均为 0 例，$c$ 全为负（-0.10860385674698787 至 -0.013708071262500055），恒等式误差最大 8.274037093680878e-17；另 4 行代理残差有 $10^{-9}$ 量级差异，因记录端用 $\max(0,\Delta-10^{-9})$、审计端用 $\max(0,\Delta)$，已披露不平滑。
- **不是原生优化验证**：证书只证明“在声明模型下找到满足 KKT 的点”。本实验是一批带逐问题证书的 QP，而非“一个声明优化模型 + 一个解文件”，工具据此对优化可行性与优化目标检查具名拒绝，本文不声称通过。

## 不增率的饱和性、完整可行域基线与代理越界



\begin{bptable}
\setcounter{table}{10}
%% table-id: q3-transfer-stages sha256:fd7d3a3dff6c48883bd213e84039bb29216d0479571e0a0ee376882c4a50777e
\captionof{table}{四种迁移策略的阶段指标}\label{tab:q3-transfer-stages}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.2052\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0855\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0855\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1109\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1218\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1327\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1077\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1187\linewidth-6pt\relax}@{}}
\toprule
策略 & 转移能量 V & 归一化 V & 四条化学列不增率 & 老化酒花代理不增率 & 综合不增率（含代理） & fallback 份额 & 目标均值自距 \\
\midrule
QP·\allowbreak{}分位数锚定（交付策略） & 2.0799 & 0.1134 & 1.0000 & 1.0000 & 1.0000 & 0.0000 & — \\
QP·\allowbreak{}源锚定 & 7.0906 & 0.3900 & 1.0000 & 1.0000 & 1.0000 & 0.0000 & — \\
源固定（平凡对照） & 7.1963 & 0.3958 & 1.0000 & 1.0000 & 1.0000 & 0.0000 & — \\
目标均值投影（盒约束诊断对照） & 6.9415 & 0.3794 & 1.0000 & 0.4141 & 0.4141 & 0.0000 & 4.749e-16 \\
目标均值投影·\allowbreak{}完整可行域（参照基线） & 6.3792 & 0.3485 & 1.0000 & 1.0000 & 1.0000 & 0.0000 & — \\
\bottomrule
\end{tabular}
\begin{tablenote}注：转移能量按同一批目标参考行计算，越小表示迁移后的谱越接近目标风格。四条化学列不增率只统计二甲基硫、双乙酰、4-乙烯基愈创木酚、反-2-壬烯醛四条 cap；综合不增率另要求老化酒花代理不增。盒约束均值投影（不含半空间）的综合不增率为 0.4141，其偏低完全由代理越界驱动，四条化学 cap 仍全部满足，因此该值不等于“四条 cap 有相应比例不满足”。完整可行域均值投影（box ∩ 同一条 stale 半空间）的综合不增率为 1.0000，它是本轮新增的参照基线：与交付 QP 策略有相同的可行域和非增性质，但转移能量更高，因此“非增率 = 1”本身不能区分策略优劣。源固定策略是不做任何迁移的平凡对照，其四条化学列与综合不增率同样为 1，因此不能把 1.000 读成迁移效果；老化酒花代理是训练折内的岭回归代理，不是实测老化指标。该复合指标在计划内两个执行块与补充种子块中均为 1.000（有界饱和），min-value 规则下“min 1 ≥ 1”不构成改善或强稳健证据。盒约束均值投影是诊断对照，其代理越界记录只属该参照控制，不参与交付判定。fallback 份额为 0 表示没有迁移结果被退回源谱。目标均值自距是“目标均值到自身”的距离，只对盒约束均值投影策略有意义；早期中心化口径下的同名值偏大，已被修复，不再引用。\end{tablenote}
\end{bptable}


先分清两个量（台账旧称“逐列不增率”，本文统一称“综合不增率”）。**四条化学列**（DMS、双乙酰、4VG、反-2-壬烯醛）的不增率为 1（逐列 1 / 1 / 1 / 1），四种策略下均未被违反。**综合不增率**另要求 `stale_hops` 代理不增：交付 1、源锚定 1、源固定 1；盒约束诊断对照 0.41414141414141414 的低值完全由代理越界驱动。

**完整可行域基线是公平对照的主体。** 目标均值投影到与 QP 完全相同的可行域（box ∩ 同一条 stale 半空间、同一修正后 $b$）：$V=$ 6.379240954520166、综合不增率 1；交付 QP 为 $V=$ 2.0798861351916886。两者不增率都是 1，但 QP 转移能量更低——唯一一处“同约束下 QP 优于简单基线”的对照；旧盒约束诊断（$V=$ 6.94148284204317、非增率 0.41414141414141414）不在同一可行域内，只能作诊断。

但“不增率 = 1”不能区分策略：`source-fixed` 不改变任何化学值、不增率必然为 1。更根本的是**指标饱和**——$c^{\mathrm{new}}\le c^{\mathrm{source}}$ 逐列成立时比值恒为 1，没有改善空间；稳健性计划内两块与补充块同为 1.000，也不提供信息。

**迁移侧的两个缺陷命题分开读。** 真实化学列反-2-壬烯醛不增率为 1（化学命题成立）；**感官 t2n 代理**在同一批迁移行上仍有 0.06060606060606061 的比例增加，说明代理口径下“老化风味不增”未成立，本文未把感官 t2n 设成硬约束。

**源状态分层（四类判定）。** 交付策略 3762 条上界记录：可核验 3465、条件 198、不可识别 99、失败 0，可核验分母 3663；不可识别的 99 条 = 81 条 4VG 地板存储码（源物理值=新值=0，上界近乎空转）+ 18 条源双乙酰缺测；条件的 198 条 = 99 条反-2-壬烯醛源值上界（$c^{\mathrm{new}}\le c^{\mathrm{source}}$ 的代理口径，不是训练 $q_{90}$）+ 99 条 `stale_hops` 线性代理判定；两类都不计入可核验；两类都不计入分母、不计为失败。代理越界只在盒约束诊断对照（99 行中 58 行），与 198 个 QP 的 `max_constraint_violation=0` 不是同一对象。

## 位移、约束残差与 z 空间位移是三组不同的量



\begin{bptable}
\setcounter{table}{11}
%% table-id: q3-transfer-columns sha256:ffe8d793a1c75d232a300e8b1733af3ea2de045f50db5aa66a27217b747ffc30
\captionof{table}{关键列的三组量：约束残差、存储空间位移与 z 空间位移}\label{tab:q3-transfer-columns}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.2569\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1193\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1501\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1614\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1358\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1445\linewidth-6pt\relax}@{}}
\toprule
对象 & ①约束残差 max & ②存储空间位移 max & ②存储空间位移 mean & ③z 空间位移 max & ③z 空间位移 mean \\
\midrule
反-2-壬烯醛 & 3.556e-17 & 0.0010 & 2.079e-05 & — & — \\
双乙酰 & 2.22e-16 & 0.5239 & 0.0580 & — & — \\
4-乙烯基愈创木酚 & 0.0000 & 0.3010 & 0.0109 & — & — \\
z 空间·\allowbreak{}逐行 231 维绝对位移均值 & — & — & — & 0.6367 & 0.4878 \\
z 空间·\allowbreak{}逐行 231 维 L1 位移 & — & — & — & 147.0727 & 112.6728 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：三组量不是同一对象，不能相互替代或相减。①约束残差是上限约束下 clamp(新值 − 源值, 0) 的逐行最大值，量级在浮点误差附近，只说明约束未被违反；②存储空间位移是 |新值 − 源值| 的逐列最大/均值，描述配方改动了多少；③z 空间位移是 231 维中心化标准化后的逐行位移，逐列分解未随产物保存，故只给出行级读数。z 空间的独立 centre/scale 重建产物属于上一轮运行（冻结代码/数据 sha 与当前运行不同（['src/q3\_lib.py', 'src/q3\_transfer\_fix.py']）；复算覆盖 ['qp-quantile-anchor', 'qp-source-anchor', 'source-fixed', 'target-mean-projection'] / 396 行，本轮为 ['qp-quantile-anchor', 'qp-source-anchor', 'source-fixed', 'target-mean-projection', 'target-mean-projection-full'] / 495 行），本轮不引用该过期重建；本轮只做行内恒等式核对 l1\_change\_z / 231 = mean\_abs\_change\_z（最大差 1.110e-16）。三组都只针对交付的 QP 分位数锚定策略。\end{tablenote}
\end{bptable}


三组量分别回答三个问题。第一组**约束残差** $\operatorname{clamp}(x^{\mathrm{new}}-x^{\mathrm{source}},0)$ 的量级就是数值零，回答“是否越界”，不回答“改了多少”。第二组**存储空间位移**是 `qp-quantile-anchor` 的逐列最值/均值：三列量级差异很大（双乙酰最大、4VG 次之、反-2-壬烯醛接近噪声），不能用单一“平均改动”概括；这三列**不代表** 231 列的整体位移（整体位移由痕量化合物主导，逐列分布见图 9 第 (1) 组），后者也不能反过来判断缺陷约束——那只看残差。

第三组 **z 空间位移**只用于描述改动量级：上一轮的独立 centre/scale 重建对应不同代码/数据哈希，属过期产物，本文不引用；本轮只做行内恒等式核对（$L_1/231$ 与平均绝对位移一致，最大差 $1.1\times10^{-16}$），不作为可复现性证据。


\begin{bpfigure}
%% figure-id: FIG-0049 sha256:0b4ac2b1efd1654071777657c2aa7444757ab9a3e97c8880084dbe618a8755cd
%% figure-src: ../figures/confirmatory_v2/Q3-transfer-shift.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/Q3-transfer-shift.png}
\captionof{figure}{问题三：迁移三组量分面板——存储位移 |opt−src|、z 空间位移、约束残差 clamp(new−src,0)；残差非位移，按策略区分。}
\end{bpfigure}


目标参照自距 4.74908413763155e-16（数值零；旧口径 0.6654909915445382 是未减目标均值的缺陷，已修正）。迁移前后分布变化：迁移谱 2.0798861351916886（归一化 0.11341058752359791）、源点固定 7.196326285149654、盒约束诊断 6.94148284204317、完整可行域基线 6.379240954520166。

## 问题三的实际答案

两个对象分开给答案。

1. **生成侧**：设计谱归一化能量距离 0.8726874826148657；约束分层可核验 19670 / 条件 8211 / 不可识别 619 / 不可行 0。边界：未超过同风格重采样参照，三个对照配置 $V$ 也略优，Kriek 逐风格读数离群。
2. **迁移侧**：计划内 198 次求解全部最优；交付策略 $V=$ 2.0798861351916886（归一化 0.11341058752359791）、四条化学列不增率 1；同一完整可行域的均值投影基线 $V=$ 6.379240954520166、不增率 1。
3. **证据归属**：生成侧与迁移侧各有主结论与稳健性结论，分别对应问题三生成、问题三迁移两支预登记稳健性计划（各含参考块、扰动块与登记后补跑的一块）。登记原文见附录 B.4。

限制：不是真实工艺可实现性的证据；不增只在 $10^{-9}$ 声明容差内成立（131/198 个 QP 解落在边界）；化学不增与感官代理不增是两个命题；迁移无迁移后真实标签；原生优化检查未通过。

**证据登记：** 生成侧的主结论与稳健性结论见附录 B.4

**证据登记：** 迁移侧的主结论与稳健性结论见附录 B.4

## 问题三的作用边界

第一，迁移是“声明模型下的最优”，不是真实迁移：结论只在 231 维 z 空间、声明盒界与单条代理半空间、以及“秩 10 二次目标 + $\lambda$ 锚点项 + $L_1$ 项”下成立；198 个证书不改变这一点。

第二，没有迁移后的真实标签。只报告目标距离与约束状态，不报告准确率；任何“更接近真实 Tripel 风味”的表述都超出证据。

第三，生成不等于优于参照。设计谱劣于源样本重采样参照，另三个对照配置的 $V$ 也略优，Kriek 逐风格读数离群；本文不宣称生成模型优于基线，也不用池化值代替小风格画像。

第四，化学不增与感官代理不增是两个命题。真实反-2-壬烯醛增加 0 条，感官 t2n 代理仍增加 366 条（0.488）；迁移侧同理（化学列不增率 1，感官 t2n 代理增加比例 0.06060606060606061）。

第五，“不增只在容差内成立”：131 个（共 198 个）QP 解恰好落在声明的 $10^{-9}$ 边界上（按策略 qp-quantile 67、qp-source 64），读成严格不等会高估它。

第六，`source-fixed` 平凡对照与 QP 结果必须分开呈现；能区分策略的是同一完整可行域上的转移能量，而不是饱和的不增率。

第七，单一选择字段只能表示生成侧组件，迁移组件只能由理由文本与断点说明登记，因此本问选择状态为草稿选择。

# 稳健性与限制

## 检验设计

稳健性检验在主方案确定后、比较之前预注册：先登记指标、扰动清单与判定规则，再执行扰动。判定量为相对极差

$$
R=\frac{\max m-\min m}{\max(|m_{\mathrm{ref}}|,10^{-12})},
$$

其中 $m_{\mathrm{ref}}$ 为参考运行（扰动前对照）指标，四个对象各有独立计划与上限、不合并判定。另有口径历史：部分计划的 reference 字段是自由文本，工具按分母 1 计算，故记录里的“relative spread”实为**绝对极差**；本文把绝对极差与真实相对极差分列、以真实相对极差对照上限，该修正只记在结论层，不改历史记录。

## 分列的四组检验



\begin{sidewaystable}
\setcounter{table}{12}
%% table-id: rob-confirmatory sha256:9b11345b02c9f0e6b27fd59d929296ae0b64fec0eae7df11c1470f3769e1dc5d
\centering
\caption{四组稳健性检验的实际范围}\label{tab:rob-confirmatory}
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.0651\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1681\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0948\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0828\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0574\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0574\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1227\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.0271\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1173\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.1751\linewidth-6pt\relax}@{}}
\toprule
稳健性检验 & 对象与指标 & 计划执行值（按计划链接块数） & 补充种子块（未并入计划） & 绝对极差 & 真实相对极差 & 判定规则与上限 & 判定 & 扰动方法 & 限制 \\
\midrule
问题一稳健性检验 & 问题一候选模型的 A/\allowbreak{}F30 等权 MAE & 0.3542 /\allowbreak{} 0.3624 /\allowbreak{} 0.3576 & — & 0.0082 & 0.0232 & 相对极差 ≤ 0.0500（relative-\allowbreak{}range） & 通过 & 多种子 + 参数扰动 & 只覆盖三个冻结种子中的两个，且参数扰动只改内层正则网格的 λ 倍数。 \\
问题二稳健性检验 & 问题二 Top-3 平均两两 Jaccard & 0.2103 /\allowbreak{} 0.2073 & 0.2097 & 0.0030 & 0.0143 & 相对极差 ≤ 0.1000（relative-\allowbreak{}range） & 通过 & param-\allowbreak{}perturbation（冻结种子块） & 计划内只有两个执行块（种子块 0 参考 + 种子块 1）；种子块 2 的补充块在登记后执行、未并入计划记录；台账方法为 param-\allowbreak{}perturbation（被扰动对象是冻结种子块），不是 multiple-\allowbreak{}seeds；Jaccard 是集合一致率不是准确率。 \\
问题三生成稳健性检验 & 问题三生成谱的归一化能量距离 & 0.8639 /\allowbreak{} 0.8703 & 0.8839 & 0.0064 & 0.0074 & 相对极差 ≤ 0.0500（relative-\allowbreak{}range） & 通过 & param-\allowbreak{}perturbation（冻结种子块） & 计划内只有两个执行块；种子块 2 的补充块在登记后执行、未并入计划记录；constraint-\allowbreak{}satisfaction 恒为 1 是构造性质，不参与判定。 \\
问题三迁移稳健性检验 & 问题三迁移的综合不增率（四条化学列 + 老化酒花代理合计口径；旧称逐列不增率） & 1.0000 /\allowbreak{} 1.0000 & 1.0000 & 0.0000 & 0.0000 & 每个取值须 ≥ 1（min-\allowbreak{}value） & 通过 & param-\allowbreak{}perturbation（冻结种子块） & 指标有界且饱和（计划内两值均为 1），只能说明没有变差，不能读成强稳健；198 个 QP 是重复求解；种子块 2 的补充块未并入计划记录。 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：每行是一次预注册的稳健性检验。“计划执行值”只含计划内已执行的块（问题一 3 块；问题二/三各 2 块，方法记为 param-perturbation，被扰动对象是冻结种子块），“补充种子块”是计划登记之后才执行的第三个种子块，单独列出、不并入计划记录，因此不能把本表读成 n=3 的多种子结果。绝对极差为计划内取值的最大值减最小值；真实相对极差为绝对极差除以参考值——台账的 relative spread 以分母 1 计算（reference 为自由文本），本表按真实分母重算并分列。判定规则与上限在比较之前登记；问题三迁移用 min-value 规则，因指标有界饱和，1.0 是构造上界。所有判定只描述本组扰动，不构成模型全面稳定的证据。\end{tablenote}
\end{sidewaystable}


**扰动方法的统一说明。** 四组计划都只做**冻结种子块上的扰动**，扰动对象是协议常量 `SEEDS`/repeat，其余设置不变。差别在登记的方法标签与执行块数：

- 问题一登记为 multiple-seeds + param-perturbation，执行 3 块（参考块、种子块 20261025→20261026、内层 $\lambda$ 网格整体乘 0.5），只覆盖 3 个冻结种子中的 2 个。
- 问题二与问题三登记为 **param-perturbation**（不是 multiple-seeds），计划内各执行 2 块（参考块 + 种子块 1），同样只覆盖 2 个冻结种子。
- 四组都**不是预算扰动**：bootstrap 次数在计划内各块都是 500，没有 500→200 的降档。

另有登记之后才执行的**补充种子块**（问题二、问题三生成、问题三迁移各一块）：它们单列于下文，**未并入计划记录**，也不参与计划内极差与判定；不能把表里的“计划执行值 + 补充块”读成 n=3 的计划结果。

**问题一。** 参考运行与两个扰动的 Aroma/Flavour 30 维等权 MAE 分别为 0.35422354618559243、0.36243390816790516、0.35763459908881995；其中一次扰动把内层 $\lambda$ 网格整体乘以 0.5。绝对极差与相对极差见上表，预注册上限为 0.05。

这一组另有一条来源说明：该检验属**来源一致性修复后的重登记**，不是首次预注册。先导轮的同名计划与其记录仍按历史保留，三组扰动值与旧记录逐位相同；重登记的目的是把三条实验统一到同一版封装代码，因此本组只证“当前协议下一致”，不能读作一次新的独立稳健性证据。

**问题二**：计划内两块 Jaccard 0.2103333333333333 与 0.20733333333333334（上限 0.10），补充种子块 0.20966666666666664 只作补充证据。**问题三·生成**：0.8639056831482218 与 0.8702681221486325，补充块 0.8838886425477438（上限 0.05），约束满足率的构造量不参与判定。**问题三·迁移**：1 与 1，补充块 1，规则为每次保持 1.0。该指标有界饱和，包括补充块在内的极差 0 **不构成改善或强稳健证据**——饱和极差 0 只是没有信息。


\begin{bpfigure}
%% figure-id: FIG-0050 sha256:22ed0dffee7f6e07d61b64ca891f206bd71754abcae617c2ce5f2bd7c7d1999f
%% figure-src: ../figures/confirmatory_v2/ROB-summary.png
\includegraphics[width=0.92\linewidth,height=0.34\textheight,keepaspectratio]{../figures/confirmatory_v2/ROB-summary.png}
\captionof{figure}{四组稳健性：绝对极差与参照比值并排、各自预注册上限；预登记的种子块计划为冻结种子块参数扰动（计划 n=2），该计划的饱和极差非改善。}
\end{bpfigure}


## 这些检验没有覆盖什么

第一，四组检验都只覆盖三个冻结种子中的两个。问题一执行了 3 个块但只涉及 2 个种子（第三个种子从未执行）；问题二与问题三各执行 2 个块，它们的第三个种子块是在计划登记之后补跑的，单独列出且不并入计划记录。因此任何“种子稳健”的说法，最宽也只能覆盖 3 个冻结种子中的 2 个，而不是全部。

第二，扰动都只改变冻结种子块，问题一另有一次内层 $\lambda$ 网格乘 0.5 的参数扰动；每组最多只涉及 2 个冻结种子、每个设置只跑一次，且没有对参数空间做系统扫描，因此不能据此断言“参数不敏感”或“种子稳健”。

第三，固定种子的独立复跑与外层实验逐位一致，这只证明**确定性重现**，不是独立实现，也不增加独立样本量。问题一的复跑容差为 $10^{-9}$ 量级。

第四，四组检验的对象、指标与上限都不同，不能合并成“模型全面稳定”的单一结论。问题三的生成侧与迁移侧尤其不可合并：两者的指标一个衡量分布差异、一个衡量约束状态，连数值量纲都不同。

第五，部分题目要求项因证据不足被登记为“数据不足”，**不是通过**。具体包括：多阈值迁移情景与 Pareto 权衡缺少可核对证据；交付门禁未通过（质量检查 45 项中 33 项通过、11 项需复核、1 项失败，交付冻结被工具拒绝）；图表标注与结论的逐项一致性仍属人工判断。这三项在本稿中如实保留为未完成，不以文件存在冒充覆盖。

第六，稳健性检验的判定通过只表示“本组扰动下极差在预注册限内”，与第 4–6 章的各项验证状态是并列关系，不能把“稳健性通过”读成“结论已通过交付门禁”。

# 组件作用与负结果汇总

组件对照分散在各表中，此处只整合，不重复数值。

**预测结构（表 1）。** 图 Ridge 与普通 Ridge 几乎相同，仅加图正则不改变结果；图低秩相对普通 Ridge 的改善按低秩收缩归因，量级小于与中位数基线的差距。未做“无图同等低秩”消融，故不保留“图结构带来增益”的主张。

**关联识别（表 14）。** 方法间一致性低于跨重复一致性，候选名单主要受方法口径影响；方向一致率虽高（0.9816877777777778），150 条严格共识仍有 95 条 $\pi<0.5$——“方向可复现”与“名次稳定”是两个问题，Top-3 应读作排序假设。

**生成对照（表 9）。** 投影的分布代价很小，但生成设计谱劣于源样本重采样参照，三个对照配置 $V$ 也略低；三类 Copula 差异小于它们与参照的差异，依赖结构估计不是主导误差来源，而边际误差仍可观、Kriek 逐风格读数尤其差。

**迁移对照（表 11）。** 平凡对照 `source-fixed` 不增率同为 1，该指标无法区分“有改善”与“未移动”；盒约束诊断的低值完全由 `stale_hops` 代理越界造成（四条化学 cap 仍全为 1）；能区分策略的是同一完整可行域上的转移能量比较。

# 结论、建议与局限

## 主要结论

本文以可核实的尺度字典连接预测、关联与生成，并在每问内先固定协议、后比较候选。问题一：图正则低秩的 30 维等权 MAE 0.35929156588219174、中位数基线 0.39817732837288883、全 50 维 0.350504156920024（基线 0.3918800487369867），全部为折外预测，0–6 为训练分布内相对等级；图与低秩单独作用有限。问题二：方法间平均两两 Jaccard 0.2091111111111111、$\pi$ 均值 0.42045666666666665，方向一致率 0.9816877777777778（旧口径 0.7225544444444444 偏低源于定义），该量是集合一致性而非准确率。问题三：生成侧归一化能量距离 0.8726874826148657，高于源样本重采样参照、三个对照配置 $V$ 也略优；三风格单独池化显著高于池化值，Kriek 离群；化学反-2-壬烯醛不增（0 条），感官 t2n 代理仍增加 366 条（0.488）；迁移侧 198 次求解全部最优、四条化学列不增率 1，转移能量低于同一完整可行域基线（2.0798861351916886 对 6.379240954520166），但“不增率 = 1”不构成改善证据。

## 实践建议

配方筛选先用 Top-3 与共表达网络定位候选，再用小规模酿造或加标实验检验机制——候选排序不构成因果证据，不能直接指导添加量。风格设计可参考真实目标风格的酯类、高级醇与酸类范围，同时保留 DMS、双乙酰、4VG 与反式-2-壬烯醛的逐样本阈值核验；Kriek、Lambic 等小样本风格的生成质量明显弱于整体，应优先补样本与人工品评而非直接采用生成均值。预测交付中 0–6 等级只能作同数据内相对排序；要与人工评分可比，需取得原始评分与标定参数并重做一致性检验。

## 适用边界

本稿是论文源工作稿，不是最终提交版，具体边界如下。

第一，证据层级不齐。问题一的划分完整性与留出指标检查结构性不可满足；问题三的原生优化可行性与优化目标检查被工具具名拒绝，本文不声称通过；问题二的核心量是集合一致性而非准确率，也没有可对照的真值。台账当前对三问的选择状态都只是草稿选择，没有任何一问进入“被选为最终方案”。

第二，0–6 等级未恢复人工评分。附件评分工作簿为空白模板，级别由训练折经验分布标定，预测向中部收缩，整级一致率与二次加权 $\kappa$ 因此受限。

第三，关联与迁移都不涉及因果。问题二为同期关联，问题三为声明模型下的优化结果且无迁移后真实标签；两者都不支持“机制已被证实”的表述。

第四，稳健性覆盖不全。四组检验都只覆盖三个冻结种子中的两个；问题二与问题三的补充种子块未并入计划记录，问题一的第三个种子从未执行；扰动只改变冻结种子块（问题一另有一次 $\lambda$ 网格缩放），不是参数空间扫描；固定种子复跑仅证确定性重现；迁移侧指标饱和使极差为零无法解释为稳健。

第五，附件之间同源，不能互为独立验证；六大来源的交叉相关表对照只能核对接径，不能代替外部数据。校准附件与主输入在 33 个线性校准列上有 80 个单元格冲突（79 个实质性），成因未知、未修补，这意味着这些列的物理量换算存在不可消除的输入不确定性。

第六，三问的选择状态都是草稿选择，交付检查未通过最终门禁（`final=false`、`qualityPassed=false`），本稿是 DRAFT。把本稿的数值当作已通过最终验收的结论，是对证据状态的误读。

# 参考文献 {.unnumbered}

[1] 2026 年 MathorCup 数学应用挑战赛——大数据竞赛. 赛道 A：啤酒酿造化合物分析与啤酒风味预测：初赛题面及附件 1–8. 2026.

[2] Schreurs M, Piampongsant S, Roncoroni M, et al. Predicting and improving complex beer flavor through machine learning. *Nature Communications*, 2024, 15: 2368. [doi:10.1038/s41467-024-46346-0](https://doi.org/10.1038/s41467-024-46346-0).

[3] Gibson B, Vidgren V, Peddinti G, Krogerus K. Diacetyl control during brewery fermentation via adaptive laboratory engineering of the lager yeast *Saccharomyces pastorianus*. *Journal of Industrial Microbiology & Biotechnology*, 2018, 45: 1103–1112. [doi:10.1007/s10295-018-2087-4](https://doi.org/10.1007/s10295-018-2087-4).

[4] Baldus M, Klie R, Biermann M, et al. On the Behaviour of Dimethyl Sulfoxide in the Brewing Process and its Role as Dimethyl Sulfide Precursor in Beer. *BrewingScience*, 2018, 71(1/2): 1–11. [doi:10.23763/BrSc18-01baldus](https://doi.org/10.23763/BrSc18-01baldus).

\newpage
\appendix

# 附录 A　支撑材料长表索引与两张概率表 {.unnumbered}

## A.1 支撑材料长表索引 {.unnumbered}

以下 4 张长表随支撑材料交付（同一数据另有 `.csv`），正文只引用其汇总结论；输入/输出 SHA-256 与表→实验映射见 `report/tables/INDEX.json`，全部进入交付包 `SHA256SUMS`。

| 表 | 文件 | 内容 |
|---|---|---|
| q1-targets | `report/tables/q1-targets.md` / `.csv` | Aroma/Flavour 30 维逐维折外 MAE、中位数基线 MAE、差值与 Skill（按 Skill 升序，含 6 个恶化维度），每维 750 折外行 |
| q1-styles | `report/tables/q1-styles.md` / `.csv` | 22 个风格的折外 MAE、啤酒数与折外行数，小样本风格（Faro 3、Brut 4、Flanders old brown 5、Scotch 5）单列 |
| q2-full-top3 | `report/tables/q2-full-top3.md` / `.csv` | 50 维 × 每维 3 项的完整严格共识榜（150 条），含 $\pi$、$S$、方向、类型与同模块替代候选 |
| q2-extended | `report/tables/q2-extended.md` / `.csv` | 15 个非单体扩展指标在 50 维上的 Top-3，与严格榜分表、不合并计数 |

这四张表的数据行一行未删；正文不内联只为控制版式，不表示证据缺失。

## A.2 概率与约束明细表 {.unnumbered}

以下两张表内容与正文结论直接相关，放在附录以保持正文篇幅；编号接正文连续。



\begin{bpLTsmall}
\setcounter{table}{13}
\begin{longtable}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.4191\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1282\linewidth-6pt\relax}>{\raggedright\arraybackslash}p{\dimexpr 0.4207\linewidth-6pt\relax}@{}}
%% table-id: q2-stability sha256:38b47ac6aa5c83b9fb27a5e02817dca4777226337b7bc7e445c78b145b31eafb
\caption{入选频率、方法间集合一致性与同源对照}\label{tab:q2-stability}\\
\toprule
指标 & 数值 & 口径与说明 \\
\midrule
\endfirsthead
\toprule
指标 & 数值 & 口径与说明 \\
\midrule
\endhead
\bottomrule
\endfoot
Top-3 平均两两 Jaccard（入选频率优先集合，主指标） & 0.2091 & 50 维 × 4 方法 × 6 个方法对，三次重复池化；集合为最终交付集合 \\
Top-3 平均两两 Jaccard（点估计集合） & 0.1977 & 同一统计量，集合改为点估计 Top-3；与主指标的差异来自集合规则而不是数据 \\
第一次重复的 Jaccard & 0.2103 & 该次重复自身的池化值 \\
第二次重复的 Jaccard & 0.2073 & 该次重复自身的池化值 \\
第三次重复的 Jaccard & 0.2097 & 该次重复自身的池化值 \\
跨重复集合一致率（Jaccard） & 0.8748 & 交付集合在两次重复之间的重合程度 \\
入选频率 π 均值 & 0.4205 & 交付严格榜条目：四种方法 × 三次重复池化（每次重复 600 条） \\
π < 0.5 的条目数 /\allowbreak{} 分母 & 1263 /\allowbreak{} 1800 & 占比 70.17\%；分母为该口径下的条目总数 \\
符号方向一致率均值（现行口径） & 0.9817 & 同一批交付条目中，bootstrap 复制里总体 Spearman 与点估计同方向的比例 \\
符号稳定性（已弃用口径 P(ρ>0)，不得再称为 sign stability） & 0.7226 & 旧口径把 503 条点估计为负方向的条目计为“不稳定”；该值偏低源于定义而不是方向不稳，仅作历史对照 \\
与附件 6.csv 的同源秩相关（双侧名称对齐） & 0.9210 & 44 行名称两侧对齐；同源对照，不是外部验证 \\
与附件 6.csv 的同源秩相关（已废弃：列位置口径） & 0.4451 & 该值由按列位置对齐加索引混用产生，属错位伪影，已弃用，不得作为佐证 \\
bootstrap 预算（每次重复） & 500 & 风格内分层重采样次数，各执行块相同 \\
稳健性执行值（计划内 2 块：种子块 0 参考 /\allowbreak{} 种子块 1） & 0.2103 /\allowbreak{} 0.2073 & 同一指标在两个已执行冻结种子块下的取值；台账方法为 param-\allowbreak{}perturbation（被扰动对象是冻结种子块），不是 multiple-\allowbreak{}seeds，也没有预算扰动 \\
补充种子块（种子块 2，登记后执行，未并入计划记录） & 0.2097 & 该块在计划登记后才执行，工具拒绝覆盖已执行计划；不得并入上面的执行值、极差与判定，也不得写成 n=3 的计划结果 \\
绝对极差 & 0.0030 & 计划内两值的最大值 − 最小值（不含补充块） \\
真实相对极差 & 0.0143 & 绝对极差 /\allowbreak{} 参考值；判定上限 0.1000 \\
稳健性判定 & 通过 & 预注册规则 relative-\allowbreak{}range；只描述本组扰动 \\
\end{longtable}
\begin{tablenote}注：Jaccard 衡量的是不同方法/重复之间 Top-3 集合的重合程度，不是预测准确率；π 是候选在 bootstrap 复制中的入选频率，低于 0.5 表示名次不稳；符号方向一致率与旧口径 P(ρ>0) 是两种定义，必须分开引用：现行口径只问“与点估计同方向”，旧口径把负方向条目一律计为不一致，因此其数值天然偏低。6.csv 与本研究同源，只作排序一致性对照，不能称为外部独立验证；bootstrap 预算固定为每次重复 500 次，各执行块之间没有预算差异。稳健性执行值只覆盖计划内已链接的冻结种子块（方法记为 param-perturbation），计划参考块是登记后的重跑，因此其值不必等于主实验的池化值；种子块 2 的补充块在登记后执行、单独列出且未并入计划记录；这些判定都不构成模型全面稳定的证据。\end{tablenote}
\end{bpLTsmall}




\begin{bptable}
\setcounter{table}{14}
%% table-id: q3-constraints sha256:98b28b6effa9b63625cec6f0e8f93e6a1d99b5ee38d953ca44659b257d6e77bc
\captionof{table}{声明约束的核验构成}\label{tab:q3-constraints}
\par\smallskip
\small
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.6751\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1434\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1495\linewidth-6pt\relax}@{}}
\toprule
核验状态 & 记录数 & 占比 \\
\midrule
已验证（verified） & 19670 & 0.6902 \\
条件成立（conditional） & 8211 & 0.2881 \\
不可识别（not identifiable） & 619 & 0.0217 \\
不可行（infeasible） & 0 & 0.0000 \\
合计 & 28500 & 1.0000 \\
\bottomrule
\end{tabular}
\par\smallskip
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{\dimexpr 0.4934\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0848\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0848\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1113\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.1107\linewidth-6pt\relax}>{\raggedleft\arraybackslash}p{\dimexpr 0.0831\linewidth-6pt\relax}@{}}
\toprule
约束类 & 记录数 & 已验证 & 条件成立 & 不可识别 & 不可行 \\
\midrule
缺陷硬阈值·\allowbreak{}二甲基硫上界 & 750 & 750 & 0 & 0 & 0 \\
缺陷硬阈值·\allowbreak{}4-乙烯基愈创木酚上界 & 750 & 256 & 0 & 494 & 0 \\
缺陷硬阈值·\allowbreak{}双乙酰上界 & 750 & 0 & 750 & 0 & 0 \\
反-2-壬烯醛化学不增（训练 q90 上界） & 750 & 0 & 750 & 0 & 0 \\
老化酒花代理上界（岭回归代理） & 750 & 0 & 750 & 0 & 0 \\
线性非负（33 列） & 24750 & 18664 & 5961 & 125 & 0 \\
合计 & 28500 & 19670 & 8211 & 619 & 0 \\
\bottomrule
\end{tabular}
\begin{tablenote}注：上表为逐条约束记录的四类核验状态，下表按约束类拆分。“已验证”指约束在写出的样本文件中被直接复核；“条件成立”指约束依赖训练折内的数据派生界或代理变量；“不可识别”指该格的上界无法从数据确定（如缺陷列缺测）；不可行记录为零。设计谱的约束满足率为 1.0000（由约束投影保证），未约束原始生成仅 0.1267；核验记录合计 28500 条，其中已验证占比 0.6902。线性非负类覆盖 33 个化学列；老化酒花只有训练折内的代理约束，不能读作实测老化指标。\end{tablenote}
\end{bptable}


# 附录 B　复现要点 {.unnumbered}

## B.1 计算与复核顺序 {.unnumbered}

环境为项目绑定的 Python 3.12（NumPy、pandas、SciPy、scikit-learn）。复核顺序：

1. 按 `beer` 对齐附件，核对校准字典与缺失计数（含第 2 章的 80 格冲突清单）。
2. 只在训练折拟合预处理、图与超参数；计算折外预测与相对等级，并把评价侧（750 行折外）与展示侧（250 行重拟合）分开落盘。
3. 按名称对齐交叉相关表，计算四种方法的 Top-3 与 bootstrap 频率，同时输出方向的正 / 负 / 零 / 无效计数。
4. 逐折用未填补的有效观测估计边际，生成原始抽样，再投影得到约束设计谱。
5. 在声明 QP（含修正后的代理右端 $b$）下求解并写证书。
6. 按四组独立计划执行冻结种子块的扰动，并单列登记后补跑的种子块。

## B.2 脚本与产物索引 {.unnumbered}

全部数值取自台账登记的实验产物与由其生成的表格，不在正文手抄；正文与图表题注只使用中文编号（图 N、表 N），不出现任何内部实验/验证/结论编号；内部编号只出现在附录 B.4 的证据登记块里（由渲染器从台账生成，用于追溯，可整体删去而不影响阅读）；每张表的输入路径、输入/输出 SHA-256 与表→实验映射记录在 `report/tables/INDEX.json`。输入缺失或指标键不存在时，生成脚本具名失败，不填零、不回退旧实验。

## B.3 本稿的待补项（DRAFT 状态声明） {.unnumbered}

1. 图 1–10 依次为题一 3 张、题二 3 张、生成 2 张、迁移 1 张、稳健性 1 张，均已在台账登记且文件 sha 与登记值一致（编号见 `report/evidence_manifest.json`）；上一轮旧图已全部退役或被替代，旧编号不得再引用。图内英文标注偏小，核对以原图为准。
2. 按 DRAFT 交付：正式渲染与产物绑定此前已执行，但交付检查未通过最终门禁——45 项质量检查 33 通过 / 11 需复核（1 项要求覆盖、10 项指标复算因未登记数据划分而无权威测试真值）/ 1 失败（分析证据缺输入清单，属历史遗留，本轮未 retrofit），交付冻结被具名拒绝，故 `final=false`、`qualityPassed=false`；冻结与打包状态以 `DELIVERY-NOTES.md` 为准。
3. 验证检查点仍不完整：问题一的划分完整性与留出指标、问题三的原生优化可行性与优化目标结构性未通过；三问选择状态都是草稿选择（provisional）。
4. 部分题目要求项登记为“数据不足”，不等于已完整回答。
5. 过程控制账目：RUN-0003 以显式恢复保留 `stopped` 与 unknown-usage，RUN-0004 承接其未结算额度；1,304,576 token 的未结算上界仍披露，不因恢复清零。

## B.4 证据登记（全部 8 条结论） {.unnumbered}

正文只引用结论编号与判定读数，登记原文、证据引用与限制集中在本节，避免正文重复。

**问题一·主结论。** 确认轮 Q1：train-only 3×3×3 嵌套 CV 下图正则低秩（MODEL-0048 / EXP-0073）A/F30 等权 MAE = 0.359292，同协议中位数基线（EXP-0074）0.398177，差 0.038886；全 50 维 0.350504。证据：VAL-0063/0064/0065；稳健性**ROB-0011**（统一 wrapper 7d7ab6aca6c2）：参考 EXP-0100（repeat 0）、种子扰动 EXP-0101（repeat 1 / seed 20261026）、参数扰动 EXP-0102（内层 λ 网格 ×0.5，标量 lambdaMultiplier=0.5）→ mae 0.354224 / 0.362434 / 0.357635，**绝对极差 0.008210、相对极差 0.023178 ≤ 0.05（插件原生相对口径）**，decisionPassed=true。三值与旧 ROB-0007 逐位相同，只证当前协议下一致。限制：内部 OOF 非外部测试；split-integrity/holdout-metrics 不可满足、provisional；确定性重现≠独立实现；仅 2/3 种子；旧 ROB-0007 与分母=1 口径限制保留为历史。

**问题一·稳健性。** 问题一的稳健性检验同时覆盖种子扰动与内层正则强度扰动：Aroma/Flavour 30 维等权 MAE 分别为 0.3542、0.3624、0.3576，绝对极差 0.0082、相对极差 0.0232，均在预设上限 0.05 之内。该检验只覆盖三个冻结种子中的两个，扰动也只沿单一参数方向（内层正则网格整体乘 0.5）；固定种子的独立复跑只证明确定性重现，不构成独立实现或独立稳健性证据。

**问题二·主结论。** 确认轮 Q2（v6 修正后，EXP-0107）：在固定 200 行训练集、3 个冻结种子块与每次 500 次风格分层 bootstrap 下，50 维 × 4 方法 Top-3 平均两两 Jaccard 为 0.2091111111111111（点估计口径 0.19766666666666666，跨重复一致率 0.8748333333333335）；入选频率 π 均值 0.42045666666666665，1800 个交付格中有 1263 个 π<0.5，主共识 150 条严格项中 95 条 π<0.5。符号稳定性改为“与总体 Spearman 点估计同方向”的一致率后为 0.9816877777777778，而旧口径 P(ρ>0) 为 0.7225544444444444；旧值可逐位复现（150/150 行 π 与旧 sign_stability 完全相同），说明此前 36 条负方向条目的低值来自定义错误而不是方向不稳。

**问题二·稳健性。** Q2 稳健性（ROB-0015，v6 修正后）：在固定 200 行训练集上只改变冻结种子块（repeat 0→1），topk-jaccard 从 0.2103333333333333 变为 0.20733333333333334，相对极差 0.003000 / 0.210333 ≈ 1.43%，满足预登记 relative-range ≤ 0.10；预登记后跑的第三个种子块 EXP-0131（repeat 2）为 0.20966666666666664，也落在同一区间内（相对极差 1.43%），但它不在计划记录的执行集内（工具拒绝覆盖已执行计划），故只作为补充证据列出。

**问题三·生成。** 确认轮 Q3 生成（v6 修正后，EXP-0109）：约束后设计谱的 constraint-satisfaction = 1.0（投影构造性质，不是经验发现），21 个可估计风格 177 个可估格的 n_gen 加权归一化经验能量距离 V = 0.8726874826148657（原始 V = 15.99994601104919，带符号诊断 U = 1.6153896894821214）；Tripel/Kriek/Lambic 子集 27 格的 V = 33.78288729066554（归一化 1.8078909138627393，U = 1.0278782459401254），分母与全风格不同。真实化学 trans-2-nonenal 相对原始抽样增加 0 条（maxIncrease=0），感官 t2n 代理仍增加 366/750（48.8%），两者分开报告。四类约束记录为 verified 19670 / conditional 8211 / not_identifiable 619 / infeasible 0。边际只用未填补有效观测估计，内层 (κ,κ_R) 选参改用与外层一致的经验 V 口径并重跑；同风格训练行重采样参照的 V 归一化为 0.8137313，仍优于本生成器，本结论不宣称优于该基线。

**问题三·生成稳健性。** Q3 生成稳健性（ROB-0016，v6 修正后）：只改变冻结种子块（repeat 0→1），归一化经验能量距离从 0.8639056831482218 变为 0.8702681221486325，相对极差 0.006362 / 0.863906 ≈ 0.74%，满足预登记 relative-range ≤ 0.05；预登记后跑的第三个种子块 EXP-0132（repeat 2）为 0.8838886425477438，三块相对极差 2.31% 仍 ≤ 0.05，但该第三块不在计划记录的执行集内（工具拒绝覆盖已执行计划），只作补充证据。

**问题三·迁移。** 确认轮 Q3 迁移（v6 修正后，EXP-0110）：在 Pils/Lager→Tripel 的 11 源 × 3 重复 × 3 外折 × 5 策略（495 行）上，凸 QP 主策略 qp-quantile-anchor 的逐化学列不增率 = 1.0（DMS、双乙酰、4VG、真实 trans-2-nonenal 各 1.0），198 个 QP 全部 optimal，max primal = 9.994750582720258e-09、max dual = 2.1051915766179263e-10、max 约束违反 = 0。stale 半空间右端修正为 b = a'z_source + 1e-9（九折截距 c ∈ [-0.1086, -0.0137] 全为负；identity error 8.27e-17、半空间残差 0）；131/198 个解贴在该声明边界（qp-quantile 67、qp-source 64；495 行全策略合计 189/495），故“不增”只在 1e-9 容差内成立。完整可行域均值投影基线非增率 = 1.0、V = 6.379240954520166；QP 主策略 V = 2.0798861351916886；box-only 诊断 V = 6.94148284204317、非增率 0.41414141414141414。源状态分层（主策略 3762 条）：verified 3465（可核验分母 3663）、conditional 198、not_identifiable 99、failed 0；不可识别 99 = 81 条 4VG 地板存储码（physical_source = physical_new = 0，上界近乎空转）+ 18 条 beer119/beer28 源双乙酰缺失；条件 198 = 99 条 trans-2-nonenal 源值上界（c_new ≤ c_source，不是训练 q90）+ 99 条 stale_hops 代理判定。

**问题三·迁移稳健性。** Q3 迁移稳健性（ROB-0017，v6 修正后）：只改变冻结种子块（repeat 0→1），逐化学列不增率在参考 EXP-0129 与扰动 EXP-0130 均为 1.0，满足预登记 min-value = 1（最小值 1 ≥ 1）；预登记后跑的第三个种子块 EXP-0133（repeat 2）同样为 1.0，但不在计划记录的执行集内（工具拒绝覆盖已执行计划），只作补充证据。

# 附录 C　证据类型、验证状态与限制 {.unnumbered}

本附录用人类可读的方式说明各章结论的**证据类型**与**适用限制**，不重复展开台账记录原文（含工程编号的结论原文属核对材料，随支撑材料归档，不进入正文）。

| 章节 | 结论类型 | 证据范围 | 验证状态 | 关键限制 |
|---|---|---|---|---|
| 第 4 章 预测 | 同期关联（内部分布内预测） | 同一批 250 款啤酒的 750 行折外预测 | 泄漏检查、基线比较、固定种子独立复跑通过 | 无留出集；划分完整性与留出指标检查结构性不可满足；选择为草稿选择 |
| 第 4 章 预测 | 相对分级一致性 | 训练折经验分布标定的 0–6 等级 | 与预测同协议 | 0–6 为相对等级，未恢复原始人工评分；预测向中部收缩；卡面 Acetaldehyde 项无标签、不预测 |
| 第 5 章 关键因素 | 同期关联（非因果） | 注册的 200 行训练集，风格分层重抽样 | 泄漏检查与固定种子独立复跑通过 | 方法间集合一致性不等于准确率；附件交叉相关表与本研究同源；方向一致率高但 95/150 入选频率低于 0.5 |
| 第 5 章 网络 | 描述性阈值图结构 | 附件 2 的 231×231 相关矩阵（231 节点 / 645 边 / 52 分量） | 规则预先声明、计数可复算；不进入验证 | 只是阈值图连通，不是功能模块或因果网络；全样本矩阵不入验证 |
| 第 6 章 生成 | 描述性分布质量 | 21 个可估风格、177 个可估格、729 份生成 | 泄漏检查与复跑通过；原生优化检查不适用 | 生成未优于同量源样本重采样参照；三个对照配置的 V 也略优；Kriek 逐风格读数离群；感官 t2n 代理仍增加 |
| 第 6 章 迁移 | 声明模型下的最优 | 231 维标准化空间、声明盒界与单条代理半空间 | 求解证书 198/198 最优并经独立复算；原生优化检查未通过、不声称 | 非全局最优、非迁移准确率；无迁移后真实标签；131/198 落在 1e-9 容差边界（qp-quantile 67、qp-source 64；495 行全策略合计 189/495）；198 次求解为 11 源 × 9 上下文 × 2 策略 |
| 第 7 章 稳健性 | 描述性（受饱和与覆盖限制） | 四个对象各自独立计划，冻结种子块参数扰动（问题二/三计划内 2 块，问题一 3 块，均覆盖 2 个种子） | 判定规则在执行前登记，四组均满足 | 覆盖率不足（2/3 种子）；问题二/三的补充种子块未并入计划记录；迁移侧指标饱和使极差为零不构成改善 |

**未完成事项（DRAFT 状态）**：图件已在本轮台账登记并进入正文（图 1–10）；交付检查未通过最终门禁（45 项质量检查：详见台账 quality.checks 的实时状态，本文不把旧快照当现状），`final=false`、`qualityPassed=false`；验证检查点仍不完整（问题一划分完整性/留出指标、问题三原生优化检查结构性未通过）；部分题目要求项登记为“数据不足”，不等于已完整回答。

